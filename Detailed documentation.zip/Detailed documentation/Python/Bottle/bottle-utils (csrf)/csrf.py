
# THIS IS THE UNOFFICIAL bottle-utils PACKAGE THAT CAN BE USED TO PROTECT BOTTLE WEB APPLICATION. 

from __future__ import unicode_literals

import os
import hashlib
import functools

from bottle import request, response, abort

from .html import HIDDEN
from .common import to_unicode

# no samesite, httponly or secure property are set in the cookie
ROOT = '/'
CSRF_TOKEN = '_csrf_token'
EXPIRES = 600  # seconds, i.e. 10 minutes
ENCODING = 'latin1'


def get_conf():
    """
    Return parsed configruation options. This function obtains the
    configuration from ``bottle.request.app.config`` object which is expected
    to be a dictionary-like object.
    This function raises ``KeyError`` if configuration misses
    """
    conf = request.app.config
    csrf_secret = conf['csrf.secret'] # signing key. There is no check at all for length or randomness
    csrf_token_name = str(conf.get('csrf.token_name', CSRF_TOKEN)) # name of cookie. If nothing provided, defaults to _csrf_token
    csrf_path = conf.get('csrf.path', ROOT).encode(ENCODING) # /
    try:
        cookie_expires = int(conf.get('csrf.expires', EXPIRES)) # 600 seconds by default
    except ValueError:
        cookie_expires = EXPIRES
    return csrf_secret, csrf_token_name, csrf_path, cookie_expires # returns the default values


# function responsible for generating the token
def generate_csrf_token():
    """
    Generate and set new CSRF token in cookie. The generated token is set to
    ``request.csrf_token`` attribute for easier access by other functions.
    It is generally not necessary to use this function directly.
    .. warning::
       This function uses ``os.urandom()`` call to obtain 8 random bytes when
       generating the token. It is possible to deplete the randomness pool and
       make the random token predictable.
    """
    secret, token_name, path, expires = get_conf()
    sha256 = hashlib.sha256()
    # vulnerable, only 64 bits of entropy. Today (OWASP) tokens are required to have a minimum of 128 bits of entropy (or a 16-byte token)
    # hashing with SHA-2 does not increase its entropy.
    sha256.update(os.urandom(8))
    # encoded to latin1
    token = sha256.hexdigest().encode(ENCODING)
    # place it in the cookie as encoded. The secret is passed as argument because the cookies are signed (HMAC-SHA256, then base64ed)
    # https://bottlepy.org/docs/dev/tutorial.html (search by "signed cookies").
    response.set_cookie(token_name, token, path=path,
                        secret=secret, max_age=expires)
    # while the token in the html body is saved as unencoded.                  
    request.csrf_token = token.decode(ENCODING)


# this is the function that is called in the  HTML template to retrieve the token.
# If it finds it in a cookie, it reuses it. If not, it calls generate() to generates the toke and set it in a cookie. This is used as a decorator above a route 
def csrf_token(func):
    """
    Create and set CSRF token in preparation for subsequent POST request. This
    decorator is used to set the token. It also sets the ``'Cache-Control'``
    header in order to prevent caching of the page on which the token appears.
    When an existing token cookie is found, it is reused. The existing token is
    reset so that the expiration time is extended each time it is reused.
    The POST handler must use the :py:func:`~csrf_protect` decotrator for the
    token to be used in any way.
    The token is available in the ``bottle.request`` object as ``csrf_token``
    attribute::
        @app.get('/')
        @bottle.view('myform')
        @csrf_token
        def put_token_in_form():
            return dict(token=request.csrf_token)
    In a view, you can render this token as a hidden field inside the form. The
    hidden field must have a name ``_csrf_token``::
        <form method="POST">
            <input type="hidden" name="_csrf_token" value="{{ token }}">
            ....
        </form>
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        secret, token_name, path, expires = get_conf()
        # if cookie came with request, it will reuse the token and also extend expiration time.
        # The get_cookie() will unsign the cookie and return the unsigned token
        token = request.get_cookie(token_name, secret=secret)
        if token:
            # We will reuse existing tokens, but a new cookie is set that extends the expiration time
            response.set_cookie(token_name, token, path=path,
                                secret=secret, max_age=expires)
            # the difference between token in body and token in cookie is that the one in body is not encoded, while the one in cookie is
            request.csrf_token = token.decode('utf8')
        else:
        # no cookie on a first-time request, so generate the token. Moreover, it will set the cookie with decoded token.
            generate_csrf_token()
        # Pages with CSRF tokens should not be cached
        response.headers[str('Cache-Control')] = ('no-cache, max-age=0, '
                                                  'must-revalidate, no-store')
        return func(*args, **kwargs)
    return wrapper


# the csrf verification
def csrf_protect(func):
    """
    Perform CSRF protection checks. Performs checks to determine if submitted
    form data matches the token in the cookie. It is assumed that the GET
    request handler successfully set the token for the request and that the
    form was instrumented with a CSRF token field. Use the
    :py:func:`~csrf_token` decorator to do this.
    If the handler function returns (i.e., it is not interrupted with
    ``bottle.abort()``, ``bottle.redirect()``, and similar functions that throw
    an exception, a new token is set and response is returned to the requester.
    It is therefore recommended to perform a reidrect on successful POST.
    Generally, the handler does not need to do anything
    CSRF-protection-specific. All it needs is the decorator::
        @app.post('/')
        @bottle.view('myform')
        @csrf_protect
        def protected_post_handler():
            if successful:
                redirect('/someplace')
            return dict(errors="There were some errors")
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        secret, token_name, path, expires = get_conf()
        # get token from the cookie. get_cookie will unsign the cookie and retrieve the encoded token.
        # If anything goes wrong (e.g. missing cookie or wrong signature), return a default value.
        token = request.get_cookie(token_name, secret=secret)
        # if no token in cookie, expired or bad signature, it will throw an error.
        if not token:
            abort(403, 'The form you submitted is invalid or has expired')
        # get the token from the body. The form_token is the decoded token.
        # It only checks on the form. No support for URL-based tokens or even custom headers.
        form_token = request.forms.get(token_name)
        # make sure they are same format.
        # Timing attacks on comparison is not possible, since token is regenerated per-request.
        # It converts them both to the same encoding (utf-8) before comparing, since token in cookie was 'latin1' encoded. This makes sure they are same encoding
        if to_unicode(form_token) != to_unicode(token):
        # if the condition fails, then the cookie is deleted, e.g expired (benign case) or because it is a failed attack
        # this will always call the regeneration function, which will set a new cookie anyway (regardless of successful/unseccesful check)
            response.delete_cookie(token_name, path=path, secret=secret,
                                   max_age=expires)
            abort(403, 'The form you submitted is invalid or has expired')
        # per-request tokens, so no BREACH
        generate_csrf_token()
        return func(*args, **kwargs)
    return wrapper

# instead of calling request.csrf_token to retrieve the token, add it to the HTML in a developer-defined input field
# this tag will automatically generate the form field as hidden with the token in it.
def csrf_tag():
    """
    Generte HTML for hidden form field. This is a convenience function to
    generate a simple hidden input field. It does not accept any arguments
    since it uses the ``bottle.request`` object to obtain the token.
    If the handler in which this function is invoked is not decorated with
    :py:func:`~csrf_token`, an ``AttributeError`` will be raised.
    :returns:   HTML markup for hidden CSRF token field
    """
    _, token_name, _, _ = get_conf()
    # csrf_token holds the generated csrf_token (either because generate() set it or because csrf_token() retrieved the token and placed it on req.csrf_token)
    token = request.csrf_token
    try:
        token_name = token_name.decode('utf8')
    except AttributeError:
        pass
    return HIDDEN(token_name, token)