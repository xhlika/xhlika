
# flask-wtf IS THE EXTERNAL OFFICIAL PACKAGE THAT HANDLES CSRF PROTECTION FOR FLASK APPLICATIONS. THE ENTIRE LOGIC OF THE ANTI-CSRF MECHANISM IS WITHIN THIS FILE.

import hashlib
import logging
import os
import warnings
from functools import wraps
from flask import Blueprint, current_app, g, request, session
from itsdangerous import BadData, SignatureExpired, URLSafeTimedSerializer
from werkzeug.exceptions import BadRequest
from werkzeug.security import safe_str_cmp
from wtforms import ValidationError
from wtforms.csrf.core import CSRF

from ._compat import FlaskWTFDeprecationWarning, string_types, urlparse

# these are the 3 main functions that handle the CSRF protection in this extension
__all__ = ('generate_csrf', 'validate_csrf', 'CSRFProtect')
logger = logging.getLogger(__name__)


#the function responsible for generating the token, read description below for what it does.
# It will return the signed token.
def generate_csrf(secret_key=None, token_key=None):
    """Generate a CSRF token. The token is cached for a request, so multiple
    calls to this function will generate the same token.
    During testing, it might be useful to access the signed token in
    ``g.csrf_token`` and the raw token in ``session['csrf_token']``.
    :param secret_key: Used to securely sign the token. Default is
        ``WTF_CSRF_SECRET_KEY`` or ``SECRET_KEY``.
    :param token_key: Key where token is stored in session for comparison.
        Default is ``WTF_CSRF_FIELD_NAME`` or ``'csrf_token'``.
    """
    # reads the config file if the developer has specified something, otherwise it will use the secret_key of the application.
    # if secret_key=none, it will get current_app.secret_key
    secret_key = _get_config(
        secret_key, 'WTF_CSRF_SECRET_KEY', current_app.secret_key,
        message='A secret key is required to use CSRF.'
    ) # this is just the name of the field in the server-side session where the token is stored, same like CsrfSecret was in Express's session
    field_name = _get_config(
        token_key, 'WTF_CSRF_FIELD_NAME', 'csrf_token',
        message='A field name is required to use CSRF.'
    )
    # g.csrf will contain the signed token while session[csrf_token] will contain the raw token.
    # So, if there is no signed token, there are 2 reasons: 1) token doesn't exist OR token exists, but not the signed version
    # g stands for global in Flask.
    if field_name not in g:
    # function in the library of "itsdangerous" that will sign the token. 
    # The salt is used at https://github.com/pallets/itsdangerous/blob/1776c8f73c38aebfebcc19cdd56b4854b0ad5997/src/itsdangerous/signer.py#L139
    # Salt is used to avoid hash collisions, since the app's secret key might be used in different places in app to derive keys (which uses SHA1, i.e. risk of collison)
    # the secret key is combined with the salt, then hashed with sha1. this is the key that will be used for signing the token.
        s = URLSafeTimedSerializer(secret_key, salt='wtf-csrf-token')
    # if the session does not have the "csrf_token" field, then create it.
    # this will generate the token and store it as base token in session["csrf_token"] in server-side
        if field_name not in session:
        
        
        # this is how the raw.base token is generated. It return a string of 64 bytes, generated cryptographically random with os.urandom().
        # os.urandom() will extract it from dev/urandom in Unix-like systems and from CryptoGenRandom() in WIndows, same as in JS frameworks.
        # These random bytes are then hashed using sha1. I.e. the actual stored raw/base token in server-side storage is a SHA-1 of these random bytes
            session[field_name] = hashlib.sha1(os.urandom(64)).hexdigest()
            
            
            
            
     # regardless of the fact that the raw/base token existed or was just generated (the "if" above), the big "if" that we are within happens
     # because there wasn't a signed token. Therefore, above we generate it.
     
     # this is the method that itsdangerous library uses to sign the base token.
     # https://github.com/pallets/itsdangerous/blob/1776c8f73c38aebfebcc19cdd56b4854b0ad5997/src/itsdangerous/serializer.py#L167
     # this method will call the make_signer() method of Serializer class (of itsdangerous) with the salt as argument (the one above), which will call:
     # https://github.com/pallets/itsdangerous/blob/1776c8f73c38aebfebcc19cdd56b4854b0ad5997/src/itsdangerous/signer.py#L156
     # This is the function that signs the token. base_token+.+HMACed_value_of_base_token_in_base64. It uses the function on line 149 (of signer.py) for signature
     # The signing key (HMAC-sha1 signature) is generated as explained above by hashing the provided salt + secret key of app/developer-provided.
     # This signature is then encoded to base64. This will be added to create the signed token of above: raw_value+.+HMACed_value_of_raw_in_base64
     
        try: #dumps() calls dump_payload() which converts the hashed base token to base64 before signing it. I.e. it signs the base64 raw-hashed token
        # timestamp is added at timed.py, so CSRF token is: base token_hashed_base64ed||.||base64ed_timestamp||.||signature
            token = s.dumps(session[field_name])
        except TypeError: #if there is some kind of error, e.g. expired token, then regenerate it again and sign it again
            session[field_name] = hashlib.sha1(os.urandom(64)).hexdigest()
            token = s.dumps(session[field_name])
        # set the signed token (which is the variable "token") in the g.field_name 
        setattr(g, field_name, token)
    
    # this is out of the "if"--> if field_name not in g:   
    # if token existed/already generated, this will just return the already signed token. Otherwise the code above will generate or sign a new token and return.
    return g.get(field_name)




# csrf verification is done here.
def validate_csrf(data, secret_key=None, time_limit=None, token_key=None):
    """Check if the given data is a valid CSRF token. This compares the given
    signed token to the one stored in the session.
    :param data: The signed CSRF token to be checked.
    :param secret_key: Used to securely sign the token. Default is
        ``WTF_CSRF_SECRET_KEY`` or ``SECRET_KEY``.
    :param time_limit: Number of seconds that the token is valid. Default is
        ``WTF_CSRF_TIME_LIMIT`` or 3600 seconds (60 minutes).
    :param token_key: Key where token is stored in session for comparison.
        Default is ``WTF_CSRF_FIELD_NAME`` or ``'csrf_token'``.
    :raises ValidationError: Contains the reason that validation failed.
    .. versionchanged:: 0.14
        Raises ``ValidationError`` with a specific error message rather than
        returning ``True`` or ``False``.
    """
  # the lines below get the secret key (used for signing), field name where the base token is stored ("session[csrf_token]") and the time limit 
    secret_key = _get_config(
        secret_key, 'WTF_CSRF_SECRET_KEY', current_app.secret_key,
        message='A secret key is required to use CSRF.'
    )
    field_name = _get_config(
        token_key, 'WTF_CSRF_FIELD_NAME', 'csrf_token',
        message='A field name is required to use CSRF.'
    )
    time_limit = _get_config(
        time_limit, 'WTF_CSRF_TIME_LIMIT', 3600, required=False
    )
     
    # if signed token is missing in the request, then just throw an error. 
    if not data:
        raise ValidationError('The CSRF token is missing.')
    # if the raw token cannot be found, then again throw an error; session expired, deleted etc, so don't allow request.
    if field_name not in session:
        raise ValidationError('The CSRF session token is missing.')
    # it uses itsdangerous again to now unsign the signed token that came with the request. loads() does the opposite of dumps()
    # It will call this for unsign(): https://github.com/pallets/itsdangerous/blob/1776c8f73c38aebfebcc19cdd56b4854b0ad5997/src/itsdangerous/signer.py#L171
    # if "." is missing, then it is a bad signing format, so error. Otherwise extract the signature and the re-sign the value before "." (the raw/base token)
    # this raw/base token will be re-signed and will hmac.compare_digest() will be use to compare the two signatures for verification.
    # comparison is timing safe: https://github.com/pallets/itsdangerous/blob/1776c8f73c38aebfebcc19cdd56b4854b0ad5997/src/itsdangerous/signer.py#L20
    s = URLSafeTimedSerializer(secret_key, salt='wtf-csrf-token')

    #if all goes fine, this will return the raw token.
    try:
        token = s.loads(data, max_age=time_limit)
    except SignatureExpired: # if token expired, it will throw an error
    # Note that the session cookie and the CSRF token have 2 distinct expiration times: session cookie depends on browser's session.
    # CSRF token is valid for 1 hours. If 1 hour is passed, a new token is generated and the session is modified.
    # session data in cookie is by default refreshed ine ach request, so the CSRF token will be updated as well.
        raise ValidationError('The CSRF token has expired.')
    except BadData: # there was some problem with the signature or its format.
        raise ValidationError('The CSRF token is invalid.')
 
    # otherwise at this point we have the raw token, signature was OK, token was not expired, so here the token comparison takes place.
    # It is a secure string comparison. It compares the raw/base token that was stored in the session with the token that was extracted from 
    # the signed token of req after signature verification. it uses HMAC comparison, or if missing, it does an XOR of the two values and checks if it is == 0
    # (meaning they are equal): https://github.com/pallets/werkzeug/blob/master/src/werkzeug/security.py#L75
    if not safe_str_cmp(session[field_name], token):
        raise ValidationError('The CSRF tokens do not match.')


# it is used above to retrieve the configured settings for the CSRF middleware.
def _get_config(
    value, config_name, default=None,
    required=True, message='CSRF is not configured.'
):
    """Find config value based on provided value, Flask config, and default
    value.
    :param value: already provided config value                      this is the value that dev provides, if none or missing, then use the default below
    :param config_name: Flask ``config`` key                         the config name that is used to stored the raw token in the session
    :param default: default value if not provided or configured     e.g. current_app.secret_key if no other key is provided by dev.
    :param required: whether the value must not be ``None``
    :param message: error message if required config is not found
    :raises KeyError: if required config is not found
    """

    if value is None:
        value = current_app.config.get(config_name, default)

    if required and value is None:
        raise RuntimeError(message)

    return value

# CSRF protection for FlaskForm. 
# there are 2 protections (on this order): 
# 1. if global protection is enabled, CSRFprotect() is executed, so there is no point to run this on FlaskForm (would give same result)
# 2. if no global defense, (i.e. no extensions ), by default FlaskForm are already protected from CSRF (beginning of doc says it) so this will still check CSRF
class _FlaskFormCSRF(CSRF):
    def setup_form(self, form):
        self.meta = form.meta # keeps the configuration of the CSRF in the "meta" attribute of this class.
        return super(_FlaskFormCSRF, self).setup_form(form)

    # uses the function above to generate the token. The entire explanation is above.
    def generate_csrf_token(self, csrf_token_field):
        return generate_csrf(
            secret_key=self.meta.csrf_secret,
            token_key=self.meta.csrf_field_name
        )

    # the verification. 
    def validate_csrf_token(self, form, field):
        if g.get('csrf_valid', False):
            # already verified by CSRFProtect, so no point doing it again.
            return

        try:
            validate_csrf(
                field.data,
                self.meta.csrf_secret,
                self.meta.csrf_time_limit,
                self.meta.csrf_field_name
            )
        except ValidationError as e:
            logger.info(e.args[0])
            raise



# this is the extension's main function that provides global CSRF protection (since above was only when FlaskForms are used)
class CSRFProtect(object):
    """Enable CSRF protection globally for a Flask app.
    ::
        app = Flask(__name__)
        csrf = CSRFProtect(app)
    Checks the ``csrf_token`` field sent with forms, or the ``X-CSRFToken``
    header sent with JavaScript requests. Render the token in templates using
    ``{{ csrf_token() }}``.
    See the :ref:`csrf` documentation.
    """

    def __init__(self, app=None):
    # as in docs, views (just HTML that can have multiple forms) and blueprints can be exempt from CSRF verification
        self._exempt_views = set()
        self._exempt_blueprints = set()

        if app:
            self.init_app(app)

    def init_app(self, app):
        app.extensions['csrf'] = self
        # these are the defaults for this extensions when used globally.
        app.config.setdefault('WTF_CSRF_ENABLED', True)   # globally enabled
        app.config.setdefault('WTF_CSRF_CHECK_DEFAULT', True)  # all views need to be checked
        app.config['WTF_CSRF_METHODS'] = set(app.config.get(
            'WTF_CSRF_METHODS', ['POST', 'PUT', 'PATCH', 'DELETE'] #methods to verify
        ))
        app.config.setdefault('WTF_CSRF_FIELD_NAME', 'csrf_token')  # name it is stored in session
        app.config.setdefault(
            'WTF_CSRF_HEADERS', ['X-CSRFToken', 'X-CSRF-Token']    # or when token comes with ajax, check for this custom headers in request
        )
        app.config.setdefault('WTF_CSRF_TIME_LIMIT', 3600)      # token is valid for 1 hour
        # Origin header check is used in addition to the CSRF token verification
        app.config.setdefault('WTF_CSRF_SSL_STRICT', True)      # strict Origin header checking (only for https connections though)
        
        # jinja is a template engine used in python frameworks. This makes the token available to the view's context_processor
        # developer can call it with csrf_token(), which is same as generate_csrf() (the one explained at the top)
        app.jinja_env.globals['csrf_token'] = generate_csrf
        app.context_processor(lambda: {'csrf_token': generate_csrf})

        @app.before_request   # this is done before the app executes the request or goes to the view/route that will handle it.
        def csrf_protect():
            if not app.config['WTF_CSRF_ENABLED']: #if no csrf defense, return, nothing to do.
                return

            if not app.config['WTF_CSRF_CHECK_DEFAULT']:  # same as above
                return

            if request.method not in app.config['WTF_CSRF_METHODS']:  # if req is "safe", nothing to do.
                return

            if not request.endpoint:   # if it is not going to an existing route, return? there will be an error anyway.
                return

            if request.blueprint in self._exempt_blueprints:  # if the request destination is an exempted blueprint, nothing to do, so return.
                return

            view = app.view_functions.get(request.endpoint)  # gets the route/destination ("view" in flask) where the request is going to.
            dest = '{0}.{1}'.format(view.__module__, view.__name__)

            if dest in self._exempt_views:  # if the request is going to an exempted view, nothing to do so return.
                return

            # calls this function below, which goes further with the request
            self.protect()


    # extracts the token from the request body field with name "csrf_token"
    # will return none if not found
    def _get_csrf_token(self):
        # find the token in the form data
        field_name = current_app.config['WTF_CSRF_FIELD_NAME']
        base_token = request.form.get(field_name)
        # if found in request body, return it
        if base_token:
            return base_token

        # if the form has a prefix, the name will be {prefix}-csrf_token.
        # It checks in case it is with a different name blabla-csrf_token (as long as it ends with csrf_token)
        for key in request.form:
            if key.endswith(field_name):
                csrf_token = request.form[key]

                if csrf_token:
                    return csrf_token

        # find the token in the headers (for ajax cases). It will check for only 2 specific custom headers (supports Angular in X-CSRF-Token)
        for header_name in current_app.config['WTF_CSRF_HEADERS']:
            csrf_token = request.headers.get(header_name)

            if csrf_token:
                return csrf_token

        return None


    def protect(self):
    # checks the method of request again. if "safe" request method, then return since safe methods are supposed to be idempotent.
        if request.method not in current_app.config['WTF_CSRF_METHODS']:
            return

        try:  # will validate the token. It gets the signed token from the request (function above checks for it in body and headers)
              # Then, it calls the function above which takes care of validation. The secret key, name of field etc. are retrieved there from configuration file
            validate_csrf(self._get_csrf_token())
        except ValidationError as e:
            logger.info(e.args[0])
            self._error_response(e.args[0])

        # if validation was OK, it will check the origin header, BUT only if the request is over https. If over http, the check is not performed.
        if request.is_secure and current_app.config['WTF_CSRF_SSL_STRICT']:
            if not request.referrer:  #if the referrer header is not present, return an error; strict Origin header check.
                self._error_response('The referrer header is missing.')

            # host header contains only hostname and port, so it misses the protocol, which is what this thing is doing
            # Note that the developer calls it "good referrer" but he is actually comparing origins.
            good_referrer = 'https://{0}/'.format(request.host)

            # if it is not a same origin request, throw an error.
            if not same_origin(request.referrer, good_referrer):
                self._error_response('The referrer does not match the host.')

        # at this point, both checks where OK and no errors are issued. It sets g.csrf_valid=true, so that the FlaskFrom will not to the verification again
        g.csrf_valid = True  # mark this request as safe

    def exempt(self, view):
        """Mark a view or blueprint to be excluded from CSRF protection.
        ::
            @app.route('/some-view', methods=['POST'])
            @csrf.exempt
            def some_view():
                ...
        ::
            bp = Blueprint(...)
            csrf.exempt(bp)
        """

        if isinstance(view, Blueprint):
            self._exempt_blueprints.add(view.name)
            return view

        if isinstance(view, string_types):
            view_location = view
        else:
            view_location = '.'.join((view.__module__, view.__name__))

        self._exempt_views.add(view_location)
        return view

    def _error_response(self, reason):
        raise CSRFError(reason)

    def error_handler(self, view):
        """Register a function that will generate the response for CSRF errors.
        .. deprecated:: 0.14
            Use the standard Flask error system with
            ``@app.errorhandler(CSRFError)`` instead. This will be removed in
            version 1.0.
        The function will be passed one argument, ``reason``. By default it
        will raise a :class:`~flask_wtf.csrf.CSRFError`. ::
            @csrf.error_handler
            def csrf_error(reason):
                return render_template('error.html', reason=reason)
        Due to historical reasons, the function may either return a response
        or raise an exception with :func:`flask.abort`.
        """

        warnings.warn(FlaskWTFDeprecationWarning(
            '"@csrf.error_handler" is deprecated. Use the standard Flask '
            'error system with "@app.errorhandler(CSRFError)" instead. This '
            'will be removed in 1.0.'
        ), stacklevel=2)

        @wraps(view)
        def handler(reason):
            response = current_app.make_response(view(reason))
            raise CSRFError(response=response)

        self._error_response = handler
        return view

# this is deprecated and replaced by CSRFProtect, so if the constructor of this class is called,  it will call the correct constructor above. 
    """
    .. deprecated:: 0.14
        Renamed to :class:`~flask_wtf.csrf.CSRFProtect`.
    """

    def __init__(self, app=None):
        warnings.warn(FlaskWTFDeprecationWarning(
            '"flask_wtf.CsrfProtect" has been renamed to "CSRFProtect" '
            'and will be removed in 1.0.'
        ), stacklevel=2)
        super(CsrfProtect, self).__init__(app=app)

# the error to show if the csrf verification fails for some reasons. can be customized, as shown in the docs.
class CSRFError(BadRequest):
    """Raise if the client sends invalid CSRF data with the request.
    Generates a 400 Bad Request response with the failure reason by default.
    Customize the response by registering a handler with
    :meth:`flask.Flask.errorhandler`.
    """

    description = 'CSRF validation failed.'

# checks if origins match. If any of the 3 elements of origin does not match, then it will return false.
def same_origin(current_uri, compare_uri):
    current = urlparse(current_uri)
    compare = urlparse(compare_uri)

    return (
        current.scheme == compare.scheme
        and current.hostname == compare.hostname
        and current.port == compare.port
    )