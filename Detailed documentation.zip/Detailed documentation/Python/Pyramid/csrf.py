
# THIS IS THE SOURCE CODE OF THE ANTI-CSRF MECHANISM IN PYRAMID. THERE ARE 3 DIFFERENT POLICIES WHEN IT COMES TO CSRF PROTECTION. 
# EACH HAS ITS OWN NEW(), GET(), CHECK() METHODS. THE METHODS OF THESE 3 CLASSES ARE USED AT THE BOTTOM OF THIS BIG CLASS (THAT HAS THESE 3 POLICIES AS SUBCLASSES).
# BASED ON THE CONFIGURED POLICY, THE NEW(), GET(), CHECK() FUNCTIONS WILL BE CALLED ACCORDINGLY.

from urllib.parse import urlparse
import uuid
from webob.cookies import CookieProfile
from zope.interface import implementer

from pyramid.exceptions import BadCSRFOrigin, BadCSRFToken
from pyramid.interfaces import ICSRFStoragePolicy
from pyramid.settings import aslist
from pyramid.util import (
    SimpleSerializer,
    bytes_,
    is_same_domain,
    strings_differ,
    text_,
)



# this one is for backward compatibility when a part of CSRF login was developed in the session.

#FIRST POLICY
@implementer(ICSRFStoragePolicy)
class LegacySessionCSRFStoragePolicy:
    """ A CSRF storage policy that defers control of CSRF storage to the
    session.
    This policy maintains compatibility with legacy ISession implementations
    that know how to manage CSRF tokens themselves via
    ``ISession.new_csrf_token`` and ``ISession.get_csrf_token``.
    Note that using this CSRF implementation requires that
    a :term:`session factory` is configured.
    .. versionadded:: 1.9
    """
    # calls the function at the session.py that generates the token
    def new_csrf_token(self, request):
        """ Sets a new CSRF token into the session and returns it. """
        return request.session.new_csrf_token()
    # calls the function at the session.py that retrieves token from _csrft_ attribute of the session or generate a new token if missing (+ set it on  _csrft)
    def get_csrf_token(self, request):
        """ Returns the currently active CSRF token from the session,
        generating a new one if needed."""
        return request.session.get_csrf_token()
    # the CSRF verification function. The supplied token is the token of the request body.
    # The expected token is retrieved from the session.
    def check_csrf_token(self, request, supplied_token):
        """ Returns ``True`` if the ``supplied_token`` is valid."""
        expected_token = self.get_csrf_token(request)
        # function at pyramid.util class. Check whether two strings differ while avoiding timing attacks. This function returns True if the given strings differ 
        # and False if they are equal. It uses HMAC digest comparison to avoid timing attacks
        # not True (they differ)= false --> CSRF attempt. not False (equal)= True --> no CSRF.
        # bytes_ is another function in pyramid.utils that converts string to bytes, since it is the format in which HMAC digest comparison is done
        return not strings_differ(
            bytes_(expected_token), bytes_(supplied_token)
        )

# SECOND POLICY
# CSRF storage: session --> Plain Token mechanism.
# The default CSRF protection
@implementer(ICSRFStoragePolicy)
class SessionCSRFStoragePolicy:
    """ A CSRF storage policy that persists the CSRF token in the session.
    Note that using this CSRF implementation requires that
    a :term:`session factory` is configured.
    ``key``
        The session key where the CSRF token will be stored.
        Default: `_csrft_`.
    .. versionadded:: 1.9
    """
    # generates the token for this CSRF policy
    # uuid.uuid4() returns 32 hexadecimal digits, which is 16 bytes *8 = 128 bytes, but only 122 are actually random. 6 are used for the version. 
    # It will be a 32-char string in the end. uuid.uuid4() uses UUID(bytes=os.urandom(16), version=4) to generate the random bytes. so it uses os.urandom() in its core. secure.
    _token_factory = staticmethod(lambda: text_(uuid.uuid4().hex))
    # The session key where the CSRF token will be stored.
    def __init__(self, key='_csrft_'):
        self.key = key
    
    # calls _token_factory() to generate the token and places it in _csrft_ property of the session
    def new_csrf_token(self, request):
        """ Sets a new CSRF token into the session and returns it. """
        token = self._token_factory()
        request.session[self.key] = token
        return token
    
    # get token from the session's attribut _csrft, if nothing in session a new one is generated and returned. It is also placed in the session's attribute
    def get_csrf_token(self, request):
        """ Returns the currently active CSRF token from the session,
        generating a new one if needed."""
        token = request.session.get(self.key, None)
        if not token:
            token = self.new_csrf_token(request)
        return token
    
    #CSRF verification. Same logic as above at the Legacy method.
    def check_csrf_token(self, request, supplied_token):
        """ Returns ``True`` if the ``supplied_token`` is valid."""
        expected_token = self.get_csrf_token(request)
        return not strings_differ(
            bytes_(expected_token), bytes_(supplied_token)
        )


@implementer(ICSRFStoragePolicy)
# THIRD POLICY: Double Submit mechanism. 
class CookieCSRFStoragePolicy:
    """ An alternative CSRF implementation that stores its information in
    unauthenticated cookies, known as the 'Double Submit Cookie' method in the
    `OWASP CSRF guidelines
    <https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html#double-submit-cookie>`_.
    This gives some additional flexibility with
    regards to scaling as the tokens can be generated and verified by a
    front-end server.
    .. versionadded:: 1.9
    .. versionchanged: 1.10
       Added the ``samesite`` option and made the default ``'Lax'``.
    """
    # generated the same way as above.
    _token_factory = staticmethod(lambda: text_(uuid.uuid4().hex))
    
    # default settings for session cookie: Secure, HttpOnly not set, sameSite=lax by default.
    def __init__(
        self,
        cookie_name='csrf_token',
        secure=False,
        httponly=False,
        domain=None,
        max_age=None,
        path='/',
        samesite='Lax',
    ):
        self.cookie_profile = CookieProfile(
            cookie_name=cookie_name,
            secure=secure,
            max_age=max_age,
            httponly=httponly,
            path=path,
            domains=[domain],
            serializer=SimpleSerializer(),
            samesite=samesite,
        )
        self.cookie_name = cookie_name
    # function that generates the token same as in the Plain Token and places it in the CSRF cookie named "csrf_token". It also sets the cookie header for response
    def new_csrf_token(self, request):
        """ Sets a new CSRF token into the request and returns it. """
        token = self._token_factory()
        request.cookies[self.cookie_name] = token
        # once the token is generated, the CSRF cookie is set as well with the new value.
        def set_cookie(request, response):
            self.cookie_profile.set_cookies(response, token)

        request.add_response_callback(set_cookie)
        return token
    
    # retrieve the csrf token from the cookie.
    def get_csrf_token(self, request):
        """ Returns the currently active CSRF token by checking the cookies
        sent with the current request."""
        bound_cookies = self.cookie_profile.bind(request)
        token = bound_cookies.get_value()
        # if no CSRF cookie, it will call the function above that generates token and also places/sets the CSRF cookie for the response
        if not token:
            token = self.new_csrf_token(request)
        # otherwise return the CSRF token in the cookie.
        return token
    
    # same verification logic as the other 2 CSRF methods of session and legacy
    def check_csrf_token(self, request, supplied_token):
        """ Returns ``True`` if the ``supplied_token`` is valid."""
        expected_token = self.get_csrf_token(request)
        return not strings_differ(
            bytes_(expected_token), bytes_(supplied_token)
        )

############################################################################################################################################################

# retrieves the CSRF token by calling get_csrf_token() function of the chosen (or default) ICSRFStoragePolicies (1 of the 3 methods that handles the CSRF:
# legacy, session, cookie).
def get_csrf_token(request):
    """ Get the currently active CSRF token for the request passed, generating
    a new one using ``new_csrf_token(request)`` if one does not exist. This
    calls the equivalent method in the chosen CSRF protection implementation.
    .. versionadded :: 1.9
    """
    # the comment above is very accurate. Get the registered anti-CSRF mechanism and use its get() function to get the token. If no token is found, generate it.
    registry = request.registry
    csrf = registry.getUtility(ICSRFStoragePolicy)
    return csrf.get_csrf_token(request)


# generates the CSRF token by calling the responsible new_csrf_token() function of one of the 3 policies that is default/chosen for CSRF defense.
def new_csrf_token(request):
    """ Generate a new CSRF token for the request passed and persist it in an
    implementation defined manner. This calls the equivalent method in the
    chosen CSRF protection implementation.
    .. versionadded :: 1.9
    """
    registry = request.registry
    csrf = registry.getUtility(ICSRFStoragePolicy)
    return csrf.new_csrf_token(request)

# the CSRF verification
# token -->form field name. header---> the specific header to check iff token is not in request body.
def check_csrf_token(
    request, token='csrf_token', header='X-CSRF-Token', raises=True
):
    """ Check the CSRF token returned by the
    :class:`pyramid.interfaces.ICSRFStoragePolicy` implementation against the
    value in ``request.POST.get(token)`` (if a POST request) or
    ``request.headers.get(header)``. If a ``token`` keyword is not supplied to
    this function, the string ``csrf_token`` will be used to look up the token
    in ``request.POST``. If a ``header`` keyword is not supplied to this
    function, the string ``X-CSRF-Token`` will be used to look up the token in
    ``request.headers``.
    If the value supplied by post or by header cannot be verified by the
    :class:`pyramid.interfaces.ICSRFStoragePolicy`, and ``raises`` is
    ``True``, this function will raise an
    :exc:`pyramid.exceptions.BadCSRFToken` exception. If the values differ
    and ``raises`` is ``False``, this function will return ``False``.  If the
    CSRF check is successful, this function will return ``True``
    unconditionally.
    See :ref:`auto_csrf_checking` for information about how to secure your
    application automatically against CSRF attacks.
    .. versionadded:: 1.4a2
    .. versionchanged:: 1.7a1
       A CSRF token passed in the query string of the request is no longer
       considered valid. It must be passed in either the request body or
       a header.
    .. versionchanged:: 1.9
       Moved from :mod:`pyramid.session` to :mod:`pyramid.csrf` and updated
       to use the configured :class:`pyramid.interfaces.ICSRFStoragePolicy` to
       verify the CSRF token.
    """
    supplied_token = ""
    # We first check the headers for a csrf token, as that is significantly
    # cheaper than checking the POST body
    if header is not None:
        supplied_token = request.headers.get(header, "")

    # If this is a POST/PUT/etc request, then we'll check the body to see if it
    # has a token. We explicitly use request.POST here because CSRF tokens
    # should never appear in an URL as doing so is a security issue. We also
    # explicitly check for request.POST here as we do not support sending form
    # encoded data over anything but a request.POST.
    if supplied_token == "" and token is not None:
        supplied_token = request.POST.get(token, "")
    
    # retrieves the policy that is configured to handle CSRF. 
    policy = request.registry.getUtility(ICSRFStoragePolicy)
    # each policy has its own check() function, though they do the same thing.
    # "request" is needed to extract the token from session or from csrf cookie that came with the request
    # "supplied_token" is the token in the request body or custom header
    # if check_csrf_token() returns true then request is ok. If false, this entire function returns false, implying a CSRF attempt.
    if not policy.check_csrf_token(request, text_(supplied_token)):
        if raises:
            raise BadCSRFToken('check_csrf_token(): Invalid token')
        return False
    # if comparison was ok, returns true, i.e. no CSRF.
    return True


# Origin header check: By default doesn't allow any origin (trusted_origins is an empty list), unless developer specifies some allowed origins: ['example.com', etc.]
# It also checks csrf_trusted_origins list in Pyramid, exactly like Django in addition to the trusted_origin list (which is empty by default)
# allow_no_origin is set to false, impying strict Origin header check. Note that this is done only for https connections, just like in Django. Same issues apply here.
def check_csrf_origin(
    request, *, trusted_origins=None, allow_no_origin=False, raises=True
):
    """
    Check the ``Origin`` of the request to see if it is a cross site request or
    not.
    If the value supplied by the ``Origin`` or ``Referer`` header isn't one of
    the trusted origins and ``raises`` is ``True``, this function will raise a
    :exc:`pyramid.exceptions.BadCSRFOrigin` exception, but if ``raises`` is
    ``False``, this function will return ``False`` instead. If the CSRF origin
    checks are successful this function will return ``True`` unconditionally.
    Additional trusted origins may be added by passing a list of domain (and
    ports if non-standard like ``['example.com', 'dev.example.com:8080']``) in
    with the ``trusted_origins`` parameter. If ``trusted_origins`` is ``None``
    (the default) this list of additional domains will be pulled from the
    ``pyramid.csrf_trusted_origins`` setting.
    ``allow_no_origin`` determines whether to return ``True`` when the
    origin cannot be determined via either the ``Referer`` or ``Origin``
    header. The default is ``False`` which will reject the check.
    Note that this function will do nothing if ``request.scheme`` is not
    ``https``.
    .. versionadded:: 1.7
    .. versionchanged:: 1.9
       Moved from :mod:`pyramid.session` to :mod:`pyramid.csrf`
    .. versionchanged:: 2.0
       Added the ``allow_no_origin`` option.
    """

    def _fail(reason):
        if raises:
            raise BadCSRFOrigin("Origin checking failed - " + reason)
        else:
            return False

    # Origin checks are only trustworthy / useful on HTTPS requests.
    # if over http, the skip is ignored and the request will be accepted regardless of the referrer (ofc if they have bypassed the csrf check above)
    if request.scheme != "https":
        return True
     
    # EXACT SAME COMMENT AS THE DJANGO CODE, COPIED FROM THERE (SINCE IN A GITHUB ISSUE WHERE IT WAS DISCUSSED ABOUT ADDING THE ORIGIN CHECK
    # THE DEVELOPERS MENTIONED DJANGO AS AN EXAMPLE TO FOLLOW)
    # ONLY DIFFERENCE: THEY CHECK THE ORIGIN. IF NOT FOUND LOOK AT REFERRER, WHILE DJANGO EXTRACTED THE ORIGIN OUT OF THE REFERRER HEADER


    # Suppose user visits http://example.com/
    # An active network attacker (man-in-the-middle, MITM) sends a
    # POST form that targets https://example.com/detonate-bomb/ and
    # submits it via JavaScript.
    #
    # The attacker will need to provide a CSRF cookie and token, but
    # that's no problem for a MITM when we cannot make any assumptions
    # about what kind of session storage is being used. So the MITM can
    # circumvent the CSRF protection. This is true for any HTTP connection,
    # but anyone using HTTPS expects better! For this reason, for
    # https://example.com/ we need additional protection that treats
    # http://example.com/ as completely untrusted. Under HTTPS,
    # Barth et al. found that the Referer header is missing for
    # same-domain requests in only about 0.2% of cases or less, so
    # we can use strict Referer checking.

    # Determine the origin of this request
    origin = request.headers.get("Origin")
    origin_is_referrer = False
    # at this point origin header was not present so pyramid will try to check if referrer header is present instead
    # if yes it will mark that by using the boolean variable origin_is_referrer
    if origin is None:
        origin = request.referrer
        origin_is_referrer = True
    
    # origin header was on the request.
    else:
        # use the last origin in the list under the assumption that the
        # server generally appends values and we want the origin closest
        # to us
        origin = origin.split(' ')[-1]

    # If we can't find an origin (neither on the referrer, nor in the origin header), fail or pass immediately depending on
    # ``allow_no_origin``
    # it is strict origin check. if no origin header or referrer, throw an error.
    if not origin:
        if allow_no_origin: # which is false by default = DO STRICT CHECK
            return True
        else:
            return _fail("missing Origin or Referer.")

    # Determine which origins we trust, which by default will include the
    # current origin. It will check the csrf_trusted_origin configuration also. If there are values in it, it will be added to trusted_origins list
    if trusted_origins is None:
        trusted_origins = aslist(
            request.registry.settings.get("pyramid.csrf_trusted_origins", [])
        )
    
    # "which by default will include the current origin". This is what it does here, adds the same origin in the list of trusted_origins.
    if request.host_port not in {"80", "443"}:
        trusted_origins.append("{0.domain}:{0.host_port}".format(request))
    else: # host is normally domain+port. if port was 80 or 443, no need to add it, we know it is 443 (https above)for sure,otherwise we wouldn't be here
        trusted_origins.append(request.domain)

    # Check "Origin: null" against trusted_origins. If Origin header was present and was null, it checks that maybe null is specified as trusted_origin by developer.
    # (insecure but developer's fault). Otherwise (the common case) it will return an error since the origin:null should not happen or is not allowed.
    if not origin_is_referrer and origin == 'null':
        if origin in trusted_origins:
            return True
        else:
            return _fail("null does not match any trusted origins.")

    # Parse our origin so that we can extract the required information from it.
    originp = urlparse(origin)

    # Ensure that our Referer is also secure.
    if originp.scheme != "https":
        return _fail("Origin is insecure while host is secure.")

    # Actually check to see if the request's origin matches any of our trusted origins.
    # any() will return true, if any of the iteration is true. If all are false, it means that the request origin was not in the list of trusted_origins--> throw error
    if not any(
        is_same_domain(originp.netloc, host) for host in trusted_origins # only checks netloc: host+port, we know scheme is https for sure at this point
    ):
        return _fail("{} does not match any trusted origins.".format(origin))
    # if Origin/Referrer header is present,  not null and is not listed of trusted origins then allow the request (by returning true)
    return True