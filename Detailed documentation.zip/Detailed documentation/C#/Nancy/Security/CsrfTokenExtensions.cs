﻿
// THIS CLASS HOLDS THE HELPER FUNCTIONS THAT GENERATE THE RANDOM BASE TOKEN AND THE FUNCTION THAT SIGNS THE CSRF TOKEN.
namespace Nancy.Security
{
    using System;
    using System.Linq;
    using System.Security.Cryptography;

    using Nancy.Cryptography;

    /// <summary>
    /// Extension methods for CSRF token related tasks.
    /// </summary>
    public static class CsrfTokenExtensions
    {
        private static readonly RandomNumberGenerator randomGenerator = RandomNumberGenerator.Create();

        /// <summary>
        /// Gets a byte array representation of the csrf token for generating
        /// hmacs
        /// </summary>
        /// <param name="token">Token</param>
        /// <returns>Byte array representing the token</returns>
        
        // converts base token+timestamp into bytes, e.g. because HMAC is only applied on bytes
        public static byte[] GetCsrfTokenBytes(this CsrfToken token)
        {
            return token.RandomBytes
                        .Concat(BitConverter.GetBytes(token.CreatedDate.UtcTicks))
                        .ToArray();
        }

        /// <summary>
        /// Calculates and sets the Hmac property on a given token
        /// </summary>
        /// <param name="token">Token</param>
        /// <param name="hmacProvider">Hmac provider to use</param>
        /// <returns>Hmac bytes</returns>
        
        // HMAC the base token + timestamp and attach the HMAC to the final CSRF token (which will be verified for tampering during CSRF verification). See below for the source code of signing process:
        // https://github.com/NancyFx/Nancy/blob/master/src/Nancy/Cryptography/CryptographyConfiguration.cs --> HMAC-SHA256
        public static void CreateHmac(this CsrfToken token, IHmacProvider hmacProvider)
        {
            // https://github.com/NancyFx/Nancy/blob/master/src/Nancy/Cryptography/DefaultHmacProvider.cs#L58
            // computes a HMAC-SHA256 using an automatically-generated signing key (of default size 64 bytes)
            // https://github.com/NancyFx/Nancy/blob/master/src/Nancy/Cryptography/RandomKeyGenerator.cs : same CSPRNG as the one that generates the CSRF token is used
            token.Hmac = hmacProvider.GenerateHmac(token.GetCsrfTokenBytes());
        }

        /// <summary>
        /// Creates random bytes for the csrf token
        /// </summary>
        /// <returns>Random byte array</returns>
        
        // generates the base/random token using RandomNumberGenerator, a CSPRNG. See link below:
        // https://docs.microsoft.com/en-us/dotnet/api/system.security.cryptography.randomnumbergenerator?view=netcore-3.1
        public static void CreateRandomBytes(this CsrfToken token)
        {
            // the base token is 10 bytes, which does not provide enough entropy (80 bits of entropy < 128)
            var randomBytes = new byte[10];

            randomGenerator.GetBytes(randomBytes);
 
            // the random token is stored in the token object. The final csrf token is: base_token || timestamp || hmac_of_both
            token.RandomBytes = randomBytes;
        }
    }
}