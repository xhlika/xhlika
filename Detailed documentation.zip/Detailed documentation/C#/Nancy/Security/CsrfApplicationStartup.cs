﻿
// THIS CLASS IS RESPONSIBLE FOR THE "BOOTING" THE ANTI-CSRF MECHANISM IF IT IS ENABLED. IT BOOTS THE ANTI-CSRF MECHANISM WHILE IT SPECIFIES THE CRYPTOGRAPHIC PROVIDER THAT WILL SIGN THE CSRF TOKENS
// AND ALSO THE TOKEN VALIDATOR. IF DEVELOPER DOESN'T SPECIFY ANYTHING DIFFERENTLY THE DEFAULT ONES WILL BE USED (E.G. DefaultCsrfTokenValidatior.cs CLASS WILL BE USED FOR CSRF VERIFICATION)
namespace Nancy.Security
{
    using Nancy.Bootstrapper;
    using Nancy.Cryptography;

    /// <summary>
    /// Wires up the CSRF (anti-forgery token) support at application startup.
    /// </summary>
    public class CsrfApplicationStartup : IApplicationStartup
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CsrfApplicationStartup"/> class, using the
        /// provided <paramref name="cryptographyConfiguration"/> and <paramref name="tokenValidator"/>.
        /// </summary>
        /// <param name="cryptographyConfiguration">The cryptographic configuration to use.</param>
        /// <param name="tokenValidator">The token validator that should be used.</param>
        
        /* https://github.com/NancyFx/Nancy/tree/master/src/Nancy/Cryptography --> AES(not important) and HMAC-SHA256(for token) are defaults
           Signing keys are generated automatically by default (with a size of 64) and used to sign the token. Same CSPRNG as the one used for CSRF token is used to generate the key. See below: 
           https://docs.microsoft.com/en-us/dotnet/api/system.security.cryptography.hmacsha256.-ctor?view=netcore-3.1 --> 64 bytes is enough
          Follow the link for a slightly more detailed explanation of this class: https://github.com/NancyFx/Nancy/blob/master/src/Nancy/Security/ICsrfTokenValidator.cs */
        public CsrfApplicationStartup(CryptographyConfiguration cryptographyConfiguration, ICsrfTokenValidator tokenValidator)
        {
            CryptographyConfiguration = cryptographyConfiguration;
            TokenValidator = tokenValidator;
        }

        /// <summary>
        /// Gets the configured crypto config
        /// </summary>
        internal static CryptographyConfiguration CryptographyConfiguration { get; private set; }

        /// <summary>
        /// Gets the configured token validator
        /// </summary>
        internal static ICsrfTokenValidator TokenValidator { get; private set; }

        /// <summary>
        /// Perform any initialisation tasks
        /// </summary>
        /// <param name="pipelines">Application pipelines</param>
        public void Initialize(IPipelines pipelines)
        {
        }
    }
}
