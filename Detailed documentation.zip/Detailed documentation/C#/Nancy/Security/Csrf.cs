﻿

// THIS IS THE SOURCE CODE OF THE MAIN FILE THAT HANDLES CSRF PROTECTION IN NANCY FRAMEWORKS. IT WILL MANAGE TOKEN GENERATION AND VERIFICATION BY CALLING THE RESPECTIVE FUNCTIONS IN OTHER CLASSES
// (CsrfTokenExtensions.cs FOR GENERATION AND DefaultCsrfTokenValidator.cs FOR VERIFICATION).
namespace Nancy.Security
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Text;

    using Nancy.Bootstrapper;
    using Nancy.Cookies;
    using Nancy.Cryptography;

    /// <summary>
    /// Csrf protection methods
    /// </summary>
    
    public static class Csrf
    {
        private const string CsrfHookName = "CsrfPostHook";
        private const char ValueDelimiter = '#';
        private const char PairDelimiter = '|';

        /// <summary>
        /// Enables Csrf token generation.
        /// </summary>
        /// <remarks>This is disabled by default.</remarks>
        /// <param name="pipelines">The application pipelines.</param>
        /// <param name="cryptographyConfiguration">The cryptography configuration. This is <see langword="null" /> by default.</param>
        /// <param name="useSecureCookie">Set the CSRF cookie secure flag. This is <see langword="false"/> by default</param> 
        public static void Enable(IPipelines pipelines, CryptographyConfiguration cryptographyConfiguration = null, bool useSecureCookie = false)
        {
            // when enabled, you can define a crypto configuration or the default one will be used (AES, HMAC-SHA256, auto key generation)
            cryptographyConfiguration = cryptographyConfiguration ?? CsrfApplicationStartup.CryptographyConfiguration;

            var postHook = new PipelineItem<Action<NancyContext>>(
                CsrfHookName,
                context =>
                {
                    if (context.Response == null || context.Response.Cookies == null || context.Request.Method.Equals("OPTIONS", StringComparison.OrdinalIgnoreCase))
                    {
                        return;
                    }

                    object value;
                    // creates a CSRF cookie since the mechanism is Double Submit
                    if (context.Items.TryGetValue(CsrfToken.DEFAULT_CSRF_KEY, out value))
                    {
                        context.Response.Cookies.Add(new NancyCookie(
                            CsrfToken.DEFAULT_CSRF_KEY,
                            (string)value,
                            true, useSecureCookie));

                        return;
                    }

                    string cookieValue;
                    if (context.Request.Cookies.TryGetValue(CsrfToken.DEFAULT_CSRF_KEY, out cookieValue)) // "NCSRF", check CsrfToken class
                    {
                        var cookieToken = ParseToCsrfToken(cookieValue);
                        // if the CSRF cookie is valid (not tampered with), then its value is reused.
                        if (CsrfApplicationStartup.TokenValidator.CookieTokenStillValid(cookieToken))
                        {
                            context.Items[CsrfToken.DEFAULT_CSRF_KEY] = cookieValue;
                            return;
                        }
                    }

                    // this will generate the CSRF token (check function below)
                    var tokenString = GenerateTokenString(cryptographyConfiguration);
                    // the CSRF token is added to the context, e.g. if the developer needs to access it and render as part of the response
                    context.Items[CsrfToken.DEFAULT_CSRF_KEY] = tokenString;
                    // adds the CSRF cookie with the CSRF token as value to the response
                    context.Response.Cookies.Add(new NancyCookie(CsrfToken.DEFAULT_CSRF_KEY, tokenString, true, useSecureCookie));
                });

            pipelines.AfterRequest.AddItemToEndOfPipeline(postHook);
        }

        /// <summary>
        /// Disable csrf token generation
        /// </summary>
        /// <param name="pipelines">Application pipelines</param>
        public static void Disable(IPipelines pipelines)
        {
            pipelines.AfterRequest.RemoveByName(CsrfHookName);
        }

        /// <summary>
        /// Creates a new csrf token for this response with an optional salt.
        /// Only necessary if a particular route requires a new token for each request.
        /// </summary>
        /// <param name="module">Nancy module</param>
        /// <param name="cryptographyConfiguration">The cryptography configuration. This is <c>null</c> by default.</param>
        
        // this supports per-request token, if invoked by developer, but it is NOT automatically called by the CSRF middleware.
        // The function below is the one that generates the CSRF token only once and the CSRF token in CSRF cookie is reused (check above)
        public static void CreateNewCsrfToken(this INancyModule module, CryptographyConfiguration cryptographyConfiguration = null)
        {
            var tokenString = GenerateTokenString(cryptographyConfiguration);
            module.Context.Items[CsrfToken.DEFAULT_CSRF_KEY] = tokenString;
        }

        /// <summary>
        /// Creates a new csrf token with an optional salt.
        /// Does not store the token in context.
        /// </summary>
        /// <returns>The generated token</returns>
        internal static string GenerateTokenString(CryptographyConfiguration cryptographyConfiguration = null)
        {
            cryptographyConfiguration = cryptographyConfiguration ?? CsrfApplicationStartup.CryptographyConfiguration;
            // current timestamp is part of the CSRF token (1)
            var token = new CsrfToken
            {
                CreatedDate = DateTimeOffset.Now
            };
            // generate a 10-byte random value using the RandomNumberGenerator CSPRNG (2)
            token.CreateRandomBytes();
            // function in CsrfTokenExtensions class that retrieves the random bytes+timestamp and generates a HMAC-SHA256 out of them (3)
            token.CreateHmac(cryptographyConfiguration.HmacProvider);

            var builder = new StringBuilder();
            // the token is converted to base64 as a 3-part string: CSRF token = (1) + (2) + (3)
            builder.AppendFormat("RandomBytes{0}{1}", ValueDelimiter, Convert.ToBase64String(token.RandomBytes));
            builder.Append(PairDelimiter);
            builder.AppendFormat("Hmac{0}{1}", ValueDelimiter, Convert.ToBase64String(token.Hmac));
            builder.Append(PairDelimiter);
            builder.AppendFormat("CreatedDate{0}{1}", ValueDelimiter, token.CreatedDate.ToString("o", CultureInfo.InvariantCulture));

            return builder.ToString();
        }

        /// <summary>
        /// Validate that the incoming request has valid CSRF tokens.
        /// Throws <see cref="CsrfValidationException"/> if validation fails.
        /// </summary>
        /// <param name="module">Module object</param>
        /// <param name="validityPeriod">Optional validity period before it times out</param>
        /// <exception cref="CsrfValidationException">If validation fails</exception>
        
        // the CSRF verification
        public static void ValidateCsrfToken(this INancyModule module, TimeSpan? validityPeriod = null)
        {
            var request = module.Request;

            if (request == null)
            {
                return;
            }
            
            // retrieves the CSRF token (as a parsed object) from the CSRF cookie (see below)
            var cookieToken = GetCookieToken(request);
            // retrieves the CSRF token (as a parsed object) from the request's body or custom header named NCSRF (see below)
            var providedToken = GetProvidedToken(request);

            // calls the default validator function (Validate()) in DefaultCsrfTokenValidator class to perform the actual verification)
            var result = CsrfApplicationStartup.TokenValidator.Validate(cookieToken, providedToken, validityPeriod);

            // "ok" is only returned if verification succeeded (i.e. the token was not expired, was equal and not tampered with)
            if (result != CsrfTokenValidationResult.Ok)
            {
                throw new CsrfValidationException(result);
            }
        }

        // retrieves the CSRF token from the request's body or custom header named NCSRF (see below)
        private static CsrfToken GetProvidedToken(Request request)
        {
            CsrfToken providedToken = null;

            var providedTokenString = request.Form[CsrfToken.DEFAULT_CSRF_KEY].Value ?? request.Headers[CsrfToken.DEFAULT_CSRF_KEY].FirstOrDefault();
            if (providedTokenString != null)
            {
                providedToken = ParseToCsrfToken(providedTokenString);
            }

            return providedToken;
        }

        // retrieves the CSRF token from CSRF cookie
        private static CsrfToken GetCookieToken(Request request)
        {
            CsrfToken cookieToken = null;

            string cookieTokenString;
            if (request.Cookies.TryGetValue(CsrfToken.DEFAULT_CSRF_KEY, out cookieTokenString))
            {
                cookieToken = ParseToCsrfToken(cookieTokenString);
            }

            return cookieToken;
        }

        private static void AddTokenValue(Dictionary<string, string> dictionary, string key, string value)
        {
            if (!string.IsNullOrEmpty(key))
            {
                dictionary.Add(key, value);
            }
        }

        // takes the CSRF token/CSRF COOKIE value as parameter and parses each part and returns a CsrfToken object with the CSRF token pieces as object properties (needed during CSRF verification)
        private static CsrfToken ParseToCsrfToken(string cookieTokenString)
        {
            var parsed = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            var currentKey = string.Empty;
            var buffer = new StringBuilder();
            // parses the CSRF token to extract the "pieces" needs to create the CsrfToken object
            for (var index = 0; index < cookieTokenString.Length; index++)
            {
                var currentCharacter = cookieTokenString[index];

                switch (currentCharacter)
                {
                    case ValueDelimiter:
                        currentKey = buffer.ToString();
                        buffer.Clear();
                        break;
                    case PairDelimiter:
                        AddTokenValue(parsed, currentKey, buffer.ToString());
                        buffer.Clear();
                        break;
                    default:
                        buffer.Append(currentCharacter);
                        break;
                }
            }

            AddTokenValue(parsed, currentKey, buffer.ToString());

            if (parsed.Keys.Count() != 3) // CSRF token needs to have 3 pieces: timestamp, base token, hmac
            {
                return null;
            }

            try
            {
                // after the CSRF token is parsed, the CsrfToken object is created (and returned) with 3 CSRF token pieces as properties: timestamp, base/random token and the HMAC of these two.
                return new CsrfToken
                {
                    CreatedDate = DateTimeOffset.ParseExact(parsed["CreatedDate"], "o", CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal),
                    Hmac = Convert.FromBase64String(parsed["Hmac"]),
                    RandomBytes = Convert.FromBase64String(parsed["RandomBytes"])
                };
            }
            catch
            {
                return null;
            }
        }
    }
}
