
// THIS CLASS HOLDS THE SOURCE CODE THAT IS RESPONSIBLE FOR THE DEFAULT TOKEN VALIDATOR (WHICH  OBVIOUSLY PERFORMS THE CSRF TOKEN VERIFICATION).
namespace Nancy.Security
{
    using System;
    using System.Linq;

    using Nancy.Cryptography;

    /// <summary>
    /// The default implementation of the <see cref="ICsrfTokenValidator"/> interface.
    /// </summary>
    
    // Follow the link to see the interface class that is implemented in this file: https://github.com/NancyFx/Nancy/blob/master/src/Nancy/Security/ICsrfTokenValidator.cs
    public class DefaultCsrfTokenValidator : ICsrfTokenValidator
    {
        private readonly IHmacProvider hmacProvider;

        /// <summary>
        /// Initializes a new instance of the <see cref="DefaultCsrfTokenValidator"/> class,
        /// using the provided <paramref name="cryptoConfig"/>.
        /// </summary>
        /// <param name="cryptoConfig">The <see cref="CryptographyConfiguration"/> that should be used.</param>
        public DefaultCsrfTokenValidator(CryptographyConfiguration cryptoConfig)
        {
            this.hmacProvider = cryptoConfig.HmacProvider;
        }

        /// <summary>
        /// Validates a pair of tokens
        /// </summary>
        /// <param name="tokenOne">First token (usually from either a form post or querystring)</param>
        /// <param name="tokenTwo">Second token (usually from a cookie)</param>
        /// <param name="validityPeriod">Optional period that the tokens are valid for</param>
        /// <returns>Token validation result</returns>
        
        // https://github.com/NancyFx/Nancy/blob/master/src/Nancy/Security/CsrfTokenValidationResult.cs
        // Validates a pair of tokens: tokenOne-from body or query string and tokenTwo from CSRF cookie
        public CsrfTokenValidationResult Validate(CsrfToken tokenOne, CsrfToken tokenTwo, TimeSpan? validityPeriod = new TimeSpan?())
        {
            // if any of the cookies is null, the "missing token error is thrown"
            if (tokenOne == null || tokenTwo == null)
            {
                return CsrfTokenValidationResult.TokenMissing;
            }

            // if the CSRF token in form doesn't match the CSRF token in cookie, "token mismatch" error is thrown. It performs an insecure token comparison since this Equals() is not overriden.
            if (!tokenOne.Equals(tokenTwo))
            {
                return CsrfTokenValidationResult.TokenMismatch;
            }

            // checks whether any of the tokens appear to have been tampered with. 
            // First, it checks if any of the values is null
            if (tokenOne.RandomBytes == null || tokenOne.RandomBytes.Length == 0)
            {
                return CsrfTokenValidationResult.TokenTamperedWith;
            }

            var newToken = new CsrfToken
                               {
                                   CreatedDate = tokenOne.CreatedDate,
                                   RandomBytes = tokenOne.RandomBytes,
                               };
                               
            // Second, re-HMAC-SHA256 the CSRF token                   
            newToken.CreateHmac(this.hmacProvider);
            // Third, compares the HMAC-SHA256 of the token that came with the request against the newly HMACed CSRF token.
            // An adversary cannot normally forge a valid HMAC/signature in the token object without having the secret key
            if (!newToken.Hmac.SequenceEqual(tokenOne.Hmac))
            {
                return CsrfTokenValidationResult.TokenTamperedWith;
            }

            // if specified, it will check whether the CSRF token is expired or not (since a timestamp is included in the token as "CreatedDate" property)
            if (validityPeriod.HasValue)
            {
                var expiryDate = tokenOne.CreatedDate.Add(validityPeriod.Value);
                
                // if current time has passed the expiration time, token expiration error is thrown. At this point, token was valid but it was expired.
                if (DateTimeOffset.Now > expiryDate)
                {
                    return CsrfTokenValidationResult.TokenExpired;
                }
            }
            // successful verification, proceed with the request
            return CsrfTokenValidationResult.Ok;
        }

        /// <summary>
        /// Validates that a cookie token is still valid with the current configuration / keys
        /// </summary>
        /// <param name="cookieToken">Token to validate</param>
        /// <returns>True if valid, false otherwise</returns>
        public bool CookieTokenStillValid(CsrfToken cookieToken)
        {
            // checks that the CSRF cookie is not null or missing any of its components
            if (cookieToken == null || cookieToken.RandomBytes == null || cookieToken.RandomBytes.Length == 0)
            {
                return false;
            }

            // verifies that the CSRF cookie was not tampered with by comparing HMACs
            var newToken = new CsrfToken
            {
                CreatedDate = cookieToken.CreatedDate,
                RandomBytes = cookieToken.RandomBytes,
            };
            newToken.CreateHmac(this.hmacProvider);

            if (!newToken.Hmac.SequenceEqual(cookieToken.Hmac))
            {
                return false;
            }

            return true;
        }
    }
}