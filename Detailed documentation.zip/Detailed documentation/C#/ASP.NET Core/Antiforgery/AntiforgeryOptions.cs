// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.


// THIS CLASS HANDLES THE CONFIGURATION OF THE ANTI-CSRF MECHANISM, SUCH AS THE CSRF COOKIE NAME, CSRF FORM FIELD NAME, SETTING THE X-FRAME-OPTIONS HEADER OR NOT, ETC.
// IF THE DEVELOPER ONLY ACTIVATES THE CSRF PROTECTION WITHOUT SPECIFYING ANY OF THESE OPTIONS, THE DEFAULTS PROVIDED IN THIS CLASS WILL BE USED.
using System;
using Microsoft.AspNetCore.Http;

namespace Microsoft.AspNetCore.Antiforgery
{
    /// <summary>
    /// Provides programmatic configuration for the antiforgery token system.
    /// </summary>
    public class AntiforgeryOptions
    {
        private const string AntiforgeryTokenFieldName = "__RequestVerificationToken";
        private const string AntiforgeryTokenHeaderName = "RequestVerificationToken";

        private string _formFieldName = AntiforgeryTokenFieldName;

        private CookieBuilder _cookieBuilder = new CookieBuilder
        {
            SameSite = SameSiteMode.Strict,  // by default, the CSRF cookie has Samesite property set to Strict.
            HttpOnly = true,

            // Check the comment on CookieBuilder class for more details
            IsEssential = true, // this cookie is essential for the application to function, shouldn't ask/need user's consent

            // Some browsers do not allow non-secure endpoints to set cookies with a 'secure' flag or overwrite cookies
            // whose 'secure' flag is set (http://httpwg.org/http-extensions/draft-ietf-httpbis-cookie-alone.html).
            // Since mixing secure and non-secure endpoints is a common scenario in applications, we are relaxing the
            // restriction on secure policy on some cookies by setting to 'None'. Cookies related to authentication or
            // authorization use a stronger policy than 'None'.
            SecurePolicy = CookieSecurePolicy.None, // secure=false by default
        };

        /// <summary>
        /// The default cookie prefix, which is ".AspNetCore.Antiforgery.".
        /// </summary>
        
        // the CSRF cookie name is: .AspNetCore.Antiforgery.||hash_of_application_id
        public static readonly string DefaultCookiePrefix = ".AspNetCore.Antiforgery.";

        /// <summary>
        /// Determines the settings used to create the antiforgery cookies.
        /// </summary>
        /// <remarks>
        /// <para>
        /// If an explicit <see cref="CookieBuilder.Name"/> is not provided, the system will automatically generate a
        /// unique name that begins with <see cref="DefaultCookiePrefix"/>.
        /// </para>
        /// <para>
        /// <see cref="CookieBuilder.SameSite"/> defaults to <see cref="SameSiteMode.Strict"/>.
        /// <see cref="CookieBuilder.HttpOnly"/> defaults to <c>true</c>.
        /// <see cref="CookieBuilder.IsEssential"/> defaults to <c>true</c>. The cookie used by the antiforgery system
        /// is part of a security system that is necessary when using cookie-based authentication. It should be
        /// considered required for the application to function.
        /// <see cref="CookieBuilder.SecurePolicy"/> defaults to <see cref="CookieSecurePolicy.None"/>.
        /// </para>
        /// </remarks>
        public CookieBuilder Cookie
        {
            get => _cookieBuilder;
            set => _cookieBuilder = value ?? throw new ArgumentNullException(nameof(value));
        }

        /// <summary>
        /// Specifies the name of the antiforgery token field that is used by the antiforgery system.
        /// </summary>
        
        //FormFieldName =  __RequestVerificationToken
        public string FormFieldName
        {
            get => _formFieldName;
            set => _formFieldName = value ?? throw new ArgumentNullException(nameof(value));
        }

        /// <summary>
        /// Specifies the name of the header value that is used by the antiforgery system. If <c>null</c> then
        /// antiforgery validation will only consider form data.
        /// </summary>
        
        // HeaderName = RequestVerificationToken
        public string HeaderName { get; set; } = AntiforgeryTokenHeaderName;

        /// <summary>
        /// Specifies whether to suppress the generation of X-Frame-Options header
        /// which is used to prevent ClickJacking. By default, the X-Frame-Options
        /// header is generated with the value SAMEORIGIN. If this setting is 'true',
        /// the X-Frame-Options header will not be generated for the response.
        /// </summary>
        
        // by default, this header will be set to prevent Clickjacking
        public bool SuppressXFrameOptionsHeader { get; set; }
    }
}