// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.



// THIS CLASS CONSTRUCTS THE FINAL CSRF TOKEN (USING THE RANDOM BASE TOKEN, CLAIMUID/USERNAME AND ADDITTIONAL_DATA). THEN IT WILL ENCRYPT AND SIGN BOTH THE CSRF TOKEN IN FORM AND IN CSRF COOKIE.
// MOREOVER, THE INVERSE PROCESS (DESERIALIZE) IS ALSO DONE IN THIS CLASS. VISIT THE LINK FOR INFORMATION ON CRYPTOGRAPHIC OPERATIONS IN ASP.NET CORE:
// https://docs.microsoft.com/en-us/aspnet/core/security/data-protection/using-data-protection?view=aspnetcore-3.1
using System;
using System.IO;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.ObjectPool;

namespace Microsoft.AspNetCore.Antiforgery
{
    internal class DefaultAntiforgeryTokenSerializer : IAntiforgeryTokenSerializer
    {
        private static readonly string Purpose = "Microsoft.AspNetCore.Antiforgery.AntiforgeryToken.v1";
        private const byte TokenVersion = 0x01;

        private readonly IDataProtector _cryptoSystem;
        private readonly ObjectPool<AntiforgerySerializationContext> _pool;

        public DefaultAntiforgeryTokenSerializer(
            IDataProtectionProvider provider,
            ObjectPool<AntiforgerySerializationContext> pool)
        {
            if (provider == null)
            {
                throw new ArgumentNullException(nameof(provider));
            }

            if (pool == null)
            {
                throw new ArgumentNullException(nameof(pool));
            }

            _cryptoSystem = provider.CreateProtector(Purpose);
            _pool = pool;
        }

        // deserializes the encrypted final CSRF token so that its data can be extracted and used during the CSRF verification.
        // It returns an object with the "pieces" of the CSRF token
        public AntiforgeryToken Deserialize(string serializedToken)
        {
            var serializationContext = _pool.Get();

            Exception innerException = null;
            try
            {
                var count = serializedToken.Length;
                var charsRequired = WebEncoders.GetArraySizeRequiredToDecode(count);
                var chars = serializationContext.GetChars(charsRequired);
                // the CSRF token in bytes
                var tokenBytes = WebEncoders.Base64UrlDecode(
                    serializedToken,
                    offset: 0,
                    buffer: chars,
                    bufferOffset: 0,
                    count: count);
 
                // decrypts (and un-HMACs) the encrypted (and base64ed) CSRF token
                var unprotectedBytes = _cryptoSystem.Unprotect(tokenBytes);
                var stream = serializationContext.Stream;
                stream.Write(unprotectedBytes, offset: 0, count: unprotectedBytes.Length);
                stream.Position = 0L;

                var reader = serializationContext.Reader;
                // this AntiforgeryToken object will hold the deserialized token. See the function below for how the deserialization is done
                var token = Deserialize(reader);
                if (token != null)
                {
                    return token;
                }
            }
            catch (Exception ex)
            {
                // swallow all exceptions - homogenize error if something went wrong
                innerException = ex;
            }
            finally
            {
                _pool.Return(serializationContext);
            }

            // if we reached this point, something went wrong deserializing
            throw new AntiforgeryValidationException(Resources.AntiforgeryToken_DeserializationFailed, innerException);
        }
        

         // THIS IS THE COMPLETE FORMAT OF THE CSRF TOKEN, EXPLAINING EACH BIT. THIS FUNCTION DESERIALIZES THE CSRF TOKEN 
         
         
        /* The serialized format of the anti-XSRF token is as follows:
         * Version: 1 byte integer (1)
         * SecurityToken: 16 byte binary blob (2)
         * IsCookieToken: 1 byte Boolean (3)
         * [if IsCookieToken != true]       --> this distinguishes the CSRF token from the CSRF cookie.
         *   +- IsClaimsBased: 1 byte Boolean (4)
         *   |  [if IsClaimsBased = true] 
         *   |    `- ClaimUid: 32 byte binary blob (5a)
         *   |  [if IsClaimsBased = false]
         *   |    `- Username: UTF-8 string with 7-bit integer length prefix (5b)
         *   `- AdditionalData: UTF-8 string with 7-bit integer length prefix (6)
         */
        private static AntiforgeryToken Deserialize(BinaryReader reader)
        {
            // we can only consume tokens of the same serialized version that we generate
            // retrieves the version (1)
            var embeddedVersion = reader.ReadByte();
            if (embeddedVersion != TokenVersion)  // 0x01
            {
                return null;
            }

            var deserializedToken = new AntiforgeryToken(); // creates a CSRF token object (with properties like username, random token, etc)
            // retrieves the 16 bytes of the random token (2)
            var securityTokenBytes = reader.ReadBytes(AntiforgeryToken.SecurityTokenBitLength / 8);
            // Generates a token using an existing binary value. I.e. the random token is turned into a string, ready for comparison.
            // For more information check the corresponding constructor in BinaryBlob class.
            deserializedToken.SecurityToken =
                new BinaryBlob(AntiforgeryToken.SecurityTokenBitLength, securityTokenBytes);
            // retrieves the Boolean property that distinguishes the CSRF token from the CSRF cookie (3)
            deserializedToken.IsCookieToken = reader.ReadBoolean();
            
            // if is a CSRF token (and not a cookie)
            if (!deserializedToken.IsCookieToken)
            {
                // retrieves 1 byte that determines if ClaimUid is used or username
                var isClaimsBased = reader.ReadBoolean();
                // if isClaimsBased=true, then claimUid is used instead of the username. So the next step is to extract 32 bytes
                if (isClaimsBased)
                {
                    // extract 32 bytes of the claimUid from the CSRF token (5a)
                    var claimUidBytes = reader.ReadBytes(AntiforgeryToken.ClaimUidBitLength / 8);
                    // convert bytes into string
                    deserializedToken.ClaimUid = new BinaryBlob(AntiforgeryToken.ClaimUidBitLength, claimUidBytes);
                }
                else
                {   // otherwise extract the string of the username from the CSRF token (5b)
                    deserializedToken.Username = reader.ReadString();
                }
                // extract the additional data (if specified) from the CSRF token  
                deserializedToken.AdditionalData = reader.ReadString();
            }

            // if there's still unconsumed data in the stream, fail.
            // This is an indicator that the csrf token is tampered with, i.e. providing more data then expected
            if (reader.BaseStream.ReadByte() != -1)
            {
                return null;
            }

            // success
            // returns an AntiforgeryToken object containing all pieces of the CSRF token.
            return deserializedToken;
        }

        // serializes the CSRF token by putting token pieces together. This is used for both the CSRF token and for the CSRF cookie since both of them are serialized and encrypted. 
        // The only difference is that the CSRF token has additional information such as username/claimUid, additional data,etc. Whether this is a CSRF token or cookie is decided by
        // IsCookieToken attribute of the object.
        // token is an object containing all necessary fields to generate the final csrf token(generated random token, username/claimUid,etc). See AntiforgeryToken class for more information
        public string Serialize(AntiforgeryToken token)
        {
            if (token == null)
            {
                throw new ArgumentNullException(nameof(token));
            }

            var serializationContext = _pool.Get();

            try
            {
                var writer = serializationContext.Writer;
                writer.Write(TokenVersion); // this is the first byte that shows the version (1)
                writer.Write(token.SecurityToken.GetData()); // the random token (2)
                writer.Write(token.IsCookieToken);  // the byte determining if it is a CSRF token or a CSRF cookie (3)
                
                // if csrf token
                if (!token.IsCookieToken)
                {
                    
                    if (token.ClaimUid != null) // are we using claimUid or username?
                    {
                        writer.Write(true /* isClaimsBased */); // 1 byte that tells the value of ClaimUid (true in this case) (4)
                        writer.Write(token.ClaimUid.GetData()); // the 32 bytes of the claimUid (5a)
                    }
                    else
                    {  // when user is not authenticated, at AntiforgeryToken class the username is set to an empty string
                        writer.Write(false /* isClaimsBased */); // 1 byte that tells the value of ClaimUid (false in this case) (4)
                        writer.Write(token.Username);   // otherwise the string of the username (5b)
                    }

                    writer.Write(token.AdditionalData); // if specified, the additional data is added at the end of the CSRF token (6)
                }

                writer.Flush();
                var stream = serializationContext.Stream;
                // the CSRF token/cookie is encrypted and HMACed. In ASP.NET Protect() does encryptiion, signing (HMAC) and also encode the data to URL-safe base64.
                // These APIs have changed in ASP.NET Core and only handle the cryptographic operations.
                var bytes = _cryptoSystem.Protect(stream.ToArray());

                var count = bytes.Length;
                // ensures that the size of bytes is not too big
                var charsRequired = WebEncoders.GetArraySizeRequiredToEncode(count);
                var chars = serializationContext.GetChars(charsRequired);
                // the encrypted CSRF token is then encoded to base64, in an URL safe version
                var outputLength = WebEncoders.Base64UrlEncode(
                    bytes,
                    offset: 0,
                    output: chars,
                    outputOffset: 0,
                    count: count);

                return new string(chars, startIndex: 0, length: outputLength);
            }
            finally
            {
                _pool.Return(serializationContext);
            }
        }
    }
}