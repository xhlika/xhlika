// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.


// THIS CLASS IS CONCERNED WITH GENERATING A NAME FOR THE CSRF COOKIE WHICH ALSO INCLUDED THE HASH OF THE APPLICATION NAME IN IT.

using System;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Options;


namespace Microsoft.AspNetCore.Antiforgery
{
    internal class AntiforgeryOptionsSetup : IConfigureOptions<AntiforgeryOptions>
    {
        private readonly DataProtectionOptions _dataProtectionOptions;

        public AntiforgeryOptionsSetup(IOptions<DataProtectionOptions> dataProtectionOptions)
        {
            _dataProtectionOptions = dataProtectionOptions.Value;
        }

        public void Configure(AntiforgeryOptions options)
        {
            if (options == null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            // In ASP.NET Core the CSRF cookie has a name of this format: .AspNetCore.Antiforgery.hash_of_application_id
            // In ASP.NET MVC the CSRF cookie has the same name as form field where there CSRF token is stored ("__RequestVerificationToken") unless an application path is configured/found for this 
            //  application. In that case the name would be:  __RequestVerificationToken||_||encoded_application_path          
            if (options.Cookie.Name == null)
            {
                 // application_id: An identifier that uniquely distinguishes this application from all other applications on the machine. Visit the link below for more information:
                // https://docs.microsoft.com/en-us/dotnet/api/microsoft.aspnetcore.dataprotection.dataprotectionoptions.applicationdiscriminator?view=aspnetcore-3.1
                var applicationId = _dataProtectionOptions.ApplicationDiscriminator ?? string.Empty;
                // if no configuration is provided by the developer in Startup.cs then the default name for the CSRF cookie is: .AspNetCore.Antiforgery.||sha256_hash_and_encode_of_application_id
                options.Cookie.Name = AntiforgeryOptions.DefaultCookiePrefix + ComputeCookieName(applicationId); // check below
            }
        }
        
        // hashes the applicationId, and will take only first 8 characters of the hash and encode to base64_url to be URL-compliant
        private static string ComputeCookieName(string applicationId)
        {
            using (var sha256 = CryptographyAlgorithms.CreateSHA256())
            {
                var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(applicationId));
                var subHash = hash.Take(8).ToArray();
                return WebEncoders.Base64UrlEncode(subHash);
            }
        }
    }
}