// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.


// THIS IS THE SOUCE CODE THAT IS RESPONSIBLE FOR GETTING THE CSRF TOKEN FROM THE COOKIE AND FROM THE HTML FORM (IN THE REQUEST). ADDITIONALLY IT ALSO CREATES THE CSRF COOKIE
// (SINCE MECHANISM IS DOUBLE SUBMIT)
using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;

namespace Microsoft.AspNetCore.Antiforgery
{
    // Visit the link for a detailed explanation of each function used in this class: https://github.com/dotnet/aspnetcore/blob/master/src/Antiforgery/src/Internal/IAntiforgeryTokenStore.cs
    //  Gets the CSRF cookie and CSRF token from the curent request.
    internal class DefaultAntiforgeryTokenStore : IAntiforgeryTokenStore
    {
        private readonly AntiforgeryOptions _options;

        public DefaultAntiforgeryTokenStore(IOptions<AntiforgeryOptions> optionsAccessor)
        {
            if (optionsAccessor == null)
            {
                throw new ArgumentNullException(nameof(optionsAccessor));
            }

            _options = optionsAccessor.Value;
        }

        // retrieves the CSRF cookie from the incoming request based on the configured name.
        // It returns null if no token is found, otherwise the CSRF token in the cookie
        public string GetCookieToken(HttpContext httpContext)
        {
            Debug.Assert(httpContext != null);

            var requestCookie = httpContext.Request.Cookies[_options.Cookie.Name];
            if (string.IsNullOrEmpty(requestCookie))
            {
                // unable to find the cookie.
                return null;
            }

            return requestCookie;
        }

        // retrieves the CSRF token from the form or from the custom header AND the CSRF cookie.
        // It returns a AntiforgeryTokenSet object that contains both these tokens and their respective names
        public async Task<AntiforgeryTokenSet> GetRequestTokensAsync(HttpContext httpContext)
        {
            Debug.Assert(httpContext != null);

            var cookieToken = httpContext.Request.Cookies[_options.Cookie.Name];

            // We want to delay reading the form as much as possible, for example in case of large file uploads,
            // request token could be part of the header.
            StringValues requestToken = default;
            // if == null, the framework will only check for a CSRF token in the form.
            // Otherwise it checks in the headers since it is faster + also delay the process for file uploads.
            if (_options.HeaderName != null)
            {
                requestToken = httpContext.Request.Headers[_options.HeaderName];
            }

            // Fall back to reading form instead
            // if no token was found in the header and the request contains a standard form content type
            // https://docs.microsoft.com/en-us/dotnet/api/microsoft.aspnetcore.http.httprequest.hasformcontenttype?view=aspnetcore-3.1
            if (requestToken.Count == 0 && httpContext.Request.HasFormContentType)
            {
                // Check the content-type before accessing the form collection to make sure
                // we report errors gracefully.
                var form = await httpContext.Request.ReadFormAsync();
                requestToken = form[_options.FormFieldName]; // the csrf token in the request's body
            }

            // https://github.com/dotnet/aspnetcore/blob/master/src/Antiforgery/src/AntiforgeryTokenSet.cs
            // Creates the antiforgery token pair (cookie and request token) for a request, i.e contains the 2 tokens to be compared
            return new AntiforgeryTokenSet(requestToken, cookieToken, _options.FormFieldName, _options.HeaderName);
        }

        // sets the CSRF cookie in the response
        public void SaveCookieToken(HttpContext httpContext, string token)
        {
            Debug.Assert(httpContext != null);
            Debug.Assert(token != null);

            var options = _options.Cookie.Build(httpContext);

            if (_options.Cookie.Path != null)
            {
                options.Path = _options.Cookie.Path;
            }
            else
            {
                var pathBase = httpContext.Request.PathBase.ToString();
                if (!string.IsNullOrEmpty(pathBase))
                {
                    options.Path = pathBase;
                }
            }

            httpContext.Response.Cookies.Append(_options.Cookie.Name, token, options);
        }
    }
}