// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.




// THIS CLASS WILL GENERATE  (AND VERIFY) THE FINAL CSRF TOKEN (RANDOM TOKEN || CLAIM_UID/USERNAME || ADDITIONAL_DATA)
// THIS IS THE MAIN CLASS THAT HANDLES TOKEN GENERATION BY CALLING OTHER ADDITIONAL CLASS LIKE AntiforgeryToken (WHICH CALLS BinaryBlob WHERE THE TOKEN GENERATION IS ACTUALLY DONE)
// IT WILL ALSO CALL THE OTHER CLASSES TO EXTRACT THE CLAIM_UID AND ADDITIONAL_DATA TO CREATE THE FINAL CSRF TOKEN. MORE IMPORTANTLY, IT WILL ALSO PERFOM THE CSRF VERIFICATION.
// ALSO SEE: https://github.com/dotnet/aspnetcore/blob/master/src/Antiforgery/src/Internal/IAntiforgeryTokenGenerator.cs
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using Microsoft.AspNetCore.Http;


namespace Microsoft.AspNetCore.Antiforgery
{
    internal class DefaultAntiforgeryTokenGenerator : IAntiforgeryTokenGenerator
    {
        private readonly IClaimUidExtractor _claimUidExtractor;
        private readonly IAntiforgeryAdditionalDataProvider _additionalDataProvider;

        public DefaultAntiforgeryTokenGenerator(
            IClaimUidExtractor claimUidExtractor,
            IAntiforgeryAdditionalDataProvider additionalDataProvider)
        {
            _claimUidExtractor = claimUidExtractor;
            _additionalDataProvider = additionalDataProvider;
        }

        /// <inheritdoc />
        // this function will generate the random token, NOT the final CSRF token.
        // the CSRF cookie will only contain the random token, NOT the entire CSRF token (which is stored in the form)
        public AntiforgeryToken GenerateCookieToken()
        {
            // the class of AntiforgeryToken will generate the random token, set username and additional data (if specified)           
            return new AntiforgeryToken()
            {
                // SecurityToken will be populated automatically.
                IsCookieToken = true 
            };
        }

        /// <inheritdoc />
        
        // this function will generate the final CSRF token = random_token || username/claim_uid || additional_data_if_specified
        // I.e. the final CSRF TOKEN has 3 possible parts (1||2||3)
        // This function returns an object that contains all parts needs to create the final CSRF token
        public AntiforgeryToken GenerateRequestToken(
            HttpContext httpContext,
            AntiforgeryToken cookieToken)
        {
            if (httpContext == null)
            {
                throw new ArgumentNullException(nameof(httpContext));
            }
 
            // if no csrf cookie is set, an error will be thrown
            if (cookieToken == null)
            {
                throw new ArgumentNullException(nameof(cookieToken));
            }
 
            // see below, if CSRF cookie is null or if isCookieToken=false, then an error is thrown
            if (!IsCookieTokenValid(cookieToken))
            {
                throw new ArgumentException(
                    Resources.Antiforgery_CookieToken_IsInvalid,
                    nameof(cookieToken));
            }

            // the CSRF token will contain the random token that was generated and placed in the CSRF cookie already by GenerateCookieToken()
            // (1)
            var requestToken = new AntiforgeryToken()
            {
                SecurityToken = cookieToken.SecurityToken,
                IsCookieToken = false  // this property is used to ensure that the CSRF token and CSRF cookie are not swapped by mistake
            };

            var isIdentityAuthenticated = false;

            // retrieve Username or ClaimUid, which will be added to the final CSRF token.
            // (2)
            var authenticatedIdentity = GetAuthenticatedIdentity(httpContext.User);

            if (authenticatedIdentity != null)
            {
                isIdentityAuthenticated = true;
                // this method of DefaultClaimUidExtractor class will try to extract the ClaimUid of the authenticated user
                requestToken.ClaimUid = GetClaimUidBlob(_claimUidExtractor.ExtractClaimUid(httpContext.User));
                
                // if no ClaimUid is found, it will use the username of the logged in user instead.
                // this can be empty if the user is not yet authenticated.
                if (requestToken.ClaimUid == null)
                {
                    requestToken.Username = authenticatedIdentity.Name;
                }
            }

            // populate AdditionalData
            // (3)
            if (_additionalDataProvider != null) // the default is set to null, unless the developer configures something
            {
                requestToken.AdditionalData = _additionalDataProvider.GetAdditionalData(httpContext);
            }

            // if the user is authenticated but both the username and ClaimUid are set to null an error is thrown for security.
            // This prevents CSRF tokens without user information while the user is actually authenticated (extra security)
            if (isIdentityAuthenticated
                && string.IsNullOrEmpty(requestToken.Username)
                && requestToken.ClaimUid == null
                && string.IsNullOrEmpty(requestToken.AdditionalData))
            {
                // Application says user is authenticated, but we have no identifier for the user.
                throw new InvalidOperationException(
                    Resources.FormatAntiforgeryTokenValidator_AuthenticatedUserWithoutUsername(
                        authenticatedIdentity.GetType(),
                        nameof(IIdentity.IsAuthenticated),
                        "true",
                        nameof(IIdentity.Name),
                        nameof(IAntiforgeryAdditionalDataProvider),
                        nameof(DefaultAntiforgeryAdditionalDataProvider)));
            }

            // the object that contains all parts needs to create the final CSRF token
            return requestToken;
        }

        /// <inheritdoc />
        // only checks that CSRF cookie is not null and that isCookieToken=true. (set above by GenerateCookieToken())
        public bool IsCookieTokenValid(AntiforgeryToken cookieToken)
        {
            return cookieToken != null && cookieToken.IsCookieToken;
        }

        /// <inheritdoc />
        
        //this function will perform the CSRF verification
        public bool TryValidateTokenSet(
            HttpContext httpContext,
            AntiforgeryToken cookieToken,
            AntiforgeryToken requestToken,
            out string message)
        {
            if (httpContext == null)
            {
                throw new ArgumentNullException(nameof(httpContext));
            }

            // if the CSRF cookie is missing in the request, the CSRF verification will thrown an error 
            if (cookieToken == null)
            {
                throw new ArgumentNullException(
                    nameof(cookieToken),
                    Resources.Antiforgery_CookieToken_MustBeProvided_Generic);
            }

            // if the CSRF token is missing in the request's body, the CSRF verification will thrown an error 
            if (requestToken == null)
            {
                throw new ArgumentNullException(
                    nameof(requestToken),
                    Resources.Antiforgery_RequestToken_MustBeProvided_Generic);
            }

            // Do the tokens have the correct format?
            // I.e. it ensures that the CSRF cookie is not swapped somehow with the CSRF token
            if (!cookieToken.IsCookieToken || requestToken.IsCookieToken)
            {
                message = Resources.AntiforgeryToken_TokensSwapped;
                return false;
            }

            /* Are the security tokens embedded in each incoming token identical? It compares the random token in the csrf cookie against the random token within the CSRF token.
               It is a secure comparison that compares the values in constant time.
               cookieToken.SecurityToken is of type BinaryBlob and in this class the Equals() method is overriden to be constant-time.
               According to C# documentation: "This means that if objA overrides the Object.Equals(Object) method, this override is called." obj.Equals(objA, obj B) */
            if (!object.Equals(cookieToken.SecurityToken, requestToken.SecurityToken))
            {
                message = Resources.AntiforgeryToken_SecurityTokenMismatch;
                return false;
            }

            // Is the incoming token meant for the current user?
            var currentUsername = string.Empty;
            BinaryBlob currentClaimUid = null;

            // gets the identity of the currently logged in user
            var authenticatedIdentity = GetAuthenticatedIdentity(httpContext.User);
            if (authenticatedIdentity != null)
            {
                currentClaimUid = GetClaimUidBlob(_claimUidExtractor.ExtractClaimUid(httpContext.User));
                // if no claimUid is found, it will get the username of the authenticated user
                if (currentClaimUid == null)
                {
                    currentUsername = authenticatedIdentity.Name ?? string.Empty;
                }
            }

            // OpenID and other similar authentication schemes use URIs for the username.
            // These should be treated as case-sensitive.
            var comparer = StringComparer.OrdinalIgnoreCase;
            if (currentUsername.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                currentUsername.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                comparer = StringComparer.Ordinal;
            }

            // checks whether the username in the CSRF token matches the username of the currently authenticated user
            // if both are null (e.g. not authenticated or because ClaimUid is used instead) this will return true and check ClaimUid below
            if (!comparer.Equals(requestToken.Username, currentUsername))
            {
                message = Resources.FormatAntiforgeryToken_UsernameMismatch(requestToken.Username, currentUsername);
                return false;
            }

            // checks whether the ClaimUid in the CSRF token matches the username of the currently authenticated user
            if (!object.Equals(requestToken.ClaimUid, currentClaimUid))
            {
                message = Resources.AntiforgeryToken_ClaimUidMismatch;
                return false;
            }

            // Is the AdditionalData valid? If provided, ValidateAdditionalData() will be called with the additional data embedded in the CSRF token.
            if (_additionalDataProvider != null &&
                !_additionalDataProvider.ValidateAdditionalData(httpContext, requestToken.AdditionalData))
            {
                message = Resources.AntiforgeryToken_AdditionalDataCheckFailed;
                return false;
            }
 
            // otherwise no additional data was specified or the validation was successful
            message = null;
            return true;
        }

        // returns a 32-byte claimUid 
        private static BinaryBlob GetClaimUidBlob(string base64ClaimUid)
        {
            if (base64ClaimUid == null)
            {
                return null;
            }

            return new BinaryBlob(256, Convert.FromBase64String(base64ClaimUid));
        }

        // used during CSRF verification to retrieve the identiy provider that is used. This will then help get the ClaimUid
        private static ClaimsIdentity GetAuthenticatedIdentity(ClaimsPrincipal claimsPrincipal)
        {
            if (claimsPrincipal == null)
            {
                return null;
            }

            var identitiesList = claimsPrincipal.Identities as List<ClaimsIdentity>;
            if (identitiesList != null)
            {
                for (var i = 0; i < identitiesList.Count; i++)
                {
                    if (identitiesList[i].IsAuthenticated)
                    {
                        return identitiesList[i];
                    }
                }
            }
            else
            {
                foreach (var identity in claimsPrincipal.Identities)
                {
                    if (identity.IsAuthenticated)
                    {
                        return identity;
                    }
                }
            }

            return null;
        }
    }
}