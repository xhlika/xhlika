// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.


// THIS CLASS ALLOWS THE DEVELOPER TO CUSTOMIZE WHAT IS STORED IN THE CSRF TOKEN IN ADDITION TO USERNAME OR CLAIM_UID.
// THIS CAN BE USED E.G. TO ADD A CRYPTOGRAPHIC NONCE OR TIMESTAMP TO PREVENT REPLAY ATTACKS. IN MOST FRAMEWORKS TOKENS CAN'T BE CUSTOMIZED.
// SEE: https://github.com/dotnet/aspnetcore/blob/master/src/Antiforgery/src/IAntiforgeryAdditionalDataProvider.cs
using Microsoft.AspNetCore.Http;

namespace Microsoft.AspNetCore.Antiforgery
{
    /// <summary>
    /// A default <see cref="IAntiforgeryAdditionalDataProvider"/> implementation.
    /// </summary>
    
// The GetAdditionalData method is called each time a field token is generated and the add_data is embedded within the generated token. 
// It could return a timestamp, a nonce or any other user value, e.g. to prevent Replay attacks.  Or make it harder to do cookie tossing  e.g. in login CSRF, since no username is added in the CSRF token.
// The client's username is already embedded in the generated tokens in all other cases, so there's no need to include this information.
    internal class DefaultAntiforgeryAdditionalDataProvider : IAntiforgeryAdditionalDataProvider
    {
        /// <inheritdoc />
        public string GetAdditionalData(HttpContext context)
        {
            return string.Empty; // by default, no additional data is added, unless the developer calls this method and provide his own
        }

        /// <inheritdoc />
        // called to validate the additional data provided by the developer when the token is validated. 
        public bool ValidateAdditionalData(HttpContext context, string additionalData)
        {
            // Default implementation does not understand anything but empty data.
            return string.IsNullOrEmpty(additionalData); // by default, no GetAdditionalData() is specified, so nothing to validate.
        }                                                // If the developer adds additional data,then  he should also implement this function for validation
    }                                                    // This function will be called during the CSRF verification
}