// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.


   
// THIS CLASS HANDLES THE ENCRYPTION+SIGNING AND DECRYPTION+UNSIGNING OF THE CSRF TOKEN

using System.Reflection;
using System.Web.Security;

namespace System.Web.Helpers.AntiXsrf
{
    // Interfaces with the System.Web.MachineKey static class using the 4.5 Protect / Unprotect methods.
    // https://github.com/aspnet/AspNetWebStack/blob/master/src/System.Web.WebPages/Helpers/AntiXsrf/ICryptoSystem.cs 
    internal sealed class MachineKey45CryptoSystem : ICryptoSystem
    {
        private static readonly string[] _purposes = new string[] { "System.Web.Helpers.AntiXsrf.AntiForgeryToken.v1" };
        private static readonly MachineKey45CryptoSystem _singletonInstance = GetSingletonInstance();

        public static MachineKey45CryptoSystem Instance
        {
            get
            {
                return _singletonInstance;
            }
        }

        private static MachineKey45CryptoSystem GetSingletonInstance()
        {
            return new MachineKey45CryptoSystem();
        }

        // function to encrypt+HMAC-SHA256 some plaintext data. The ciphertext is then encoded to URL-compatible base64.
        // If invoked directly by developer, a string called "_Purposes" can be applied to distinguish e.g. between different applications
        public string Protect(byte[] data)
        {
            byte[] rawProtectedBytes = MachineKey.Protect(data, _purposes);
            return HttpServerUtility.UrlTokenEncode(rawProtectedBytes);
        }

        // function to unsign and decrypt some ciphertext data.
        // The ciphertest is first decoded and then unsigned + decrypted.
        public byte[] Unprotect(string protectedData)
        {
            byte[] rawProtectedBytes = HttpServerUtility.UrlTokenDecode(protectedData);
            return MachineKey.Unprotect(rawProtectedBytes, _purposes);
        }
    }
}