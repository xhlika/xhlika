// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.


// THIS CLASS IS RESPONSIBLE FOR SERIALIZING AND DESERIALIZING THE CSRF TOKEN. I.E. IT USES THE token OBJECT FROM AntiForgeryToken CLASS AND BUILDS THE CSRF TOKEN BY PUTTING PIECES TOGETHER
// (BASE TOKEN, CLAIMUID/USERNAME, ADDITTIONAL_DATA) AND THEN CALLS THE RESPONSIBLE FUNCTIONS TO ENCRYPT AND SIGN THE CSRF TOKEN. THE DESERIALIZER DOES THE INVERSE PROCESS.
using System.Diagnostics.CodeAnalysis;
using System.Diagnostics.Contracts;
using System.IO;
using System.Web.Mvc;

namespace System.Web.Helpers.AntiXsrf
{

    internal sealed class AntiForgeryTokenSerializer : IAntiForgeryTokenSerializer
    {
        private const byte TokenVersion = 0x01;
        private readonly ICryptoSystem _cryptoSystem;

        internal AntiForgeryTokenSerializer(ICryptoSystem cryptoSystem)
        {
            _cryptoSystem = cryptoSystem;
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Failures are homogenized; caller handles appropriately.")]
        [SuppressMessage("Microsoft.Usage", "CA2202:Do not dispose objects multiple times", Justification = "MemoryStream is safe for multi-dispose.")]
        // deserializes the encrypted final CSRF token so that its data can be extracted and used during the CSRF verification.
        // It returns an object with the "pieces" of the CSRF token
        public AntiForgeryToken Deserialize(string serializedToken)
        {
            try
            {
                // decrypts (and un-HMACs) the encrypted (and base64ed) CSRF Token.
                // In ASP.NET Core this API only handles the decryption and the decoding is done separately after this API is invoked
                using (MemoryStream stream = new MemoryStream(_cryptoSystem.Unprotect(serializedToken)))
                {
                    using (BinaryReader reader = new BinaryReader(stream))
                    {
                        //  deserializes the decrypted final CSRF token so that its data can be extracted and used during the CSRF verification
                        AntiForgeryToken token = DeserializeImpl(reader);
                        if (token != null)
                        {
                            return token;
                        }
                    }
                }
            }
            catch
            {
                // swallow all exceptions - homogenize error if something went wrong
            }

            // if we reached this point, something went wrong deserializing
            throw HttpAntiForgeryException.CreateDeserializationFailedException();
        }

        /* The serialized format of the anti-XSRF token is as follows:
         * Version: 1 byte integer   (1)
         * SecurityToken: 16 byte binary blob (2)
         * IsSessionToken: 1 byte Boolean     (3) 
         * [if IsSessionToken = true] 
         *   +- IsClaimsBased: 1 byte Boolean  (4)
         *   |  [if IsClaimsBased = true]
         *   |    `- ClaimUid: 32 byte binary blob  (5a)
         *   |  [if IsClaimsBased = false]
         *   |    `- Username: UTF-8 string with 7-bit integer length prefix (5b)
         *   `- AdditionalData: UTF-8 string with 7-bit integer length prefix (6)
         */
         
        /* deserializes the decrypted final CSRF token so that its data can be extracted and used during the CSRF verification.
           Note: ASP.NET's documentation has the wrong belief that the CSRF defense implemented here is a variation of Synchronizer Token Pattern (Plain Token)
           and the boolean attribute is called "IsSessionToken". This was fixed in ASP.NET Core where the property is renamed to "IsCookieToken" and the documentation 
           rightfully refers to the mechanism as Double Submit. */
        private static AntiForgeryToken DeserializeImpl(BinaryReader reader)
        {
            // we can only consume tokens of the same serialized version that we generate.
            // Retrieves the version (1)
            byte embeddedVersion = reader.ReadByte(); // 0x01
            if (embeddedVersion != TokenVersion)
            {
                return null;
            }
            // creates a CSRF token object (with properties like username, random token, etc.)
            AntiForgeryToken deserializedToken = new AntiForgeryToken();
            // retrieves the 16 bytes of the random token (2)
            byte[] securityTokenBytes = reader.ReadBytes(AntiForgeryToken.SecurityTokenBitLength / 8);
            // Generates a token using an existing binary value. I.e. the random token is turned into a string, ready for comparison.
            // Check the corresponding constructor in BinaryBlob class for more information.
            deserializedToken.SecurityToken = new BinaryBlob(AntiForgeryToken.SecurityTokenBitLength, securityTokenBytes);
            // retrieves the boolean property that distinguishes the CSRF token from the CSRF cookie (3)
            deserializedToken.IsSessionToken = reader.ReadBoolean();

            // if it is a CSRF token (and not a cookie)
            if (!deserializedToken.IsSessionToken)
            {
                // retrieves 1 byte that determines if ClaimUid is used or username
                bool isClaimsBased = reader.ReadBoolean();
                // if isClaimsBased=true, then claimUid is used instead of the username, so next step is to extract 32 bytes
                if (isClaimsBased)
                {
                    // extract 32 bytes of the claimUid from the CSRF token (5a)
                    byte[] claimUidBytes = reader.ReadBytes(AntiForgeryToken.ClaimUidBitLength / 8);
                    // convert bytes into string
                    deserializedToken.ClaimUid = new BinaryBlob(AntiForgeryToken.ClaimUidBitLength, claimUidBytes);
                }
                else
                {
                    // otherwise extract the string of the username from the CSRF token (5b)
                    deserializedToken.Username = reader.ReadString();
                }
               // extract the additional data (if specified) from the CSRF token 
               // This is an indicator that the csrf token is tampered with, i.e. providing more data then expected
                deserializedToken.AdditionalData = reader.ReadString();
            }

            // if there's still unconsumed data in the stream, fail
            if (reader.BaseStream.ReadByte() != -1)
            {
                return null;
            }

            // success
           // returns an AntiforgeryToken object containing all pieces of the CSRF token.
            return deserializedToken;
        }

        [SuppressMessage("Microsoft.Usage", "CA2202:Do not dispose objects multiple times", Justification = "MemoryStream is safe for multi-dispose.")]
        /* serializes the CSRF token by putting token pieces together. This is used for both the CSRF token and for the CSRF cookie. Both of them are serialized and encrypted. 
           The only difference is that the CSRF token has additional information such as username/claimUid, additional data,etc. Whether this is a csrf token or cookie is decided by 
           IsSessionToken attribute.Token is an object containing all necessary fields to generate the final CSRF token(generated random token, username/claimUid, etc). See AntiforgeryToken class for more.  */
        public string Serialize(AntiForgeryToken token)
        {
            Contract.Assert(token != null);

            using (MemoryStream stream = new MemoryStream())
            {
                using (BinaryWriter writer = new BinaryWriter(stream))
                {
                    writer.Write(TokenVersion); // this is the first byte that shows the version (1)
                    writer.Write(token.SecurityToken.GetData()); // the random token (2)
                    writer.Write(token.IsSessionToken); // the byte determining if it is a CSRF token or a CSRF cookie (3)

                    if (!token.IsSessionToken)
                    {
                        if (token.ClaimUid != null) // are we using claimUid or username?
                        {
                            writer.Write(true /* isClaimsBased */); // 1 byte that tells the value of ClaimUid (true in this case) (4)
                            writer.Write(token.ClaimUid.GetData()); // the 32 bytes of the claimUid (5a)
                        }
                        else
                        {   // when user is not authenticated, at AntiforgeryToken class the username is set to an empty string
                            writer.Write(false /* isClaimsBased */); // 1 byte that tells the value of ClaimUid (false in this case) (4)
                            writer.Write(token.Username); // otherwise the string of the username (5b)
                        }

                        writer.Write(token.AdditionalData); // if specified, the additional data is added at the end of the CSRF token (6)
                    }

                    writer.Flush();
                    // the CSRF token/cookie is encrypted and HMACed, then encoded to base64
                    // in ASP.NET Core Protect() only encrypts some data and the encoding is done after Protect()
                    // in the class where this API is called.
                    return _cryptoSystem.Protect(stream.ToArray());
                }
            }
        }
    }
}