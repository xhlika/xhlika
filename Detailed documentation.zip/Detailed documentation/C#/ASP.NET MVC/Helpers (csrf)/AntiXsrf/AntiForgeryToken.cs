// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.



// THIS CLASS THAT CREATES THE "TOKEN" OBJECT (WITH THE RANDOM TOKEN, CLAIMUID/USERNAME AND ADDITIONAL DATA AS PROPERTIES) THAT IS USED IN MULTIPLE PLACES IN THE ANTI-CSRF MECHANISM, E.G. ON VERIFICATION.
// CREATING AN OBJECT OF THIS CLASS WILL MAKE THE BinaryBlob CLASS TO GENERATE THE RANDOM BASE TOKEN (SecurityToken PROPERTY).
namespace System.Web.Helpers.AntiXsrf
{
    // Represents the security token for the Anti-XSRF system.
    // The token is a random 128-bit value that correlates the session with the request body.
    internal sealed class AntiForgeryToken
    {
        internal const int SecurityTokenBitLength = 128; // the generated random token itself is 16 bytes.
        internal const int ClaimUidBitLength = 256;      // if claimUid is used instead of username, then it is 32 bytes.

        private string _additionalData = string.Empty;  // by default no other additional data is added in the token.
        private string _username = string.Empty;        // by default username is set to null (e.g. before auth, there is no username)
        private BinaryBlob _securityToken;              // this class will handle to random token generation.

        // the additional data to be added to the final CSRF token.
        // If developer did not specify anything, this will be an empty string.
        public string AdditionalData
        {
            get
            {
                return _additionalData  String.Empty;
            }
            set
            {
                _additionalData = value;
            }
        }

        public BinaryBlob ClaimUid { get; set; }

        public bool IsSessionToken { get; set; }


        // this will generate the random part of the CSRF token (random_part||claim_uid/username = final CSRF token)
        // This base token is a per-session value, while the final CSRF token is changed in each request to prevent BREACH
        public BinaryBlob SecurityToken
        {
            get
            {
                // calling this specific constructor of BinaryBlob class generates a new base token using a specified bit length (16 bytes).
                // Check BinaryBlob class for generation details.
                if (_securityToken == null)
                {
                    _securityToken = new BinaryBlob(SecurityTokenBitLength);
                }
                 // if the random token was already generated, it will be re-used (since it is per-session).
                // This can be retrieved from the CSRF cookie which only stores this random token and no additional info (username, uid, etc)
                return _securityToken;
            }
            set
            {
                _securityToken = value;
            }
        }

        // if a username exists (i.e. user is already authenticated), then it will be added to the CSRF token, otherwise it is an empty string.
        // This can happen before user is authenticated, e.g. at login page.
        public string Username
        {
            get
            {
                return _username  String.Empty;
            }
            set
            {
                _username = value;
            }
        }
    }
}