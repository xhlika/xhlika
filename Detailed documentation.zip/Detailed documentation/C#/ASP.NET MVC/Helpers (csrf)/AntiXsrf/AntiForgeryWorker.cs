// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.


// THIS CSRF WORKS IS USED BY AntiForgery.cs CLASS TO ADD CSRF TOKEN TO THE FORM (GetFormInputElement()) AND PERFORMS THE TOKEN VERIFICATION (Validate()). FOR BOTH THESE TASKS, IT CALLS THE RESPONSIBLE
// FUNCTIONS IN OTHER CLASSES. ADDITIONALLY, THIS CLASS PROVIDES OTHER FUNCTIONS FOR LOCAL CSRF DEFENSE IN SPECIFIC ROUTES (E.G. SEE GetTokens())
using System.Diagnostics.CodeAnalysis;
using System.Diagnostics.Contracts;
using System.Security.Principal;
using System.Web.Mvc;
using System.Web.WebPages.Resources;

namespace System.Web.Helpers.AntiXsrf
{
    internal sealed class AntiForgeryWorker
    {
        private readonly IAntiForgeryConfig _config;
        private readonly IAntiForgeryTokenSerializer _serializer;
        private readonly ITokenStore _tokenStore;
        private readonly ITokenValidator _validator;

        internal AntiForgeryWorker(IAntiForgeryTokenSerializer serializer, IAntiForgeryConfig config, ITokenStore tokenStore, ITokenValidator validator)
        {
            _serializer = serializer;
            _config = config;
            _tokenStore = tokenStore;
            _validator = validator;
        }

        private void CheckSSLConfig(HttpContextBase httpContext)
        {
            if (_config.RequireSSL && !httpContext.Request.IsSecureConnection)
            {
                throw new InvalidOperationException(WebPageResources.AntiForgeryWorker_RequireSSL);
            }
        }

        private AntiForgeryToken DeserializeToken(string serializedToken)
        {
            return (!String.IsNullOrEmpty(serializedToken))
                ? _serializer.Deserialize(serializedToken)
                : null;
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Caller will just regenerate token in case of failure.")]
        private AntiForgeryToken DeserializeTokenNoThrow(string serializedToken)
        {
            try
            {
                return DeserializeToken(serializedToken);
            }
            catch
            {
                // ignore failures since we'll just generate a new token
                return null;
            }
        }

        private static IIdentity ExtractIdentity(HttpContextBase httpContext)
        {
            if (httpContext != null)
            {
                IPrincipal user = httpContext.User;
                if (user != null)
                {
                    return user.Identity;
                }
            }
            return null;
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Caller will just regenerate token in case of failure.")]
        // tries to extract the CSRF cookie from the request. If not found, it returns null which will trigger a new cookie generation below
        private AntiForgeryToken GetCookieTokenNoThrow(HttpContextBase httpContext)
        {
            try
            {
                return _tokenStore.GetCookieToken(httpContext);
            }
            catch
            {
                // ignore failures since we'll just generate a new token
                return null;
            }
        }

        // [ ENTRY POINT ]
        // Generates an anti-XSRF token pair for the current user. The return
        // value is the hidden input form element that should be rendered in
        // the <form>. This method has a side effect: it may set a response
        // cookie.
        
        // this is the main function that will trigger token generation and set the CSRF cookie+token
        public TagBuilder GetFormInputElement(HttpContextBase httpContext)
        {
            CheckSSLConfig(httpContext);
            // will try to find a CSRF cookie in the request. It will not throw if nothign is found, since a new cookie will be generated
            AntiForgeryToken oldCookieToken = GetCookieTokenNoThrow(httpContext);
            AntiForgeryToken newCookieToken, formToken;
            // check below the second GetTokens() function. 
            GetTokens(httpContext, oldCookieToken, out newCookieToken, out formToken);

            // if GetTokens() was set to non-null, it means no CSRF cookie came with the request (or was invalid) and a new is generated
            // non-null--> newCookieToken will hold the newly generated random token.
            if (newCookieToken != null)
            {
                // If a new cookie was generated, persist it.
                // The function will create and set a CSRF cookie in the response.
                _tokenStore.SaveCookieToken(httpContext, newCookieToken);
            }
            
            // by default when CSRF protection is enabled, X-Frame-Options headers is also set to prevent ClickJacking
            // unless the developer configures SuppressXFrameOptionsHeader=true to prevent this
            if (!_config.SuppressXFrameOptionsHeader)
            {
                // Adding X-Frame-Options header to prevent ClickJacking. See
                // http://tools.ietf.org/html/draft-ietf-websec-x-frame-options-10
                // for more information.
                const string FrameHeaderName = "X-Frame-Options";
                if (httpContext.Response.Headers[FrameHeaderName] == null)
                {
                    httpContext.Response.AddHeader(FrameHeaderName, "SAMEORIGIN");
                }
            }

            // <input type="hidden" name="__AntiForgeryToken" value="..." />
            
            // this will create the <input> HTML tag that places the csrf token in a hidden form field. 
            TagBuilder retVal = new TagBuilder("input");
            retVal.Attributes["type"] = "hidden";
            retVal.Attributes["name"] = _config.FormFieldName;
            // formToken is the random token. Serialize() will put pieces together to create the final CSRF token,  then this final CSRF token is encrypted+HMACed+base64_encoded
            retVal.Attributes["value"] = _serializer.Serialize(formToken);
            return retVal;
        }

        // [ ENTRY POINT ]
        // Generates a (cookie, form) serialized token pair for the current user.
        // The caller may specify an existing cookie value if one exists. If the
        // 'new cookie value' out param is non-null, the caller *must* persist
        // the new value to cookie storage since the original value was null or
        // invalid. This method is side-effect free.
        
        // it is called in AntiForgery's class GetTokens() function. Developers can call it to retrieve a serialized CSRF token and Cookie.
        // They have to take care of adding these in the HTML form and (the cookie) in the response themselves.
        public void GetTokens(HttpContextBase httpContext, string serializedOldCookieToken, out string serializedNewCookieToken, out string serializedFormToken)
        {
            CheckSSLConfig(httpContext);

            AntiForgeryToken oldCookieToken = DeserializeTokenNoThrow(serializedOldCookieToken);
            AntiForgeryToken newCookieToken, formToken;
            GetTokens(httpContext, oldCookieToken, out newCookieToken, out formToken);

            serializedNewCookieToken = Serialize(newCookieToken);
            serializedFormToken = Serialize(formToken);
        }

        // this function will check if the CSRF cookie is present and not tampered with. If yes, it will use its value to generate the CSRF token that is placed in the form field.
        // If cookie was missing or incorrect, a new one is generated and now newCookieToken holds a non-null value.
        // When GetTokens() returns with such a newCookieToken, GetFormInputElement() will create a new CSRF cookie with the new random token
        private void GetTokens(HttpContextBase httpContext, AntiForgeryToken oldCookieToken, out AntiForgeryToken newCookieToken, out AntiForgeryToken formToken)
        {
            newCookieToken = null;
            if (!_validator.IsCookieTokenValid(oldCookieToken))
            {
                // Need to make sure we're always operating with a good cookie token. 
                // If the cookie is missing/invalid, a new one is created using GenerateCookieToken() function of TokenValidator class
                oldCookieToken = newCookieToken = _validator.GenerateCookieToken();
            }

            Contract.Assert(_validator.IsCookieTokenValid(oldCookieToken));
            // if the CSRF cookie existed and was correct, its value will be used to generate the CSRF token. If it is incorrect, a new random token is created which is used to generate the CSRF token
            // A new  random token is created using GenerateFormToken() function of TokenValidator class. I.e. in both cases the token will be generated either from the cookie or from a fresh random value.
            formToken = _validator.GenerateFormToken(httpContext, ExtractIdentity(httpContext), oldCookieToken);
        }

        // this function calls the Serialize() function in AntiForgeryTokenSerializer class to put CSRF token "pieces" together  and then perform crypto operations on it.
        private string Serialize(AntiForgeryToken token)
        {
            return (token != null) ? _serializer.Serialize(token) : null;
        }

        // [ ENTRY POINT ]
        // Given an HttpContext, validates that the anti-XSRF tokens contained
        // in the cookies & form are OK for this request.
        
        // this function handles the CSRF verification
        public void Validate(HttpContextBase httpContext)
        {
            CheckSSLConfig(httpContext);

            // Extract cookie & form tokens from the request (and deserializes them)
            // it uses the corresponding functions from AntiForgeryTokenStore class
            AntiForgeryToken cookieToken = _tokenStore.GetCookieToken(httpContext);
            AntiForgeryToken formToken = _tokenStore.GetFormToken(httpContext);

            // Validate
            // It uses the ValidateTokens() function in TokenValidator class to actually perform the verification.
            _validator.ValidateTokens(httpContext, ExtractIdentity(httpContext), cookieToken, formToken);
        }

        // [ ENTRY POINT ]
        // Given the serialized string representations of a cookie & form token,
        // validates that the pair is OK for this request.
        
        // USED BY DEVELOPERS TO PERFORM VERIFICATION THEMSELVES. This is an alternative to the above Validate() function.
        // Instead of getting the request as parameter, it gets the CSRF token and CSRF cookie.
        // Both values will be deserialized, and then, same as above, ValidateTokens() function of TokenValidator class is called.        
        public void Validate(HttpContextBase httpContext, string cookieToken, string formToken)
        {
            CheckSSLConfig(httpContext);

            // Extract cookie & form tokens
            AntiForgeryToken deserializedCookieToken = DeserializeToken(cookieToken);
            AntiForgeryToken deserializedFormToken = DeserializeToken(formToken);

            // Validate
            _validator.ValidateTokens(httpContext, ExtractIdentity(httpContext), deserializedCookieToken, deserializedFormToken);
        }
    }
}