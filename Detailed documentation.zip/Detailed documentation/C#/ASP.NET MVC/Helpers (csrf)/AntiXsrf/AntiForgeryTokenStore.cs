// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.


// THIS IS THE SOUCE CODE THAT IS RESPONSIBLE FOR GETTING THE CSRF TOKEN FROM THE COOKIE AND FROM THE HTML FORM (IN THE REQUEST). ADDITIONALLY IT ALSO CREATES THE CSRF COOKIE (
// (SINCE MECHANISM IS DOUBLE SUBMIT)
using System.Diagnostics.CodeAnalysis;
using System.Diagnostics.Contracts;
using System.Web.Mvc;

namespace System.Web.Helpers.AntiXsrf
{
    // Saves anti-XSRF tokens split between HttpRequest.Cookies and HttpRequest.Form
    // https://github.com/aspnet/AspNetWebStack/blob/master/src/System.Web.WebPages/Helpers/AntiXsrf/ITokenStore.cs
    internal sealed class AntiForgeryTokenStore : ITokenStore
    {
        private readonly IAntiForgeryConfig _config;
        private readonly IAntiForgeryTokenSerializer _serializer;

        internal AntiForgeryTokenStore(IAntiForgeryConfig config, IAntiForgeryTokenSerializer serializer)
        {
            _config = config;
            _serializer = serializer;
        }

        // it will retrieve the CSRF cookie from the request.
        // If a CSRF cookie is found, it is deserialized (decoded and decrypted), i.e. it return the decrypted random token stored in cookie.
        // If no cookie is found, this function will return null which at a later point will trigger a token generation
        public AntiForgeryToken GetCookieToken(HttpContextBase httpContext)
        {
            HttpCookie cookie = httpContext.Request.Cookies[_config.CookieName];
            if (cookie == null || String.IsNullOrEmpty(cookie.Value))
            {
                // did not exist
                return null;
            }

            return _serializer.Deserialize(cookie.Value);
        }

        // retrieves the CSRF token from the request's body (and not from a custom header).
        // If a token is found, it is decoded and decrypted.
        // Otherwise it returns null; no token found in the body.
        public AntiForgeryToken GetFormToken(HttpContextBase httpContext)
        {
            string value = httpContext.Request.Form[_config.FormFieldName];
            if (String.IsNullOrEmpty(value))
            {
                // did not exist
                return null;
            }

            return _serializer.Deserialize(value);
        }

        // this function creates the CSRF cookie that is attached to the response.
        // The random token is first serialized (pieces are put together, then enryption+hmac+base_64 encode is performed)
        // the resulting value is placed on the CSRF cookie.
        public void SaveCookieToken(HttpContextBase httpContext, AntiForgeryToken token)
        {
            string serializedToken = _serializer.Serialize(token);
            HttpCookie newCookie = new HttpCookie(_config.CookieName, serializedToken)
            {
                HttpOnly = true // by default, this property is set to true. Samesite is not set however, like in ASP.NET Core.
            };

            // Note: don't use "newCookie.Secure = _config.RequireSSL;" since the default
            // value of newCookie.Secure is automatically populated from the <httpCookies>
            // config element.
            if (_config.RequireSSL)
            {
                newCookie.Secure = true;  // if HTTPS connections are configured, only then this property will be set.
            }

            httpContext.Response.Cookies.Set(newCookie);
        }
    }
}