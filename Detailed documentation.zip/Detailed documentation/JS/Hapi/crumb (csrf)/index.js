
/* CRUMB IS THE PACKAGE THAT PROVIDES THE CSRF DEFENSE FOR HAPI, SINCE HAPI ITSELF DOESN'T OFFER BUILT-IN DEFENSE FOR CSRF. MECHANISM IS DOUBLE SUBMIT COOKIE. 
   IT BECOMES SPECIAL VERSION (THE HYBRID) WHEN RESTFUL=TRUE. IN THIS CASE, CRUMB LOOKS FOR THE TOKEN IN REQUEST HEADER INSTEAD OF REQ BODY ("PAYLOAD").  */

'use strict';

const Stream = require('stream');

const Boom = require('@hapi/boom');
// this library does the generation of the token and the validation.
const Cryptiles = require('@hapi/cryptiles');
// the libraries below contain helper functions for handling stuff like errors, copying objects, checking data types, assert(), etc.
const Hoek = require('@hapi/hoek');
const Joi = require('@hapi/joi');

// when restful=true, these methods are to be considered by csrf, in other words: get, head, options are ignored.
const internals = {
    restfulValidatedMethods: ['post', 'put', 'patch', 'delete']
};

// makes sure that the above variables are of a certain datatype, seems like they try to make JS data-type aware.
// these are the options you use to configure csrf
internals.schema = Joi.object().keys({
    //key - the name of the cookie to store the csrf crumb into. Defaults to crumb.
    key: Joi.string().optional(),
    //size - the length of the crumb to generate. Defaults to 43 chars.
    size: Joi.number().optional(),
    //autoGenerate:  whether to automatically generate a new crumb for requests. Defaults to true.
    autoGenerate: Joi.boolean().optional(),
    //addToViewContext - whether to automatically add the crumb to view contexts as the given key (crumb). Defaults to true.
    addToViewContext: Joi.boolean().optional(),
    // cookieOptions- storage options for the cookie containing the crumb
    cookieOptions: Joi.object().keys(null),
    //headerName - specify the name of the custom CSRF header. Defaults to X-CSRF-Token.
    headerName: Joi.string().optional(),
    //restful - RESTful mode that validates crumb tokens from "X-CSRF-Token" request header
    //for POST, PUT, PATCH and DELETE server routes. Disables payload/query crumb validation. Defaults to false.
    restful: Joi.boolean().optional(),
    //skip- a function that is called for every request. If the provided function returns true, validation and generation of crumb is skipped. Defaults to false.
    skip: Joi.func().optional(),
    //enforce- defaults to true, using enforce with false will set the CSRF header cookie but won't execute the validation. Why use it then? 
    enforce: Joi.boolean().optional(),
    //logUnauthorized- whether to add to the request log with tag 'crumb' and data 'validation failed' (defaults to false)
    logUnauthorized: Joi.boolean().optional()
});

// these are the default values that are used in the dev does not specify anything else.
internals.defaults = {
    key: 'crumb',
    size: 43,                       // Equal to 256 bits
    autoGenerate: true,             // If false, must call request.plugins.crumb.generate() manually before usage
    addToViewContext: true,         // If response is a view, add crumb to context
    cookieOptions: {                // Cookie options (i.e. hapi server.state)
        path: '/'
    },
    headerName: 'X-CSRF-Token',     // Specify the name of the custom CSRF header
    restful: false,                 // Set to true for custom header crumb validation. Disables payload/query validation
    skip: false,                    // Set to a function which returns true when to skip crumb generation and validation,
    enforce: true,                  // Set to true for setting the CSRF cookie while not performing validation
    logUnauthorized: false          // Set to true for crumb to write an event to the request log
};

// crumb?
exports.plugin = {
    pkg: require('../package.json'),
    requirements: {
        hapi: '>=19.0.0'
    },

    // this is the function that is called to initiate the csrf middleware, kind of like the constructor
    register: function (server, options) {
         // checks that the options that dev specified are of correct type (internal.schema)
        Joi.assert(options, internals.schema);
        // similar to object.assign() in Express, creates a new object with all properties from defaults and options. 
        const settings = Hoek.applyToDefaults(internals.defaults, options);
        // if restful is false, the source where to check for the token will be the "payload" (which is how hapi calls request's body)
        const routeDefaults = {
            key: settings.key,
            restful: settings.restful,
            source: 'payload'
        };
    // "to use a cookie, you first need to configure it"-->hapi docs: https://hapi.dev/tutorials/cookies/?lang=en_US#user-content-server.state
    // settings.key tells the name of the cookie to be created, settings.cookieOptions is an object with cookie's attributes if developer has specified any,
    // otherwise defaults: ttl=null (delete when browser closes), Secure:true, HttpOnly:true, base64_encoded, path='/',  no sameSite.
        server.state(settings.key, settings.cookieOptions);

        server.ext('onPostAuth', (request, h) => {
                 // used for logging, is a function that is called below if there is an attempt of CSRF that was prevented.
            const unauthorizedLogger = () => {
                if (settings.logUnauthorized) {
                    request.log(['crumb', 'unauthorized'], 'validation failed');
                }
            };
            // returns the crumb value from the CSRF COOKIE (name is "crumb" by default).
            const getCrumbValue = () => {
                // crumb plugin is the one that handles the csrf token
                //this line accesses the request and gets the crumb cookie
                let crumbValue = request.plugins.crumb;
                // if multiple cookies with same name, it will retrieve the value of the first one: important for cookie tossing.
                if (Array.isArray(crumbValue)) {
                    request.log(['crumb'], 'multiple cookies found');
                    crumbValue = request.plugins.crumb[0];
                }

                return crumbValue;
            };

            // If skip() function is enabled, invoke it and if returns true, do not attempt to do anything with crumb
            // if developer specifies this, it is the same as saying csrf:false; there won't be a generation or verification process.
            if (settings.skip &&
                settings.skip(request, h)) {
                // same as next() in the rest of JS frameworks. I.e. moves to the next middleware.
                return h.continue;
            }

            // Get crumb settings for this route if crumb is enabled on route

            // there is the option of configuring csrf per route. 
            // _crumb is an object, but you can enable/disable csrf in a route using a boolean instead of the _crumb object
            if (request.route.settings.plugins._crumb === undefined) {
                // if the provided value is crumb:true
                if (request.route.settings.plugins.crumb ||
                    !request.route.settings.plugins.hasOwnProperty('crumb')) {
                    // creates the crumb object with the default values + specified config for that route (specified configuration overrides default values if conflict)
                    request.route.settings.plugins._crumb = Hoek.applyToDefaults(routeDefaults, request.route.settings.plugins.crumb || {});
                }
                else {  // otherwise _crumb=false, which is csrf:false for this route.
                    request.route.settings.plugins._crumb = false;
                }
            }

            /* checks the CORS config for this route.
               If CORS is not enabled for this route, or enabled returns true =(allowed req), it will allow the generation of the token. 
               Different from other frameworls, this one integrates CORS within CSRF. In other frameworks they are applied separately.
               In other frameworks the token is always generated, but browser will not allow the attacker to view the response and leak the CSRF token.
               request.route.settings.cors is an object when cors is activated globally, otherwise it is an object of what developer specified in the specific route.
               possible cases: (no cors || false) = gen, (no cors|| true) = gen,  (cors || false) = no gen, (cors || true) = gen */
            if (!request.route.settings.cors ||
                checkCORS(request)) {


                // at this point _crumb is either an object with attributes (which returns true) or a boolean (false)
                if (request.route.settings.plugins._crumb) {
                    // Read crumb value from cookie if crumb enabled for this route
                    request.plugins.crumb = request.state[settings.key];
                }

                // Generate crumb value if autoGenerate enabled (default:true) or crumb specifically enabled on route
                if (settings.autoGenerate ||
                    request.route.settings.plugins.crumb) {
                // function below that generates the csrf token by calling randomStrings()--> randomBits()--> random()-->crypto.randomBytes():sec
                // the function returns req.plugins.crumb will now hold the CSRF token.
                    generate(request, h);
                }
            }

            // Skip validation on dry run
            // default is true, so it will proceed below
            // if false, allows generation/setting cookie, but doesn't do validation. (weird)
            if (!settings.enforce) {
                return h.continue;
            }

            // Validate crumb
            // this is where the verification of the csrf token is done. If restful:true is specified (and not undefined) in _crumb object provided by developer
            // for this route, then restful=true. Otherwise settings.restful is by default false 
            const restful = request.route.settings.plugins._crumb ? request.route.settings.plugins._crumb.restful : settings.restful;
            // if true, it will check for the CSRF token in the custom header, and not in the request body
            if (restful) {
                // if the method is NOT(!) in the list of methods to be checks or _crumb=false (!_crumb=true) then continue. I.e. no CSRF check
                if (!internals.restfulValidatedMethods.includes(request.method) || !request.route.settings.plugins._crumb) {
                    return h.continue;
                }
                // retrieves the csrf token value from  X-CSRF-Token header (default name).
                const header = request.headers[settings.headerName.toLowerCase()];
                // if no header, then CSRF attempt--> request is blocked and logged (if logs are enabled)
                if (!header) {
                    unauthorizedLogger();
                    throw Boom.forbidden();
                }

                // if value in the header does not match the one in the cookie (getCrumbValue()), throw an error .            
                // Timing attacks on the comparison are possible.
                if (header !== getCrumbValue()) {
                    unauthorizedLogger();
                    throw Boom.forbidden();
                }
                // otherwise the verification was succesful; go on with execution of the req.
                return h.continue;
            }

            // Not restful (the default option), i.e. normal request. It only checks for POST requests, and not other unsafe request methods (DELETE, PUT, ETC.)
            // Core developer is not aware of the risk (since 2013): https://github.com/hapijs/crumb/issues/4
            // if _crumb=false (no CSRF here) or HTTP method is different from POST, then continue without doing a CSRF verification.           
            if (!request.route.settings.plugins._crumb ||
                request.method !== 'post') {

                return h.continue;
            }

            // source = payload at defaults above.
            const content = request[request.route.settings.plugins._crumb.source];
            // if no "payload" found, throw error.
            if (!content ||
                content instanceof Stream) {

                unauthorizedLogger();
                throw Boom.forbidden();
            }

            // checks the "payload" (body, url, or all???) for an element with name "crumb" (default name of the field where csrf token is)
            // Again, timing attacks on comparison are possible.
            if (content[request.route.settings.plugins._crumb.key] !== getCrumbValue()) {
                unauthorizedLogger();
                throw Boom.forbidden();
            }

            delete request[request.route.settings.plugins._crumb.source][request.route.settings.plugins._crumb.key];
            return h.continue;
        });
        
        
       // this is called before the server returns the response.If views are used to render HTML, the above code will ensure that token is availabe in the view context.
       // Developer has to specify {{crumb}} in the view in order for the csrf token to be added in the HTML. I.e. it is not done automatically
       // addToViewContext--> whether to automatically add the crumb to view contexts as the given key. Defaults to true.
        server.ext('onPreResponse', (request, h) => {

            // Add to view context
            const response = request.response;
            // addToViewContext=true, crumb enabled, _crumb is an object 
            if (settings.addToViewContext &&
                request.plugins.crumb &&
                request.route.settings.plugins._crumb &&
                !response.isBoom &&
                response.variety === 'view') {
                // add the crumb to the context of the view, context["crumb"]= csrf token.
                response.source.context = response.source.context || {};
                response.source.context[request.route.settings.plugins._crumb.key] = request.plugins.crumb;
            }

            return h.continue;
        });

        // it is used above before generating the token. If cors is enabled per route, it will generate the token. Only if this function returns true: allows origin
        // If CORS is false in this route, then this won't matter. Regardless of this function's result, the CSRF token will be generated.
        const checkCORS = function (request) {
             // if origin header is present, then check if the origin is allowed.
            if (request.headers.origin) {  //isOriginMatch: Cors.matchOrigin(this.headers.origin, this.route.settings.cors)
                return request.info.cors.isOriginMatch;
            }
        // if origin header is not present, then it will always return true.
            return true;
        };

        // generates the token, is called above 
        const generate = function (request, h) {
             // if no crumb is yet generated, generate it.
             // It checks this on the cookie. When request comes, check if it has the crumb cookie. If the cookie is present in the request, it won't generate a new one.
            if (!request.plugins.crumb) {
                // generates the CSRF token
                const crumb = Cryptiles.randomString(settings.size);
                // sets the cookie with the default name "crumb", value=csrf token, and specified cookie options by developer. if not specified, it uses the defaults.
                // hapi has built-in functions for cookie parsing, doesn't use external packages like other frameworks. Cookies are not signed.
                // https://hapi.dev/tutorials/cookies/?lang=en_US#user-content-server.state
                h.state(settings.key, crumb, settings.cookieOptions);
                // passes the csrf token to req.plugin.crumb. This is the one that is given to the view as well (above)
                request.plugins.crumb = crumb;
            }
             // then is already generated and it returns the crumb cookie, which holds the csrf token in it.
             // it is base-64 encoded string and some chars are replaced to be url-friendly.
            return request.plugins.crumb;
        };
        // can be used in serve-side when auto-generate is false: if false, developer must call request.plugins.crumb.generate() manually before usage
        server.expose({ generate });
    }
};