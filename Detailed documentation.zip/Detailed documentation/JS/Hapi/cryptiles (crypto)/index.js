'use strict';

// HAPI USES THE CRYPTO LIBRARY TO GENERATE RNADOM TOKENS, LIKE ALL OTHER NODE JS WEB FRAMEWORKS WE HAVE SEEN.
const Crypto = require('crypto');

const Boom = require('@hapi/boom');


const internals = {};


/* Generate a cryptographically strong pseudo-random data
   This is the function that is called to generate the CSRF token.
   The size in characters is passed as parameter and randomBits() is called. This function will turn the size in bytes and call random() 
   which will use crypto.randombytes(). It default is 43 characters  */
exports.randomString = function (size) {

    // the resulting bytes (in a buffer) are turned into base64 encoded and url-friendly version
    const buffer = exports.randomBits((size + 1) * 6);
    const string = buffer.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/\=/g, '');
    return string.slice(0, size);
};


// Return a random string of digits.
// It uses the random(), which uses crypto.randombytes() as well.
exports.randomDigits = function (size) {

    const digits = [];

    let buffer = internals.random(size * 2);            // Provision twice the amount of bytes needed to increase chance of single pass
    let pos = 0;

    while (digits.length < size) {
        if (pos >= buffer.length) {
            buffer = internals.random(size * 2);
            pos = 0;
        }

        if (buffer[pos] < 250) {
            digits.push(buffer[pos] % 10);
        }

        ++pos;
    }

    return digits.join('');
};


// Generate a buffer of random bits.
// random(bytes) calls the crypto.randomBytes() that is defined
exports.randomBits = function (bits) {

    if (!bits ||
        bits < 0) {

        throw Boom.internal('Invalid random bits count');
    }
// it just turns the bits into bytes, since random() (which uses rypto.randombytes()) expects bytes.
    const bytes = Math.ceil(bits / 8);
    return internals.random(bytes);
};



// protects against timing attacks on comparison
exports.fixedTimeComparison = function (a, b) {

    try {
        return Crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
    }
    catch (err) {
        return false;
    }
};


// only this function generates random token. You pass the number of bytes as argument. By default it is 43 chars = 43 bytes. This implies 256 bits of entropy. 
// This functions is used internally, other functions above exports.x and can be used in other files, e.g. when generating the token.
internals.random = function (bytes) {

    try {// same as all other frameworks. it will return a buffer with the random bytes, which is used as CSRF token.
        return Crypto.randomBytes(bytes);
    }
    catch (err) {
        throw Boom.internal('Failed generating random bits: ' + err.message);
    }
};