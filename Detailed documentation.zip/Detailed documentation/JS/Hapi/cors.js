
// CORS MIDDLEWARE IN HAPI. IT DOES NOT SET CREDENTIALS TO TRUE, SO IT CONSIDERED RELATIVELY SAFE. SEE BELOW.

'use strict';

const Boom = require('@hapi/boom');
const Hoek = require('@hapi/hoek');

let Route = null;                           // Delayed load due to circular dependency


const internals = {};


exports.route = function (options) {
    // if nothing is specified, (true/false) etc, then do nth since CORS is not enabled.
    if (!options) {
        return false;
    }

    // otherwise settings now holds what dev has specified.
    const settings = Hoek.clone(options);
    settings._headers = settings.headers.concat(settings.additionalHeaders);
    settings._headersString = settings._headers.join(',');
    for (let i = 0; i < settings._headers.length; ++i) {
        settings._headers[i] = settings._headers[i].toLowerCase();
    }

    if (settings._headers.indexOf('origin') === -1) {
        settings._headers.push('origin');
    }

    settings._exposedHeaders = settings.exposedHeaders.concat(settings.additionalExposedHeaders).join(',');
    // disables cors, any origin header that comes is ignored, i.e. is '*'.
    if (settings.origin === 'ignore') {
        settings._origin = false;
    }
    // use only 1 specification it means that you cannot specify both * and an array. They are separated below. *=wildcards, array to qualified.
    else if (settings.origin.indexOf('*') !== -1) {
        Hoek.assert(settings.origin.length === 1, 'Cannot specify cors.origin * together with other values');
        settings._origin = true;
    }
    else {
        // when an array is passed as options, 'qualified' is an array of origins, it pushes the objects in the array 
        settings._origin = {
            qualified: [],
            wildcards: []
        };

        for (const origin of settings.origin) {
            if (origin.indexOf('*') !== -1) {
                // if a wildcards is part of the array of whitelisted origins, e.g. *.example.com, that origin will be added here.
                settings._origin.wildcards.push(new RegExp('^' + Hoek.escapeRegex(origin).replace(/\\\*/g, '.*').replace(/\\\?/g, '.') + '$'));
            }
            else {
                // if it is an exact origin, with no wildcards, it is added in this array instead
                settings._origin.qualified.push(origin);
            }
        }
    }

    return settings;
};


exports.options = function (route, server) {
// option requests are not blocked by cors.
    if (route.method === 'options' ||
        !route.settings.cors) {

        return;
    }

    exports.handler(server);
};

// main function that invokes all the functions that are below it
exports.handler = function (server) {

    Route = Route || require('./route');

    if (server._core.router.specials.options) {
        return;
    }

    const definition = {
        method: '_special',
        path: '/{p*}',
        handler: internals.handler,
        options: {
            cors: false
        }
    };

    const route = new Route(definition, server, { special: true });
    server._core.router.special('options', route);
};

// preflight request
// this is an internal function that is used above as handler.
internals.handler = function (request, h) {

    // Validate CORS preflight request

    const method = request.headers['access-control-request-method'];
    if (!method) {
        throw Boom.notFound('CORS error: Missing Access-Control-Request-Method header');
    }

    // Lookup route

    const route = request.server.match(method, request.path, request.info.hostname);
    if (!route) {
        throw Boom.notFound();
    }

// takes the setting that dev has specified for this route.
// If nothing then it means that by default it is disabled for this route; do nothing.
    const settings = route.settings.cors;
    if (!settings) {
        return { message: 'CORS is disabled for this route' };
    }

    // Validate Origin header

    const origin = request.headers.origin;
    // !null=true, or !=undefined=true. It also checks that it is not cors:false, meaning disabled.
    if (!origin &&
        settings._origin !== false) {

        throw Boom.notFound('CORS error: Missing Origin header');
    }
    // defined at bottom of this file, check if origin is allowed.
    if (!exports.matchOrigin(origin, settings)) {
        return { message: 'CORS error: Origin not allowed' };
    }

    // Validate allowed headers

    let headers = request.headers['access-control-request-headers'];
    if (headers) {
        headers = headers.toLowerCase().split(/\s*,\s*/);
        // check if headers are allowed against the requested headers
        if (Hoek.intersect(headers, settings._headers).length !== headers.length) {
            return { message: 'CORS error: Some headers are not allowed' };
        }
    }

    // Reply with the route CORS headers
    // At this point the checks are passed and the headers are sent.
    const response = h.response();
    response._header('access-control-allow-origin', settings._origin ? origin : '*');
    // it reflects methods, so all methods are allowed by default.
    response._header('access-control-allow-methods', method);
    response._header('access-control-allow-headers', settings._headersString);
    response._header('access-control-max-age', settings.maxAge);
    // only if specified by settings, credentials will be set to true, default is false
    if (settings.credentials) {
        response._header('access-control-allow-credentials', 'true');
    }

    if (settings._exposedHeaders) {
        response._header('access-control-expose-headers', settings._exposedHeaders);
    }

    return response;
};

// simple reuqest (i.e. no needed CORS)
exports.headers = function (request) {

    const settings = request.route.settings.cors;
    const response = request.response;
    // needed to avoid caching when diff origins are used.
    // it checks that the specific route has not set this to false whch would disable cors.
    if (settings._origin !== false) {
        response.vary('origin');
    }

    // isOriginMatch()= true if the request 'Origin' header matches the configured CORS restrictions. False if no 'Origin' header is found or does not match
    // isOriginMatch: Cors.matchOrigin(this.headers.origin, this.route.settings.cors)
    if ((request.info.cors && !request.info.cors.isOriginMatch) ||                          // After route lookup
        // checks origin of request against what is defined in the settings
        !exports.matchOrigin(request.headers.origin, request.route.settings.cors)) {        // Response from onRequest
    // doesn't set headers if origin verification fails
        return;
    }
    // at this point origin was accepted, and headers will be sent.
    // If not specified by the route (meaning just cors:true), it defaults to * (s), otherwise is specified in settings._origin then it reflects it
    // since it passed the check above, meaning it is allowed, so reflect it. You can only set 1 specific origin, null, or * to allow-origin header.
    response._header('access-control-allow-origin', settings._origin ? request.headers.origin : '*');
    // Only if developer has specified, credentials will be set to to true and sent
    if (settings.credentials) {
        response._header('access-control-allow-credentials', 'true');
    }

    if (settings._exposedHeaders) {
        response._header('access-control-expose-headers', settings._exposedHeaders, { append: true });
    }
};

// checks the origin of the request
exports.matchOrigin = function (origin, settings) {
// same as ignoring it
    if (settings._origin === true ||
        settings._origin === false) {

        return true;
    }
// if no origin is present, returns false; strict checking.
// tested in JS: !null=true and !undefined=true. I.e. it is not vulnerable.
    if (!origin) {
        return false;
    }
// if the array contains the provided origin, then return true (which means OK)
    if (settings._origin.qualified.indexOf(origin) !== -1) {
        return true;
    }
// also check if regex
    for (const wildcard of settings._origin.wildcards) {
        if (origin.match(wildcard)) {
            return true;
        }
    }

    return false;
};