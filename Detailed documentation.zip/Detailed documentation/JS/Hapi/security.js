
/* THIS ARE PER-ROUTE SETTINGS THAT THE DEVELOPER CAN SPECIFY. THEY ARE NOT GLOBAL. IT MAKES IT TEDIOUS FOR DEVELOPER BUT IT IS OFFERED BUILT-IN.
   BY DEFAULT, THEY ARE DISABLED FOR ALL ROUTES. */

'use strict';

const internals = {};


exports.route = function (settings) {
// if nothing is provided, no security will be enforced in this route.
    if (!settings) {
        return null;
    }
// if the developer has specified something for this route.
    const security = settings;
    // if hsts is set to true, it will sent the HSTS header.
    if (security.hsts) {
        if (security.hsts === true) {
            security._hsts = 'max-age=15768000';
        }
        // if hsts is a number and not a boolean, that is the maxAge
        else if (typeof security.hsts === 'number') {
            security._hsts = 'max-age=' + security.hsts;
        }
        //otherwise it is an object with 3 properties: maxAge, includeSubdomain (true/false) and preload (true/false)
        else {
            security._hsts = 'max-age=' + (security.hsts.maxAge || 15768000);
            if (security.hsts.includeSubdomains || security.hsts.includeSubDomains) {
                security._hsts = security._hsts + '; includeSubDomains';
            }

            if (security.hsts.preload) {
                security._hsts = security._hsts + '; preload';
            }
        }
    }

// if provided by developer with :true, it defaults to DENY.
    if (security.xframe) {
        if (security.xframe === true) {
            security._xframe = 'DENY';
        }
        // he can also specify a stirng like 'deny', which will just be put to uppercase.
        else if (typeof security.xframe === 'string') {
            security._xframe = security.xframe.toUpperCase();
        }
        // otherwise passes an object.
        else if (security.xframe.rule === 'allow-from') {
            if (!security.xframe.source) {
                security._xframe = 'SAMEORIGIN';
            }
            else {
                security._xframe = 'ALLOW-FROM ' + security.xframe.source;
            }
        }
        else {
            security._xframe = security.xframe.rule.toUpperCase();
        }
    }

    return security;
};


// it sets the headers for the options that were decided above.
exports.headers = function (request) {

    const response = request.response;
    // retrieves whatever was specified above and then sets the response headers.
    const security = response.request.route.settings.security;

    if (security._hsts) {
        response._header('strict-transport-security', security._hsts, { override: false });
    }

    if (security._xframe) {
        response._header('x-frame-options', security._xframe, { override: false });
    }
    // this is only for IE, not to be considered as a general solution against XSS. Not a universal solution for all browsers.
    if (security.xss) {
        response._header('x-xss-protection', '1; mode=block', { override: false });
    }

    // noOpen - boolean controlling the 'X-Download-Options' header for Internet Explorer, preventing downloads from executing in your context. 
    // Defaults to true, setting the header to 'noopen'.
    if (security.noOpen) {
        response._header('x-download-options', 'noopen', { override: false });
    }

    // noSniff - boolean controlling the 'X-Content-Type-Options' header. Defaults to true, setting the header to its only and default option, 'nosniff'.
    if (security.noSniff) {
        response._header('x-content-type-options', 'nosniff', { override: false });
    }
    // referrer - controls the 'Referrer-Policy' header. all options are here : https://hapi.dev/api/?v=19.1.1#-routeoptionssecurity
    // by default, this is not sent to clients at all (referrer:false is the default. That is why below it checks if it is !==false and use dev's values)
    if (security.referrer !== false) {
        response._header('referrer-policy', security.referrer, { override: false });
    }
};