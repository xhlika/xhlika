

/* THIS IS THE CSRF MIDDLEWARE (koa-csrf package) USED IN KOA FOR CSRF PROTECTION. IT IS AN ALMOST EXACT REPLICA OF EXPRESS'S csurf PACKAGE. IT USES The
   csrf PACKAGE FOR TOKEN GENERATION AND VERIFICATION (REFER TO THE EXPRESS FOLDER FOR MORE DETAILS), SAME AS IN EXPRESS. 
   THE ONLY BIG DIFFERENCE IS THAT IT ONLY SUPPORTS PLAIN TOKEN, AND NOT DOUBLE SUBMIT */
   
// SEE EXPRESS'S "csrf" FOLDER FOR THE DETAILED EXPLANATION OF THIS PACKAGE.
const csrf = require('csrf');

class CSRF {

    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/assign
    // assign(), if a property is not specified on "options", will take the default configuration for that.
    // if a property exists in both default and opts, it will take the value at "options" (i.e. of the parameter: opts)
  constructor(opts = {}) {
    this.opts = Object.assign(      //defaults, will be used if opts below does not have anything specified. if yes, will use opts instead of the defaults
      {
        invalidTokenMessage: 'Invalid CSRF token',
        invalidTokenStatusCode: 403,
        excludedMethods: ['GET', 'HEAD', 'OPTIONS'],
        disableQuery: false
      },
      
      opts   // opts of dev will always overwrite defaults in the resulting object, that is how assign() works.
    );
    
// calls the csrf library that does the generation and verification and passes the options to it, e.g. which are excluded methods from CSRF check or type of error
// "tokens" object now can be used below to access the methods for generation, verification, etc. since it is an object of csrf class.
    this.tokens = csrf(opts);

    return this.middleware.bind(this);
  }

  middleware(ctx, next) {
      // this is the getter function that is called when you do "ctx.csrf" in the server-side, e.g. when you call it and pass it to a view that will render the HTML
      // with the token in it. ctx.csrf is equivalent to req.locals() in Express or res.locals.csrf in Sails.     
    ctx.__defineGetter__('csrf', () => {
        // if the token was already generated, use it.
      if (ctx._csrf) {
        return ctx._csrf;
      }
       // if there isn't a session then just return null; no token can be set without a session, since this is Plain Token.
      if (!ctx.session) {
        return null;
      }
     // if there is no secret then generate it. It happens when a session is first generated for the user or when cookie is not sent with the req. 
     // Since cannot link i to a session and its secret, it will generate a new token and token comparison will fail because there is a new CSRF secret: safe behavior. */
      if (!ctx.session.secret) {
        ctx.session.secret = this.tokens.secretSync();
      }
     // uses the secret to create the token, using the create() function of csrf class (tokens is an object of that class, allowing us to access its functions here)
      ctx._csrf = this.tokens.create(ctx.session.secret);
      // returns the token. This is like req.csrfToken() in Express.
      return ctx._csrf;
    });

    ctx.response.__defineGetter__('csrf', () => ctx.csrf);
    
    
    // This is executed first, then cstx.csrf above when you call ctx.csrf to render it in the HTML.
    // if the method of request is (-1 indicates that is not included in array) in the list of methods to be ignored (get, head, options), then
    // call the next middleware() in line since CSRF check is not done for safe methods.
    // Express just does this in 1 row, here they do it separately; first check request method and then verify CSRF token
    if (this.opts.excludedMethods.indexOf(ctx.method) !== -1) {
      return next();
    }
    // if for some reason, CSRF secret doesn't exist, it will be created.
    if (!ctx.session.secret) {
      ctx.session.secret = this.tokens.secretSync();
    }

    // retrieves the token from the body of request where it is as a hidden field with "_csrf" name/id.
    // if found, bodyToken=token, otherwise = false.
    const bodyToken =
      ctx.request.body && typeof ctx.request.body._csrf === 'string'
        ? ctx.request.body._csrf
        : false;

    // "token"  will retrieve the CSRF token from the request
    const token =
      bodyToken ||
      (!this.opts.disableQuery && ctx.query && ctx.query._csrf) ||
      ctx.get('csrf-token') ||
      ctx.get('xsrf-token') ||
      ctx.get('x-csrf-token') ||
      ctx.get('x-xsrf-token');

    // !false = true (when bodyToken=false and not found in headers or query), then it will throw the error since the token is missing from the request.
    if (!token) {
      return ctx.throw(
        this.opts.invalidTokenStatusCode,
        typeof this.opts.invalidTokenMessage === 'function'
          ? this.opts.invalidTokenMessage(ctx)
          : this.opts.invalidTokenMessage
      );
    }

    // at this point a token was found and the request method is unsafe so verify the CSRF token
    // it follows the same logic as in Express by calling verify() of csrf class/package.
    if (!this.tokens.verify(ctx.session.secret, token)) {
      return ctx.throw(
        this.opts.invalidTokenStatusCode,
        typeof this.opts.invalidTokenMessage === 'function'
          ? this.opts.invalidTokenMessage(ctx)
          : this.opts.invalidTokenMessage
      );
    }
    // if all above succeeds, then it means that all is fine/valid request and the next middleware can be called.
    return next();
  }
}


