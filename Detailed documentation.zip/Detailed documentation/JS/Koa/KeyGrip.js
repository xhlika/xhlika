/*!
 * keygrip
 * Copyright(c) 2011-2014 Jed Schmidt
 * MIT Licensed
 */



/* THIS IS THE PACKAGE THAT GIVES THE DEVELOPER THE OPPORTUNITY TO (MANUALLY) ROTATE KEYS. ALL EXPLANATIONS ARE IN THE "COOKIES" FOLDER SINCE 
   KEYFRIP IS USED ONLY THERE. ALL THE METHODS THAT ARE HERE ARE EXPLAINED THERE WHERE THEY ARE USED IN A SPECIFIC CONTEXT. ONLY 2 COMMENTS ARE ADDED HERE AS WELL. */


'use strict'

var compare = require('tsscmp')
var crypto = require("crypto")
  
function Keygrip(keys, algorithm, encoding) {
  if (!algorithm) algorithm = "sha1";
  if (!encoding) encoding = "base64";
  if (!(this instanceof Keygrip)) return new Keygrip(keys, algorithm, encoding)

//it only checks that the keys are provided. It doesn't check randomness, length, etc.
  if (!keys || !(0 in keys)) {
    throw new Error("Keys must be provided.")
  }

// byd efault i uses HMAC-SHA1 to sign the cookies
  function sign(data, key) {
    return crypto
      .createHmac(algorithm, key)
      .update(data).digest(encoding)
      .replace(/\/|\+|=/g, function(x) {
        return ({ "/": "_", "+": "-", "=": "" })[x]
      })
  }
                                                //first key in array
  this.sign = function(data){ return sign(data, keys[0]) }

  this.verify = function(data, digest) {
    return this.index(data, digest) > -1
  }

  this.index = function(data, digest) {
    for (var i = 0, l = keys.length; i < l; i++) {
      if (compare(digest, sign(data, keys[i]))) {
        return i
      }
    }

    return -1
  }
}

Keygrip.sign = Keygrip.verify = Keygrip.index = function() {
  throw new Error("Usage: require('keygrip')(<array-of-keys>)")
}

module.exports = Keygrip