/**
THIS PACKAGE (COOKIES) IS USED INSTEAD OF "COOKIE" PACKAGE (WHICH IS USED BY EXPRESS, SAILS, ETC) TO MANAGE COOKIES AND HANDLE SIGNING AND UNSIGNING.
2 COOKIES ARE CREATED AND SENT IF SIGNED:TRUE (DEFAULT FALSE)--> SIGNED AND UNSIGNED. SIGNATURE IS DONE BY KEYGRIP (NORMALLY) IF SPECIFIED AT OPTIONS.
KEYGRIP IS THE ONE THAT HANDLES SIGNING/UNSIGNING AND VERIFY (MORE BELOW AND IN KEYGRIP JS). GOOD FEATURE THAT ALLOWS KEY ROTATION, BUT DON'T CHECK LENGTH 
AND RANDOMNESS OF THE KEY. BASICALLY, THIS LIBRARY PROVIDES GET (RETRIEVE COOKIE VALUE AND VERIFY SIGNATURE) AND SET (WRITE THE 2 COOKIES, USING KEYGRIP TO SIGN USING HMAC-SHA1). 
SUPPORTS SAMESITE COOKIES.
**/


'use strict'

var deprecate = require('depd')('cookies')
var Keygrip = require('keygrip')
var http = require('http')
var cache = {}

/**
 * RegExp to match field-content in RFC 7230 sec 3.2
 *
 * field-content = field-vchar [ 1*( SP / HTAB ) field-vchar ]
 * field-vchar   = VCHAR / obs-text
 * obs-text      = %x80-FF
 */

var fieldContentRegExp = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;

/**
 * RegExp to match Same-Site cookie attribute value.
 */

var SAME_SITE_REGEXP = /^(?:lax|none|strict)$/i

function Cookies(request, response, options) {
  if (!(this instanceof Cookies)) return new Cookies(request, response, options)

  this.secure = undefined
  this.request = request
  this.response = response

/* This code reads the options that were passed to the Cookies() constructor when invoked, and checks for the keys.
   It always try to creates a KeyGrip object out of the recieved options.
   1. if array of keys, pass this as arg to the KeyGrip constructor. 2. if an object "Keygrip" was passed at options, this.key=object.
   3. if options.keys is an array, it creates a keygrip object and passes the array of keys as parameter, otherwise just option.keys 
   This means that if it is not an array (just 1 string), then there is no point of KeyGrip and rotation since only 1 key.
   RESULT: this.key now holds a Keygrip object and calls the methods of this class, e.g. sign() or index() (a special version of unsign) */
  if (options) {
    if (Array.isArray(options)) {
      // array of key strings
      deprecate('"keys" argument; provide using options {"keys": [...]}')
      this.keys = new Keygrip(options)
    } else if (options.constructor && options.constructor.name === 'Keygrip') {
      // any keygrip constructor to allow different versions
      deprecate('"keys" argument; provide using options {"keys": keygrip}')
      this.keys = options
    } else {
      this.keys = Array.isArray(options.keys) ? new Keygrip(options.keys) : options.keys
      this.secure = options.secure
    }
  }
}


// GET cookie (both signed and unsigned if applies + check signature if signed cookies present)
Cookies.prototype.get = function(name, opts) {
  var sigName = name + ".sig"
    , header, match, value, remote, data, index
    , signed = opts && opts.signed !== undefined ? opts.signed : !!this.keys
//get the Cookie header from request
  header = this.request.headers["cookie"]
  if (!header) return
// if certain cookie was not found then return because there is nothing to do; wasn't sent in the request
  match = header.match(getPattern(name))
  if (!match) return
// if not signed, then just go ahead and return the value of unsigned cookie
  value = match[1]
  if (!opts || !signed) return value

  remote = this.get(sigName)
  if (!remote) return
// creates cookie_name=cookie_value which will be hashed and then verify the signature
  data = name + "=" + value
  if (!this.keys) throw new Error('.keys required for signed cookies');
  // it calls index() method of Keygrip class that verifies the signature. 
  // Tt does not call verify() directly, but index() which is used by verify() anyway. 
  // verify() is just 1 line, it returns true/false by comparing the resulting index with -1 (true: verification ok, false then tampered)
  index = this.keys.index(data, remote)
  // it return an index. -1 means that none of the keys that were passed as args to keygrip object signed the cookie, i.e. cookie was tampered with.
  // This one sets cookie value to null, and at set() (if value==null), it will set an expired date and cookie is invalid, since it was tampered and shouldn't be used
  if (index < 0) {
      // signed:false, it will be deleted as a cookie anyway since it failed the verification.
      // It will be done below when value=null is detected
    this.set(sigName, null, {path: "/", signed: false })
  } else {
      /* Otherwise (read READ ME of cookies.get()), it will re-sign the cookie with one of the keys.
         https://github.com/crypto-utils/keygrip/issues/37 : keys are not rotated automatically. developer should use unshift() to add a new fresh key at beginning 
         of array. This key will be used to sign cookie from that moment onwards, you dont need to restart Node. 
         Old cookies still remain valid, since the old key will still remain in the array for signature verification until expiration. New cookies will use the fresh key.
         pop() can be used to remove old keys from the end of the array. Developer has to do this as well, but it is possible. By default, signature is 
         HMAC-SHA1 which is then base64ed and url-encoded. signed:false, because you are passing the signed cookie itself, so no need for set() to set a cookie  */

      
      
     // Documentation: "If the signature cookie hash matches any other key, the original cookie value is returned AND an outbound header is set to update the signature 
     // cookie's value to the hash of the first key. This enables automatic freshening of signature cookies that have become stale due to key rotation."

    index && this.set(sigName, this.keys.sign(data), { signed: false })
    //"the original cookie value is returned", meaning the unsigned value that will be used by other packages of koa, e.g. the session.
    return value
  }
};

// to be called when a cookie is to be set (not just the case above at get())
Cookies.prototype.set = function(name, value, opts) {
  var res = this.response
    , req = this.request
    , headers = res.getHeader("Set-Cookie") || []
    , secure = this.secure !== undefined ? !!this.secure : req.protocol === 'https' || req.connection.encrypted
    , cookie = new Cookie(name, value, opts)
    // checks if the cookie should be signed or not based on the options.By defualt session cookies are signed.
    , signed = opts && opts.signed !== undefined ? opts.signed : !!this.keys

  if (typeof headers == "string") headers = [headers]
//FEATURE: it will not send the cookie if request came under http while developer specified secure:true (default false). 
// Not same as having HSTS, but it is an additional security. Normally, secure=true just tells browser not to send cookie.
// In this case the server doesn't even send the cookie, so it will not be tampered before it reaches the browser, e.g in 2-step MITM.
  if (!secure && opts && opts.secure) {
    throw new Error('Cannot send secure cookie over unencrypted connection')
  }

  cookie.secure = opts && opts.secure !== undefined
    ? opts.secure
    : secure

  if (opts && "secureProxy" in opts) {
    deprecate('"secureProxy" option; use "secure" option, provide "secure" to constructor if needed')
    cookie.secure = opts.secureProxy
  }
// the unsigned cookie. sets the cookie
  pushCookie(headers, cookie)
// if specified that cookies need to be signed, then it will use sign() of KeyGrip to create a HMAC-SHA1 and secret key is keys[0], i.e first element in the array.
  if (opts && signed) {
    if (!this.keys) throw new Error('.keys required for signed cookies');
    cookie.value = this.keys.sign(cookie.toString())
    cookie.name += ".sig" //to distinguish it from the normal cookie
    // sets the cookie to be sent with an additional set-cookie header
    pushCookie(headers, cookie)
  }

  var setHeader = res.set ? http.OutgoingMessage.prototype.setHeader : res.setHeader
  setHeader.call(res, 'Set-Cookie', headers)
  return this
};

function Cookie(name, value, attrs) {
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError('argument name is invalid');
  }

  if (value && !fieldContentRegExp.test(value)) {
    throw new TypeError('argument value is invalid');
  }

// checks if value == null (e.g. when signature verification failed)
  this.name = name
  this.value = value || ""

  for (var name in attrs) {
    this[name] = attrs[name]
  }

// if value null, it sets date to new Date(0)= january, 1970= cookie expired and needs to be removed.
// It set sexpiration date, because part of session.js code (generic-session) will check the cookie, if invalid it will delete and generate a new session and cookie
  if (!this.value) {
    this.expires = new Date(0)
    this.maxAge = null
  }

  if (this.path && !fieldContentRegExp.test(this.path)) {
    throw new TypeError('option path is invalid');
  }

  if (this.domain && !fieldContentRegExp.test(this.domain)) {
    throw new TypeError('option domain is invalid');
  }

  if (this.sameSite && this.sameSite !== true && !SAME_SITE_REGEXP.test(this.sameSite)) {
    throw new TypeError('option sameSite is invalid')
  }
}

// DEFAULT VALUES
//SameSite also supported but not enabled by default
Cookie.prototype.path = "/";
Cookie.prototype.expires = undefined;
Cookie.prototype.domain = undefined;
Cookie.prototype.httpOnly = true;
Cookie.prototype.sameSite = false;
Cookie.prototype.secure = false;
Cookie.prototype.overwrite = false;

Cookie.prototype.toString = function() {
  return this.name + "=" + this.value
};

// takes the options that dev has specified and sets the cookie header by accumulating the cookie attributes in it, divided by ;
Cookie.prototype.toHeader = function() {
  var header = this.toString()

  if (this.maxAge) this.expires = new Date(Date.now() + this.maxAge);

  if (this.path     ) header += "; path=" + this.path
  if (this.expires  ) header += "; expires=" + this.expires.toUTCString()
  if (this.domain   ) header += "; domain=" + this.domain
  if (this.sameSite ) header += "; samesite=" + (this.sameSite === true ? 'strict' : this.sameSite.toLowerCase())
  if (this.secure   ) header += "; secure"
  if (this.httpOnly ) header += "; httponly"

  return header
};

// back-compat so maxage mirrors maxAge
Object.defineProperty(Cookie.prototype, 'maxage', {
  configurable: true,
  enumerable: true,
  get: function () { return this.maxAge },
  set: function (val) { return this.maxAge = val }
});
deprecate.property(Cookie.prototype, 'maxage', '"maxage"; use "maxAge" instead')

function getPattern(name) {
  if (cache[name]) return cache[name]

  return cache[name] = new RegExp(
    "(?:^|;) *" +
    name.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&") +
    "=([^;]*)"
  )
}

// adds a set-cookie header to the response
function pushCookie(headers, cookie) {
  if (cookie.overwrite) {
    for (var i = headers.length - 1; i >= 0; i--) {
      if (headers[i].indexOf(cookie.name + '=') === 0) {
        headers.splice(i, 1)
      }
    }
  }

  headers.push(cookie.toHeader())
}

Cookies.connect = Cookies.express = function(keys) {
  return function(req, res, next) {
    req.cookies = res.cookies = new Cookies(req, res, {
      keys: keys
    })

    next()
  }
}

Cookies.Cookie = Cookie

module.exports = Cookies