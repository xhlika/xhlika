/*!
 * csrf
 * Copyright(c) 2014 Jonathan Ong
 * Copyright(c) 2015 Douglas Christopher Wilson
 * MIT Licensed
 */

'use strict'

/**
 * Module dependencies.
 * @private
 */
 
 
 /* THIS IS THE PACKAGE (CSRF) RESPONSIBLE FOR TOKEN GENERATION AND VERIFICATION. IT IS CALLED BY THE CSRF MIDDLEWARE (THE CSURF PACKAGE)
    TO HANDLE CSRF TOKEN GENERATION AND VERIFICATION IN EACH REQUEST.
 */

// package that generates the salt and is found: https://github.com/crypto-utils/rndm last version (1.2.0) was 4 years ago which is the current version used
// read description on above link: arbitrary length output (8 in this case), BUT not cryptographically-secure salt so it doesn't count as a cryptographic nonce.
var rndm = require('rndm')
// generates the per-session CSRF secret which is combined with the per-request salt and together they form the CSRF token
// https://www.npmjs.com/package/uid-safe latest version (2.1.5) 3 years ago. That is the version currently being used.
// https://github.com/crypto-utils/uid-safe/blob/master/index.js that uses https://github.com/crypto-utils/random-bytes/blob/master/index.js
var uid = require('uid-safe')
// library for string comparison that avoids timing attacks. even mentioned in a commit: https://github.com/pillarjs/csrf/commit/19245b55b2f9becef6a00b5c713da375209b11f0#diff-168726dbe96b3ce427e7fedce31bb0bc
// https://www.npmjs.com/package/tsscmp latest version (1.0.6) was 2 years ago and is what this package is using: https://github.com/suryagh/tsscmp/blob/master/lib/index.js
//  timing safe function: crypto.TimingSafeEqual: https://nodejs.org/dist/latest-v6.x/docs/api/crypto.html#crypto_crypto_timingsafeequal_a_b
var compare = require('tsscmp')
// NOT a library/package anymore. It is now a built-in module in NodeJS. https://nodejs.org/api/crypto.html#crypto_crypto_createhash_algorithm_options
var crypto = require('crypto')

/**
 * Module variables.
 * @private
 */

// replace hash characters that are not URL-friendly when token is converted into base64 string
var EQUAL_GLOBAL_REGEXP = /=/g
var PLUS_GLOBAL_REGEXP = /\+/g
var SLASH_GLOBAL_REGEXP = /\//g

/**
 * Module exports.
 * @public
 */

// this is an object which will be called in csurf package. 
module.exports = Tokens

/**
 * Token generation/verification class.
 *
 * @param {object} [options]
 * @param {number} [options.saltLength=8] The string length of the salt               THIS IS THE DEFAULT LENGTH=64 bits. problem is that is not random.
 * @param {number} [options.secretLength=18] The byte length of the secret key        THIS IS THE DEFAULT LENGTH- which is 144 bits. Above 128 can be considered secure
 * @public                                                                            The resulting random bytes will be encoded in base64 (ends up in 24 characters)
 *                                                csrf token= salt||-||base64ed_hash_digest_of(salt-base64ed_secret)= 8+1+27(output of hash always same length)=36 chars
 **/                                              

// this is an constructor of the Tokens class which will be called in the CSRF middleware (csurf package). 
function Tokens (options) {
  if (!(this instanceof Tokens)) {
    return new Tokens(options)
  }

// it is optional. Since this is the class for generation, when the object is called, you can, e.g., specify your own length for salt and/or the secret key
  var opts = options || {}
  
// if developer specifies salt length in the options parameter of Tokens object, then use it as length, otherwise salt length is default = 8 bytes/chars
  var saltLength = opts.saltLength !== undefined
    ? opts.saltLength
    : 8

//makes sure that the developer input is a number and bigger than 1
  if (typeof saltLength !== 'number' || !isFinite(saltLength) || saltLength < 1) {
    throw new TypeError('option saltLength must be finite number > 1')
  }

// if developer specifies secret length in the options parameter of Tokens object, then use it as length, otherwise secret length is default =18 bytes/chars
  var secretLength = opts.secretLength !== undefined
    ? opts.secretLength
    : 18
//makes sure that the developer input is a number and bigger than 1
  if (typeof secretLength !== 'number' || !isFinite(secretLength) || secretLength < 1) {
    throw new TypeError('option secretLength must be finite number > 1')
  }
/* this will be accessed by the rest of the methods of this class
   this salt is 64 bits. Indeed is a good enough length for a nonce, BUT it uses Math.Random() wich it is not crypto random. doesn't qualify for a crypto nonce
   + the program does not check if the salt was accepted before, it is NOT a number-only-used-once, therefore Replay attacks possible
   admitted by core developer of Express himself: https://github.com/pillarjs/csrf/issues/4   */
  this.saltLength = saltLength
  this.secretLength = secretLength
}

/**
 * Create a new CSRF token.
 *
 * @param {string} secret The secret for the token.
 * @public
 */

/* you cannot directly add properties or functions to an object. Instead you can use objectX.prototype to "extend" objectX, which
   is the function that generates the token. In order to do that, it has to have the parameter "secret" which is unique per-session and per-user.
   If missing, it will throw an exception. Otherwise, it will invoke _tokenize() which generates the token.
*/
Tokens.prototype.create = function create (secret) {
  if (!secret || typeof secret !== 'string') {
    throw new TypeError('argument secret is required')
  }
// rndm() func is used to generate a "random" salt, by using Math.Random(). It gets as parameter the salt length.
  return this._tokenize(secret, rndm(this.saltLength))
}

/**
 * Create a new secret key.
 *
 * @param {function} [callback]
 * @public
 */

/* this generates the secret that is used during the generation of a new CSRF token. According to documentation it is supposed to be per-session and per-user
   it is stored in the server-side storage (Plain Token) or cookie (check below) and can be accessed with req[sessionKey].csrfSecret
   2 ways to generate it: asynchronously and synchronously (next method below)
   uid() is a function of uid-safe library (check at require() at top) and takes the length of required secret as parameter. 
   This libary in turn uses random-bytes library which uses crypto.randomBytes(). This is just a wrapper of OpenSSL RAND_bytes()
   According to documentation, it gets the seed from the OS (dev/random in Unix-like or CryptoGenRandom for Windows). It will throw an error if not properly seeded by OS
   Minimum length of the seed is 256 bits, otherwise RAND_bytes() returns error. This fucntions extracts cryptographically strong random bytes.
   It returns 1 in success and 0 in failure. 
*/
Tokens.prototype.secret = function secret (callback) {
  return uid(this.secretLength, callback)
}

/**
 * Create a new secret key synchronously.
 * @public
 */
//synchronous generation of the secret
Tokens.prototype.secretSync = function secretSync () {
  return uid.sync(this.secretLength)
}

/**
 * Tokenize a secret and salt.
 * @private
 */

/*generation of CSRF token: per-request salt||-|| hash_of_salt_and_per_session_secret.
  The salt is generated from rndm() while secret should normally be retrieved from session storage (or created new if it is start of session).
  The secret that is stored in server-side storage is "per-session". But, to defend against BREACH, developers have used per-request salting
  as a strategy to change the CSRF token while using the same per-session-user secret. https://github.com/pillarjs/csrf/issues/4
  This can be considered as keyed hash where "secret" serves as a key which is rotated for every new session/user. It can be thought as a simplistic application of HMAC.
  note that only the CSRF secret is stored in the server-side and not the entire CSRF token!
*/
Tokens.prototype._tokenize = function tokenize (secret, salt) {
  return salt + '-' + hash(salt + '-' + secret)
}

/**
 * Verify if a given token is valid for a given secret.
 *
 * @param {string} secret
 * @param {string} token
 * @public
 */

/*
 Verification process. Takes the CSRF secret (of the user who did the request) for this session and the CSRF token that came with the request, as parameters.
 It makes sure that both this parameters are of type string and have value (not undefined).
 As seen above, a CSRF token is: salt-hash. Index holds the position of "-" in the string. From index 0 of the string until index of '-', we retrieve the salt 
 (since salt is always placed at the beginning of the token). This is extracted from the token that came with the req.
 Expected: this variable calls the function that generated the token. It passes the secret as parameter and the salt that was extracted from client's token.
 compare() checks if the resulting CSRF token (expected) is the same or not with the CSRF token that came from client-side. The library of compare() is supposed to 
 prevent timing attacks on stirng comparison. Even if the attacker can specify his own salt value, he does NOT know the "secret" (which is unique per user-session) 
 so he cannot generate the hash part. Replay attacks though are possible: no timestamp or check that the nonce/salt has been used before. If attacker manages to leak 
 the csrf token a single time, he can use it for the entire duration of the session. He doesn't even need to know the secret. Salt prevents BREACH, but not Replay. 
 
*/
Tokens.prototype.verify = function verify (secret, token) {
  if (!secret || typeof secret !== 'string') {
    return false
  }

  if (!token || typeof token !== 'string') {
    return false
  }

  var index = token.indexOf('-')

  if (index === -1) {
    return false
  }

  var salt = token.substr(0, index)
  var expected = this._tokenize(secret, salt)

  return compare(token, expected)
}

/**
 * Hash a string with SHA1, returning url-safe base64
 * @param {string} str
 * @private
 */

/* the hash function that is used by _tokenize to generate the token.
   It creates the hash and then converts it to base64 and also replaces some forbidden url characters to make it url-friendly.
   str parameter is salt+secret  */
function hash (str) {
  return crypto
    .createHash('sha1')
    .update(str, 'ascii')
    .digest('base64')
    .replace(PLUS_GLOBAL_REGEXP, '-')
    .replace(SLASH_GLOBAL_REGEXP, '_')
    .replace(EQUAL_GLOBAL_REGEXP, '')
}