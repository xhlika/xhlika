

// THIS IS THE MAIN SOURCE CODE THAT HANDLES THE ANTI-CSRF MECHANISM IN VERT.X-WEB. IT HANDLES TOKEN GENERATION, VERIFICATION, ETC.
package io.vertx.ext.web.handler.impl;

import io.vertx.core.Vertx;
import io.vertx.core.http.Cookie;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.impl.logging.Logger;
import io.vertx.core.impl.logging.LoggerFactory;
import io.vertx.ext.auth.VertxContextPRNG;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.Session;
import io.vertx.ext.web.handler.CSRFHandler;
import io.vertx.ext.web.handler.SessionHandler;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;


/**
 * @author <a href="mailto:pmlopes@gmail.com">Paulo Lopes</a>
 */
public class CSRFHandlerImpl implements CSRFHandler {

  private static final Logger log = LoggerFactory.getLogger(CSRFHandlerImpl.class);

  private static final Base64.Encoder BASE64 = Base64.getMimeEncoder();

// it uses its own CSPRNG because of fear of CSPRNG of being blocked when not enough entropy by OS
  private final VertxContextPRNG random;
  private final Mac mac;

  private boolean nagHttps;
  private String cookieName = DEFAULT_COOKIE_NAME;                    //    "XSRF-TOKEN"    
  private String cookiePath = DEFAULT_COOKIE_PATH;                    // "/"
  private String headerName = DEFAULT_HEADER_NAME;                    // "X-XRF-TOKEN"
  private String responseBody = DEFAULT_RESPONSE_BODY;                // null
  private long timeout = SessionHandler.DEFAULT_SESSION_TIMEOUT;

// when this handler is called, secret is passed as required parameter. The key used to sign the csrf cookie (with HMAC-SHA256)
// No check on the secret/key's length or randomness, which is provided by the developer
  public CSRFHandlerImpl(final Vertx vertx, final String secret) {
    try {
      random = VertxContextPRNG.current(vertx);
      mac = Mac.getInstance("HmacSHA256");
      mac.init(new SecretKeySpec(secret.getBytes(), "HmacSHA256"));
    } catch (NoSuchAlgorithmException | InvalidKeyException e) {
      throw new RuntimeException(e);
    }
  }

  @Override
  public CSRFHandler setCookieName(String cookieName) {
    this.cookieName = cookieName;
    return this;
  }

  @Override
  public CSRFHandler setCookiePath(String cookiePath) {
    this.cookiePath = cookiePath;
    return this;
  }

  @Override
  public CSRFHandler setHeaderName(String headerName) {
    this.headerName = headerName;
    return this;
  }

  @Override
  public CSRFHandler setTimeout(long timeout) {
    this.timeout = timeout;
    return this;
  }

  @Override
  public CSRFHandler setNagHttps(boolean nag) {
    this.nagHttps = nag;
    return this;
  }

  @Override
  public CSRFHandler setResponseBody(String responseBody) {
    this.responseBody = responseBody;
    return this;
  }



  // generates and store the CSRF token in the cookie.
  // It uses randomSecure() and generate a 32-byte token (256 bits of entropy)
  private String generateAndStoreToken(RoutingContext ctx) {
    // this salt array will be filled by random.nextBytes(), i.e. the array to be filled with 32 random bytes
    byte[] salt = new byte[32];
    random.nextBytes(salt);
    // salt holds the generated token (base64ed string), then a timestamp is added.
    String saltPlusToken = BASE64.encodeToString(salt) + "." + System.currentTimeMillis();
    // the entire thing is signed using HMAC-SHA256 with the developer-provided key
    String signature = BASE64.encodeToString(mac.doFinal(saltPlusToken.getBytes()));

    // the final CSRF token is: raw/base token(base64ed)|.|timestamp|.|signature(base64ed)
    final String token = saltPlusToken + "." + signature;
    // a new token was generated, so add it to the cookie (as signed).
    ctx.addCookie(Cookie.cookie(cookieName, token).setPath(cookiePath));

    return token;
  }
    
  // function that performs the CSRF verification.
  // It is called by handle() function at the bottom of this file
  private boolean validateRequest(RoutingContext ctx) {

    // gets the CSRF cookie from the request
    final Cookie cookie = ctx.getCookie(cookieName);

    // missing CSRF token, no point continuing the verification
    if (cookie == null) {
      // quick abort
      return false;
    }

    // the challenge may be stored on the session already
    // in this case there we don't trust the user agent for it's                 ---> This is a weird comment by the core developer
    // header or form value
    
    
    // Vulnerability: "don't trust the user agent", so they use the csrf token in the session instead. I.e compare csrf cookie value vs stored CSRF token in session
    // VULNERABILITY is here. If sessions are used, then the CSRF token in the request's body is ignored, and the CSRF token in session is used to compare against the
    // token in CSRF cookie. Considering only the csrf token in the cookie is bad, since cookie are sent automatically by the browser.It isn't "Double Submit" anymore.
    String challenge = getTokenFromSession(ctx);
    boolean invalidateSessionToken = false;

    // if no token is found in session, then it will check for it in the custom header or in the form.
    // Otherwise, a token is in session and this specific flag is put to true. The token will be refreshed to avoid replay attacks  only when sessions are used
    if (challenge == null) {
      // fallback to header
      challenge = ctx.request().getHeader(headerName);
      if (challenge == null) {
        // fallback to form parameter
        challenge = ctx.request().getFormAttribute(headerName);
      }
    } else {
      // if the token is provided by the session object
      // we flag that we should invalidate it in case of success otherwise
      // we will allow replay attacks
      invalidateSessionToken = true;
    }

    // both the challenge and the cookie must be present, not null and equal
    // If challenge is missing from session, header, request body OR the comparison fails then the entire CSRF verification returns false -> throws error
    // insecure string comparison, equals() is a built-in java function that does NOT do constant time comparison (unless overriden by developers)
    if (challenge == null || !challenge.equals(cookie.getValue())) {
      return false;
    }

   // at this point, the verification was successful, now the signature is verified
   so the signed token is split into 3 parts, separated by ".": token, timestamp, signature
   // if there aren't 3 parts, it throws an error (csrf comparison retuns false = CSRF attack)
    String[] tokens = challenge.split("\\.");
    if (tokens.length != 3) {
      return false;
    }

    // retrieves the token+timestamp part from request's CSRF token and signs it again
    byte[] saltPlusToken = (tokens[0] + "." + tokens[1]).getBytes();
    synchronized (mac) {
      saltPlusToken = mac.doFinal(saltPlusToken);
    }
    String signature = BASE64.encodeToString(saltPlusToken);

    // compares the signature of the CSRF token of request (token[2]) against the newly-signed token+timestamp
    // Again, unsafe from timing attacks. If doesn't match, an error is thrown, CSRF verfication fails.
    if(!signature.equals(tokens[2])) {
      return false;
    }


    try {
      // validate validity of timestamp
      // check if the token is expired or not. If current time > timestamp+ token's timeout, then the token is expired and it will go into else: returns false
      if (!(System.currentTimeMillis() > Long.parseLong(tokens[1]) + timeout)) {
          // this will happen only if the CSRF token of the session is used instead of the one in the request body/header
          // in this specific case, the old token is invalidated, and a new token will be generated to avoid replay attacks.
        if (invalidateSessionToken) {
          // this token has been used and we discard it to avoid replay attacks
          ctx.session().remove(headerName);
        }
        // token was still valid, at this point the request is accepted.
        return true;
      } else {   // token is expired, 
        return false;
      }
    } catch (NumberFormatException e) {
      return false;
    }
  }

  protected void forbidden(RoutingContext ctx) {
    final int statusCode = 403;
    if (responseBody != null) {
      ctx.response()
        .setStatusCode(statusCode)
        .end(responseBody);
    } else {
      ctx.fail(new HttpStatusException(statusCode, ERROR_MESSAGE));
    }
  }

  // retrieves the token from the current session (identified by the session cookie of the incoming request)
  private String getTokenFromSession(RoutingContext ctx) {
    // identifies the session from the request's session cookie (which holds the session ID)
    Session session = ctx.session();
    if (session == null) {
      return null;
    }
    // get the token from the session on server-side storage
    String sessionToken = session.get(headerName);
    if (sessionToken != null) {
      // attempt to parse the value
      int idx = sessionToken.indexOf('/'); // session ID is generated with randomSecure() which uses type 4 UUID
      if (idx != -1 && session.id() != null && session.id().equals(sessionToken.substring(0, idx))) { // makes sure sessionID of req matches the on the server-side
        return sessionToken.substring(idx + 1);
      }
    }
    // fail
    return null;
  }

  // it will handle the request and ensure to check for CSRF attack if some conditions are met (e.g unsafe request method)
  @Override
  public void handle(RoutingContext ctx) {

    if (nagHttps) {
      String uri = ctx.request().absoluteURI();
      if (uri != null && !uri.startsWith("https:")) {
        log.warn("Using session cookies without https could make you susceptible to session hijacking: " + uri);
      }
    }

    HttpMethod method = ctx.request().method();
    Session session = ctx.session();

    // the switch entries represent most of http request methods for which the CSRF verif is done for: POST, PUT, DELETE, PATCH (all unsafe method)
    // for GET: will do the token generation, it is NOT checked for CSRF. All other methods are ignored (well, the rest are safe methods)
    switch (method.name()) {
      case "GET":
        final String token;
        if (session == null) {
          // if there's no session to store values, tokens are issued on every request--> simple DOUBLE SUBMIT mechanism + per-request tokens.
          token = generateAndStoreToken(ctx);
        } else {
          // get the token from the session, this also considers the fact
          // that the token might be invalid as it was issued for a previous session id
          // session id's change on session upgrades (unauthenticated -> authenticated; role change; etc...)
          String sessionToken = getTokenFromSession(ctx);
          // when there's no token in the session, then we behave just like when there is no session
          // create a new token, but we also store it in the session for the next runs
          if (sessionToken == null) { // there is a session, but there is no token in it. so a new token is generated, and placed on session
            token = generateAndStoreToken(ctx);
            // storing will include the session id too. The reason is that if a session is upgraded
            // we don't want to allow the token to be valid anymore
            session.put(headerName, session.id() + "/" + token);
          } else {
            // we're still on the same session, no need to regenerate the token --> token is re-used, replay attacks are possible + BREACH.
            // https://github.com/vert-x3/vertx-web/pull/1465/files first comment. this is what happens usually, auth users always have a session
            token = sessionToken;
            // in this case specifically we don't issue the token as it is unchanged
            // the user agent still has it from the previous interaction.
          }
        }
        // put the token in the context for users who prefer to render the token directly on the HTML
        ctx.put(headerName, token);
        ctx.next();
        break;
      case "POST":
      case "PUT":
      case "DELETE":
      case "PATCH":  // for all these unsafe methods, it will call the CSRF verification function above. If it returns true, then no CSRF --> execute the request.
        if (validateRequest(ctx)) {
          ctx.next(); // execute the request.
        } else {
          forbidden(ctx); // if verification fails (missing cookie, missing token, unequal tokens, bad signature, etc), then throw an error.
        }
        break;
      default:
        // ignore other methods (all that is left are safe methods like TRACE, OPTIONS, HEAD which are safe methods without a body)
        ctx.next(); // execute request
        break;
    }
  }
}