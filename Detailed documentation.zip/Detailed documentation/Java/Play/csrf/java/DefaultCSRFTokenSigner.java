/*
 * Copyright (C) Lightbend Inc. <https://www.lightbend.com>
 */

// THIS PLAY CLASS HANDLES CRYPTOGRAPHIC OPERATION SUCH AS TOKEN GENERATION, SIGNING, UNSIGNING AND TOKEN COMPARISON. IT DOES SO BY CALLING
// THE CORRESPONDING FUNCTION IN CSRFTokenSigner.java CLASS (SEE IN THE FOLDER)


package play.libs.crypto;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Cryptographic utilities for generating and validating CSRF tokens.
 *
 * <p>This trait should not be used as a general purpose encryption utility.
 */
@Singleton
public class DefaultCSRFTokenSigner implements CSRFTokenSigner {

  // The interface class and its method explanation is found here: https://github.com/playframework/playframework/blob/master/core/play/src/main/java/play/libs/crypto/CSRFTokenSigner.java
  private final play.api.libs.crypto.CSRFTokenSigner csrfTokenSigner;

  @Inject
  public DefaultCSRFTokenSigner(play.api.libs.crypto.CSRFTokenSigner csrfTokenSigner) {
    this.csrfTokenSigner = csrfTokenSigner;
  }

  // This primarily exists to defeat the BREACH vulnerability, as it allows the token to effectively be random per request, without actually changing the value.
  public String signToken(String token) {
    return csrfTokenSigner.signToken(token); // Sign a token. This produces a new token, that has this token signed with a nonce.
  }

  // Extract a signed token that was signed by signToken()
  public String extractSignedToken(String token) {
    scala.Option<String> extracted = csrfTokenSigner.extractSignedToken(token);
    if (extracted.isDefined()) {
      return extracted.get();
    } else {
      return null;
    }
  }

  // Generates a cryptographically secure token.
  public String generateToken() {
    return csrfTokenSigner.generateToken();
  }

  // Generates a signed token by calling generateToken / signToken.
  public String generateSignedToken() {
    return csrfTokenSigner.generateSignedToken();
  }

  // true if the tokens match and are signed, false otherwise.
  public boolean compareSignedTokens(String tokenA, String tokenB) {
    return csrfTokenSigner.compareSignedTokens(tokenA, tokenB);
  }

  @Override
  public play.api.libs.crypto.CSRFTokenSigner asScala() {
    return csrfTokenSigner;
  }
}