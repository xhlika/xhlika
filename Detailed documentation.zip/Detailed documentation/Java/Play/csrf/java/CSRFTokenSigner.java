package play.api.libs.crypto

import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.Clock

import javax.inject.Inject
import javax.inject.Provider
import javax.inject.Singleton

import play.api.libs.Codecs


// THIS IS THE ACTUAL CLASS WHEN TOKEN GENERATION AND SIGNING IS DONE. THESE FUNCTIONS ARE USED AT DefaultCSRFTokenSigner.java CLASS (SEE IN THE FOLDER)

/**
 * Cryptographic utilities for generating and validating CSRF tokens.
 *
 * This trait should not be used as a general purpose encryption utility.
 */
trait CSRFTokenSigner {

  /**
   * Sign a token.  This produces a new token, that has this token signed with a nonce.
   *
   * This primarily exists to defeat the BREACH vulnerability, as it allows the token
   * to effectively be random per request, without actually changing the value.
   *
   * @param token The token to sign
   * @return The signed token
   */
   
   // raw/base token (per-session) is signed in each request to produce a signed CSRF token that is different in each request (while raw/base token is the same)
   // see the method below
  def signToken(token: String): String

  /**
   * Generates a cryptographically secure token.
   */
  def generateToken: String

  /**
   * Generates a signed token.
   */
  def generateSignedToken: String

  /**
   * Extract a signed token that was signed by `signToken(String)`.
   *
   * @param token The signed token to extract.
   * @return The verified raw token, or None if the token isn't valid.
   */
   // it gets the signed token, verifies signature and returns the raw token.
   // see the method below
  def extractSignedToken(token: String): Option[String]

  /**
   * Compare two signed tokens
   */
   

  def compareSignedTokens(tokenA: String, tokenB: String): Boolean

  /**
   * Constant time equals method.
   *
   * Given a length that both Strings are equal to, this method will always
   * run in constant time.  This prevents timing attacks.
   *
   * @deprecated Please use `java.security.MessageDigest.isEqual(a.getBytes("utf-8"), b.getBytes("utf-8"))` over this method.
   */
  @deprecated(
    "Please use java.security.MessageDigest.isEqual(a.getBytes(\"utf-8\"), b.getBytes(\"utf-8\")) over this method.",
    "2.6.0"
  )
  // not used anymore, check below. It is override by messageDigest.isEqual who compares the HMAC digest of the 2 inputs: constant time comparison
  def constantTimeEquals(a: String, b: String): Boolean
}

/**
 * This class is used for generating random tokens for CSRF.
 */
 

class DefaultCSRFTokenSigner @Inject() (signer: CookieSigner, clock: Clock) extends CSRFTokenSigner {
  // If you're running on an older version of Windows, you may be using
  // SHA1PRNG.  So immediately calling nextBytes with a seed length
  // of 440 bits (55 bytes like below) (NIST SP800-90A) will do a more than decent
  // self-seeding for a SHA-1 based PRNG.
  private val random = new SecureRandom()  //this class provides a CSPRNG: https://docs.oracle.com/javase/8/docs/api/java/security/SecureRandom.html
  random.nextBytes(new Array[Byte](55))    // this is not the actual token that is generated, look below

  /**
   * Sign a token.  This produces a new token, that has this token signed with a nonce.
   *
   * This primarily exists to defeat the BREACH vulnerability, as it allows the token to effectively be random per
   * request, without actually changing the value.
   *
   * @param token The token to sign
   * @return The signed token
   */
   /* the raw/base token generated above will signed.
      On order to prevent BREACH, in every request a "nonce" is generated with system's time and it is appended to the raw token (it is not a cryptographic nonce)
      "nonce-token" will then be signed. The resulting signed CSRF token would be: signature-nonce-token
      It is signed by CookieSigner: https://www.playframework.com/documentation/2.6.9/api/java/play/libs/crypto/CookieSigner.html
      signToken(string): Signs (HMAC-SHA256) the given string using the application's secret key.  */
  def signToken(token: String): String = {
    val nonce  = clock.millis()
    val joined = nonce + "-" + token
    signer.sign(joined) + "-" + joined
  }

  /**
   * Extract a signed token that was signed by [[CSRFTokenSigner.signToken]].
   *
   * @param token The signed token to extract.
   * @return The verified raw token, or None if the token isn't valid.
   */
   
   // splits the signed token in 3 parts: signature, nonce, raw/base token. If signature is ok, it will return the raw/base token, otherwise None (=null).
  def extractSignedToken(token: String): Option[String] = {
    token.split("-", 3) match {
        // signs the nonce and raw/base token again. The resulting signature is compared to the signature of the signed CSRF token of the request 
        //(token parameter of this request). Is a secure comparisong from timing attacks.
      case Array(signature, nonce, raw) if isEqual(signature, signer.sign(nonce + "-" + raw)) => Some(raw)
      case _                                                                                  => None
    }
  }

  /**
   * Generate a cryptographically secure token
   */

   // 12 bytes = 96 bits of entropy would not be enough. The resulting bytes are converted to hexademical, so the resulting raw/base token is 24 chars.
   // It is called directly for the unsigned token (when there is no need for signing), otherwise called by generateSignedToken() and passed as parameter
   // to the signing function.
  def generateToken: String = {
    val bytes = new Array[Byte](12)  //not enough entropy
    random.nextBytes(bytes)
    Codecs.toHexString(bytes)
  }

  /**
   * Generate a signed token
   */
   
   // this function will call the signToken() function to sign the raw/base token. It passes generateToken() function as parameter.
   // I.e. the recently-generated raw token is passed to the signing function in order to get the signed CSRF token that is sent in the response
   // since raw/base token is not sent in the response, but a signed one (the signature-nonce-base_token is sent to prevent BREACH)
  def generateSignedToken: String = signToken(generateToken)

  /**
   * Compare two signed tokens
   */
   
   // this is the function that does the CSRF verification of the signed CSRF token of the request against the signed CSRF token in cookie
   // Actually it extracts the raw/base token from both and do the comparison on them.
  def compareSignedTokens(tokenA: String, tokenB: String): Boolean = {
    (for { // compare the raw/base token of the request with the raw/base token in the cookie in a safe string comparison. True=equal, false=CSRF attack
      rawA <- extractSignedToken(tokenA)
      rawB <- extractSignedToken(tokenB)
    } yield isEqual(rawA, rawB)).getOrElse(false)
  }

  override def constantTimeEquals(a: String, b: String): Boolean = isEqual(a, b)

  private def isEqual(a: String, b: String): Boolean = {
    MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8))
  }
}

// isEqual() does HMAC digest comparison: constant time--> safe from timing attacks.
// "This method is null-safe and evaluates the equality in constant-time rather than "short-circuiting" on the first inequality"
@deprecated("CSRFTokenSigner's singleton object can be replaced by MessageDigest.isEqual", "2.6.0")
object CSRFTokenSigner {

  /**
   * @deprecated Please use [[java.security.MessageDigest.isEqual]] over this method.
   */
  @deprecated("Consider java.security.MessageDigest.isEqual", "2.6.0")
  def constantTimeEquals(a: String, b: String): Boolean = {
    MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8))
  }
}

// the CSRFToken signer object is an object of the DefaultCSRFTokenSigner class (it has methods for generating, signing, unsigning and comparing)
@Singleton
class CSRFTokenSignerProvider @Inject() (signer: CookieSigner) extends Provider[CSRFTokenSigner] {
  lazy val get: CSRFTokenSigner = new DefaultCSRFTokenSigner(signer, Clock.systemUTC())
}