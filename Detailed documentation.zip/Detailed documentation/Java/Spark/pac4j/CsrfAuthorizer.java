

 // THIS IS THE SOURCE CODE THAT HANDLES CSRF VERIFICATION

package org.pac4j.core.authorization.authorizer;

import org.pac4j.core.util.Pac4jConstants;
import org.pac4j.core.context.WebContext;
import org.pac4j.core.profile.UserProfile;

import java.util.List;
import java.util.Optional;

import static org.pac4j.core.context.ContextHelper.*;

/**
 * Authorizer that checks CSRF tokens.
 *
 * @author Jerome Leleu
 * @since 1.8.0
 */
 
public class CsrfAuthorizer implements Authorizer<UserProfile> {

    private String parameterName = Pac4jConstants.CSRF_TOKEN;          //pac4jCsrfToken

    private String headerName = Pac4jConstants.CSRF_TOKEN;             //pac4jCsrfToken

    private boolean checkAllRequests = false;

    public CsrfAuthorizer() {
    }

    public CsrfAuthorizer(final String parameterName, final String headerName) {
        this.parameterName = parameterName;
        this.headerName = headerName;
    }

    public CsrfAuthorizer(final String parameterName, final String headerName, final boolean checkAllRequests) {
        this(parameterName, headerName);
        this.checkAllRequests = checkAllRequests;
    }

    // CSRF verification
    @Override
    public boolean isAuthorized(final WebContext context, final List<UserProfile> profiles) { // only POST, PUT, DELETE, PATCH request methods require CSRF check
        final boolean checkRequest = checkAllRequests || isPost(context) || isPut(context) || isPatch(context) || isDelete(context);
        if (checkRequest) { // retrieve the CSRF token from the request's body. If missing, it returns null.
            final String parameterToken = context.getRequestParameter(parameterName).orElse(null);
            // retrieve the CSRF token from the request's custom header. If missing, it returns null.
            final String headerToken = context.getRequestHeader(headerName).orElse(null);
            // retrieves the attribute that holds the CSRF token. It is stored as an attribute named pac4jCsrfToken.
            final Optional<String> sessionToken = (Optional<String>) context.getSessionStore().get(context, Pac4jConstants.CSRF_TOKEN);
            // if CSRF token is in the session AND it is equal to the CSRF token in the request (either body or custom header), the request is OK.
            // If any of the conditions is false (either not equal or no token in session), false is returned= CSRF attempt.
            // note that if token in request is missing, session token is compared against null.
            // equals() is a JAVA built-in function (String class) that is not secure to timing attacks ( same function as in Spring Security) unless overriden
            // sessionToken.get() gets the CSRF token value from the session attribute (that holds the csrf token) above.
            return sessionToken.isPresent() && (sessionToken.get().equals(parameterToken) || sessionToken.get().equals(headerToken));
        } else { // safe method so don't do anything
            return true;
        }
    }

    public String getParameterName() {
        return parameterName;
    }

    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    public String getHeaderName() {
        return headerName;
    }

    public void setHeaderName(String headerName) {
        this.headerName = headerName;
    }

    public boolean isCheckAllRequests() {
        return checkAllRequests;
    }

    public void setCheckAllRequests(final boolean checkAllRequests) {
        this.checkAllRequests = checkAllRequests;
    }
}