
 
 // THIS CLASS HANDLES TOKEN RETRIEVAL AND GENERATION (WHEN NO TOKEN IS PRESENT)

package org.pac4j.core.matching.matcher.csrf;

import org.pac4j.core.util.Pac4jConstants;
import org.pac4j.core.context.WebContext;

import java.util.Optional;

/**
 * Default CSRF token generator.
 *
 * @author Jerome Leleu
 * @since 1.8.0
 */

public class DefaultCsrfTokenGenerator implements CsrfTokenGenerator {

    @Override
    public String get(final WebContext context) {
        // tries to get the CSRF token from the session
        Optional<String> token = getTokenFromSession(context);
        // if no token is stored in the session, a new one needs to be generated
        if (!token.isPresent()) {
            synchronized (this) {
                token = getTokenFromSession(context);
                if (!token.isPresent()) {
                    // same as in Spring Security, it uses randomUUID to retrieve a type 4 (pseudo randomly generated) UUID from a CSPRNG
                    // it is 16 bytes (but 122 bits of entropy) and is converted in hexadecimal (32 chars)
                    token = Optional.of(java.util.UUID.randomUUID().toString());
                    // after token is generated, it is stored in the session.
                    context.getSessionStore().set(context, Pac4jConstants.CSRF_TOKEN, token.get());
                }
            }
        }
        // token exists in the session so it is reused, not regenerated.
        return token.get();
    }
 
    // used above to get the session attribute that contains the CSRF token.
    protected Optional<String> getTokenFromSession(final WebContext context) {
        return (Optional<String>) context.getSessionStore().get(context, Pac4jConstants.CSRF_TOKEN);
    }
}