

Server - contains the methods and functions that handle the CSRF defense (generation, retrieval, verification).


csrf - handles requests and response. It calls the methods and classes of "Server" folder for CSRF and other functionalities