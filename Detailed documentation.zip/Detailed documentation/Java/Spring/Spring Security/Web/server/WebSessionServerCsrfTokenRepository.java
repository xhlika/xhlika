/*
 * Copyright 2002-2017 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
 
 // THIS IS THE CLASS RESPONSIBLE FOR TOKEN GENERATION, STORAGE AND RETRIEVAL FROM THE SERVER0SIDE SESSION STORAGE.

package org.springframework.security.web.server.csrf;

import org.springframework.util.Assert;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Map;
import java.util.UUID;

/**
 * A {@link ServerCsrfTokenRepository} that stores the {@link CsrfToken} in the
 * {@link HttpSession}.
 *
 * @author Rob Winch
 * @since 5.0
 */
 
public class WebSessionServerCsrfTokenRepository
	implements ServerCsrfTokenRepository {
	private static final String DEFAULT_CSRF_PARAMETER_NAME = "_csrf";

	private static final String DEFAULT_CSRF_HEADER_NAME = "X-CSRF-TOKEN";

	private static final String DEFAULT_CSRF_TOKEN_ATTR_NAME = WebSessionServerCsrfTokenRepository.class
			.getName().concat(".CSRF_TOKEN");

	private String parameterName = DEFAULT_CSRF_PARAMETER_NAME;

	private String headerName = DEFAULT_CSRF_HEADER_NAME;

	private String sessionAttributeName = DEFAULT_CSRF_TOKEN_ATTR_NAME;

    // this is how it is always done when a class "implements" an interface class  (ServerCsrfTokenRepository in this case)
    // @Override is used to override the (abstract) methods that are declared in the interface class. They are filled in with a body for the already-defined method signature
    // This function generates the CSRF token (see createCsrfToken() below)
	@Override
	public Mono<CsrfToken> generateToken(ServerWebExchange exchange) {
		return Mono.fromCallable(() -> createCsrfToken());
	}

    // this function stores the token in the current session (putToken()) 
	@Override
	public Mono<Void> saveToken(ServerWebExchange exchange, CsrfToken token) {
		return exchange.getSession()
			.doOnNext(session -> putToken(session.getAttributes(), token))
			.flatMap(session -> session.changeSessionId());
	}

   // actual function that stores the token in the server-side storage
	private void putToken(Map<String, Object> attributes, CsrfToken token) {
        // documentation: "passing null as value for the token, is the same as deleting it", which is the case here. CSRF token attribute is removed from the session
		if (token == null) {
			attributes.remove(this.sessionAttributeName);
		} else {
            // the token is placed in the session under the responsible attribute (it has a default name retrieved from above)
			attributes.put(this.sessionAttributeName, token);
		}
	}

    // searches on the current session by the specific CSRF attribute and retrieves the value (the CSRF token) that this attribute contains
	@Override
	public Mono<CsrfToken> loadToken(ServerWebExchange exchange) {
		return exchange.getSession()
			.filter( s -> s.getAttributes().containsKey(this.sessionAttributeName))
			.map(s -> s.getAttribute(this.sessionAttributeName));
	}

	/**
	 * Sets the {@link HttpServletRequest} parameter name that the {@link CsrfToken} is
	 * expected to appear on
	 * @param parameterName the new parameter name to use
	 */
    // when this function is called, the CSRF parameter name is set (default) to _csrf
	public void setParameterName(String parameterName) {
		Assert.hasLength(parameterName, "parameterName cannot be null or empty");
		this.parameterName = parameterName;
	}

	/**
	 * Sets the header name that the {@link CsrfToken} is expected to appear on and the
	 * header that the response will contain the {@link CsrfToken}.
	 *
	 * @param headerName the new header name to use
	 */
    // when this function is called, the CSRF custom header is set (default) to X-CSRF-TOKEN
	public void setHeaderName(String headerName) {
		Assert.hasLength(headerName, "headerName cannot be null or empty");
		this.headerName = headerName;
	}

	/**
	 * Sets the {@link HttpSession} attribute name that the {@link CsrfToken} is stored in
	 * @param sessionAttributeName the new attribute name to use
	 */
    // in case developer doesn't want to use the default attribute to store the token in the session, this method can be used to change the name of attribute
	public void setSessionAttributeName(String sessionAttributeName) {
		Assert.hasLength(sessionAttributeName,
				"sessionAttributename cannot be null or empty");
		this.sessionAttributeName = sessionAttributeName;
	}

    // It returns a DefaultCsrfToken object which allows server-side to access token, parameter and header name. See DefaultCsrfToken.java  file for more info.
    // Note that regardless of Plain Token or Double Submit mechanism, in the end both classes create this object.
    // With either configuration, server-side will call the methods of DefaultCsrfToken, whos methods are override by the corresponding files of Plain Token
    // or Double Submit mechanims.
	private CsrfToken createCsrfToken() {
		return new DefaultCsrfToken(this.headerName, this.parameterName, createNewToken());
	}

    // the actual function that generates the CSRF token.
    // The randomUUID() method is used to retrieve a type 4 (pseudo randomly generated) UUID. 
    // The UUID is generated using a cryptographically strong pseudo random number generator.
    // Result is 16 bytes with 122 bits of entropy (since 6 bits are used to contain the version and are not random), which is then converted to string: secure.
	private String createNewToken() {
		return UUID.randomUUID().toString();
	}

}