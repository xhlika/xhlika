package org.springframework.security.web.server.csrf;

import org.springframework.util.Assert;

/**
 * A CSRF token that is used to protect against CSRF attacks.
 *
 * @author Rob Winch
 * @since 5.0
 */
 
@SuppressWarnings("serial")
public final class DefaultCsrfToken implements CsrfToken {

	private final String token;

	private final String parameterName;

	private final String headerName;

	/**
	 * Creates a new instance
	 * @param headerName the HTTP header name to use
	 * @param parameterName the HTTP parameter name to use
	 * @param token the value of the token (i.e. expected value of the HTTP parameter of
	 * parametername).
	 */
     
     // the constructor of this class takes the CSRF header name, parameter name (form field) and the token as parameter
     // all these are required. Basically this class takes this and makes them available to whatevr class extends this one
     // for that you use the above methods to get the header name, parameter name and the csrf token 
     
     // IMPORTANT: these are called in the other CSRF folder in web.csrf (here we are at web.server.csrf)
	public DefaultCsrfToken(String headerName, String parameterName, String token) {
		Assert.hasLength(headerName, "headerName cannot be null or empty");
		Assert.hasLength(parameterName, "parameterName cannot be null or empty");
		Assert.hasLength(token, "token cannot be null or empty");
		this.headerName = headerName;
		this.parameterName = parameterName;
		this.token = token;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.springframework.security.web.csrf.CsrfToken#getHeaderName()
	 */
     // returns the name of CSRF header (X-CSRF-Token)
	public String getHeaderName() {
		return this.headerName;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.springframework.security.web.csrf.CsrfToken#getParameterName()
	 */
    //// returns the name of CSRF form field (_csrf)
	public String getParameterName() {
		return this.parameterName;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.springframework.security.web.csrf.CsrfToken#getToken()
	 */
    // returns the csrf token itself.
	public String getToken() {
		return this.token;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || !(o instanceof CsrfToken))
			return false;

		CsrfToken that = (CsrfToken) o;

		if (!getToken().equals(that.getToken()))
			return false;
		if (!getParameterName().equals(that.getParameterName()))
			return false;
		return getHeaderName().equals(that.getHeaderName());
	}

    // hashes the csrf token + parameter name + csrf header for some reason
	@Override
	public int hashCode() {
		int result = getToken().hashCode();
		result = 31 * result + getParameterName().hashCode();
		result = 31 * result + getHeaderName().hashCode();
		return result;
	}
}