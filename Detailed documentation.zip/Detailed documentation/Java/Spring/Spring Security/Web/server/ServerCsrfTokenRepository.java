/*
 * Copyright 2002-2017 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
 
// THIS IS THE CSRF REPOSITORY FOR THE DEFAULT PLAIN TOKEN MECHANISM  

package org.springframework.security.web.server.csrf;

import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * An API to allow changing the method in which the expected {@link CsrfToken} is
 * associated to the {@link ServerWebExchange}. For example, it may be stored in
 * {@link org.springframework.web.server.WebSession}.
 *
 * @see WebSessionServerCsrfTokenRepository
 *
 * @author Rob Winch
 * @since 5.0
 *
 */
 
 /**just an interface of APIs.
// https://www.geeksforgeeks.org/interfaces-in-java/ ->what are interfaces?basically just abstract classes with only method signatures
// (head of a function) and variables that are public static (It is a variable which belongs to the class and not to object(instance ). 
// Static variables initialized only once, at the start of the execution.) final (constant variable that cannot be override, if used for classes:) 
// the class that calls "y implements x", will provide the body for these methods. 1 reason to use them? you can only inherit/extend from 1 class only
   3 APIs: token generation, token storage in the configured repository and retrieve the CSRF token.
 
 **/
// interface of HttpSession/WebSessionCsrfRepository
// This is the default CSRF repository that is used in Spring-Security, which implements Plain Token mechanism
// 3 methods: generate token, save the token in the session server-side and load/retrieve the token from the session server-side
public interface ServerCsrfTokenRepository {

	/**
	 * Generates a {@link CsrfToken}
	 *
	 * @param exchange the {@link ServerWebExchange} to use
	 * @return the {@link CsrfToken} that was generated. Cannot be null.
	 */
	Mono<CsrfToken> generateToken(ServerWebExchange exchange);

	/**
	 * Saves the {@link CsrfToken} using the {@link ServerWebExchange}. If the
	 * {@link CsrfToken} is null, it is the same as deleting it.
	 *
	 * @param exchange the {@link ServerWebExchange} to use
	 * @param token the {@link CsrfToken} to save or null to delete
	 */
	Mono<Void> saveToken(ServerWebExchange exchange, CsrfToken token);

	/**
	 * Loads the expected {@link CsrfToken} from the {@link ServerWebExchange}
	 *
	 * @param exchange the {@link ServerWebExchange} to use
	 * @return the {@link CsrfToken} or null if none exists
	 */
	Mono<CsrfToken> loadToken(ServerWebExchange exchange);
}