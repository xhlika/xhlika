<?php


// THIS IS THE SOURCE CODE OF THE ANTI-CSRF MECHANISM IN LARAVEL. IT CAN BE CONSIDERED AS THE CSRF MIDDLEWARE THAT TAKES CARE OF VERIFYING FOR CSRF BEFORE THE REQUEST REACHES THE DESTINATION ROUTE 
namespace Illuminate\Foundation\Http\Middleware;

use Closure;
use Illuminate\Contracts\Encryption\Encrypter;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\Support\Responsable;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Session\TokenMismatchException;
use Illuminate\Support\InteractsWithTime;
use Symfony\Component\HttpFoundation\Cookie;



class VerifyCsrfToken
{
    use InteractsWithTime;

    /**
     * The application instance.
     *
     * @var \Illuminate\Contracts\Foundation\Application
     */
    protected $app;           // the web application

    /**
     * The encrypter implementation.
     *
     * @var \Illuminate\Contracts\Encryption\Encrypter
     */
    protected $encrypter;         // encrypts the CSRF cookie (for Angular, this mechanism is not Double Submit) with AES-256

    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [];                 // the routes to be excluded from the CSRF check

    /**
     * Indicates whether the XSRF-TOKEN cookie should be set on the response.
     *
     * @var bool
     */
    protected $addHttpCookie = true;       // by default the CSRF cookie will be sent

    /**
     * Create a new middleware instance.
     *
     * @param  \Illuminate\Contracts\Foundation\Application  $app
     * @param  \Illuminate\Contracts\Encryption\Encrypter  $encrypter
     * @return void
     */
    public function __construct(Application $app, Encrypter $encrypter)
    {
        $this->app = $app;
        $this->encrypter = $encrypter;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     *
     * @throws \Illuminate\Session\TokenMismatchException
     */
     
     // this is the main function that does the CSRF verification
    public function handle($request, Closure $next)
    {
        // if the request is a (1) safe request method (GET, HEAD, OPTIONS), (2) we are in testing mode (not production), (3) if route is excluded, or (4) if token matches
        // if any of these above is true, then the request is accepted and an encrypted CSRF cookie is added to the response
        // If all 4 (1,2,3,4) conditions return false, then the request is denied--> CSRF attempt
        if (
            $this->isReading($request) ||          
            $this->runningUnitTests() ||
            $this->inExceptArray($request) ||
            $this->tokensMatch($request)
        ) {
            return tap($next($request), function ($response) use ($request) {
                if ($this->shouldAddXsrfTokenCookie()) {
                    $this->addCookieToResponse($request, $response);
                }
            });
        }

        throw new TokenMismatchException('CSRF token mismatch.');
    }

    /**
     * Determine if the HTTP request uses a ‘read’ verb.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return bool
     */
     
     // check whether the request method is a "safe" method. Returns true if the request is a safe request method, i.e. skip CSRF verification.
    protected function isReading($request)
    {
        return in_array($request->method(), ['HEAD', 'GET', 'OPTIONS']);
    }

    /**
     * Determine if the application is running unit tests.
     *
     * @return bool
     */
     
     // tells whether we are in production mode or in test mode. In test mode CSRF verification is disabled.
    protected function runningUnitTests()
    {
        return $this->app->runningInConsole() && $this->app->runningUnitTests();
    }

    /**
     * Determine if the request has a URI that should pass through CSRF verification.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return bool
     */
     
     // checks if the destination route is in the list of routes to be ignored by the CSRF verification. The list is specified by developer in:
     //https://github.com/laravel/laravel/blob/master/app/Http/Middleware/VerifyCsrfToken.php (by default it is empty)
    protected function inExceptArray($request)
    {
        foreach ($this->except as $except) {    
            if ($except !== '/') {
                $except = trim($except, '/');
            }

            if ($request->fullUrlIs($except) || $request->is($except)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Determine if the session and input CSRF tokens match.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return bool
     */
     
     // the actual function that does token comparison
    protected function tokensMatch($request)
    {
        $token = $this->getTokenFromRequest($request);    // check function below, it retrieves the "plain"/decrypted CSRF token from request's body or custom header.

        return is_string($request->session()->token()) && // makes sure that the CSRF token in the session and in the request are string
               is_string($token) &&                       // https://www.php.net/manual/en/function.is-string.php
               hash_equals($request->session()->token(), $token);  // secure from timing attacks: https://www.php.net/manual/en/function.hash-equals.php
    }

    /**
     * Get the CSRF token from the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return string
     */
     
     // retrieves the "plain" CSRF token from request. Tt first tries to get it from the request's body, otherwise in X-CSRF-TOKEN custom header. if not found, it will check for the X-XSRF-TOKEN header 
     // (added automatically by Axio library or Angular). This is ENCRYPTED CSRF token(added by Angular) therefore, if that token is to be used it has to be decrypted. The "plain"/decrypted token is returned.
    protected function getTokenFromRequest($request)
    {
        $token = $request->input('_token') ?: $request->header('X-CSRF-TOKEN');

        if (! $token && $header = $request->header('X-XSRF-TOKEN')) {
            $token = $this->encrypter->decrypt($header, static::serialized());
        }

        return $token;
    }

    /**
     * Determine if the cookie should be added to the response.
     *
     * @return bool
     */
     
     // just returns true/false whether to send the CSRF cookie or not. By default= true.
    public function shouldAddXsrfTokenCookie()
    {
        return $this->addHttpCookie;
    }

    /**
     * Add the CSRF token to the response cookies.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Symfony\Component\HttpFoundation\Response  $response
     * @return \Symfony\Component\HttpFoundation\Response
     */
     
     // attaches the CSRF token to the response.
    protected function addCookieToResponse($request, $response)
    {
        $config = config('session');  // needed to retrieve the configuration details for the cookie.

        if ($response instanceof Responsable) {
            $response = $response->toResponse($request);
        }

        $response->headers->setCookie(
            new Cookie( // stores the "plain"/decrypted token (retrieved from session) to the cookie (which will then be encrypted)
                'XSRF-TOKEN', $request->session()->token(), $this->availableAt(60 * $config['lifetime']),
                $config['path'], $config['domain'], $config['secure'], false, false, $config['same_site'] ?? null  // samesite=lax, but pointless for CSRF cookies
            )                                                                                                      // since this is not Double Submit mechanism. Cookie is created to support Angular
        ); 

        return $response;
    }

    /**
     * Determine if the cookie contents should be serialized.
     *
     * @return bool
     */
    public static function serialized()
    {
        return EncryptCookies::serialized('XSRF-TOKEN');
    }
}

