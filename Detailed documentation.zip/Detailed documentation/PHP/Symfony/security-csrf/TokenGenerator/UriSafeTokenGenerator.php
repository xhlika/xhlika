<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */


// THIS CLASS IS RESPONSIBLE FOR CSRF TOKEN GENERATION

namespace Symfony\Component\Security\Csrf\TokenGenerator;

/**
 * Generates CSRF tokens.
 *
 * @author Bernhard Schussek <bernhard.schussek@symfony.com>
 */
class UriSafeTokenGenerator implements TokenGeneratorInterface
{
    private $entropy;

    /**
     * Generates URI-safe CSRF tokens.
     *
     * @param int $entropy The amount of entropy collected for each token (in bits)
     */
     
     // by default, Symfony generates CSRF tokens with 256 bits of entropy (quite secure), which translates into 256/8= 32-byte CSRF token
    public function __construct(int $entropy = 256)
    {
        $this->entropy = $entropy;
    }

    /**
     * {@inheritdoc}
     */
    public function generateToken()
    {
        // Generate an URI safe base64 encoded string that does not contain "+",
        // "/" or "=" which need to be URL encoded and make URLs unnecessarily
        // longer.
        
        // same as in Laravel, it uses PHP's random_bytes to generate random bytes. In this case, 32 random bytes--> secure and with enough entropy. 
        $bytes = random_bytes($this->entropy / 8);
        // the bytes are converted to base64 format to be URI-safe/compatible, and then it is converted to string, which has a length of 43.
        return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '=');
    }
}