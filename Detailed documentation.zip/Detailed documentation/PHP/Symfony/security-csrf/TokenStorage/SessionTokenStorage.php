<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
 
 

// THIS IS THE DEFAULT SESSION STORAGE THAT IS USED WHEN CSRF PROTECTION IS ENABLED. IT IS CONFIGURED/MENTIONED HERE:
// https://github.com/symfony/symfony/blob/master/src/Symfony/Bundle/FrameworkBundle/Resources/config/security_csrf.xml 
//  CHECK ClearableTokenStorageInterface AND TokenStorageInterface INTERFACE CLASSES FOR A DETAILED DESCRIPTION OF EACH FUNCTION BELOW (HERE: https://github.com/symfony/security-csrf/tree/master/TokenStorage)
namespace Symfony\Component\Security\Csrf\TokenStorage;

use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Security\Csrf\Exception\TokenNotFoundException;

/**
 * Token storage that uses a Symfony Session object.
 *
 * @author Bernhard Schussek <bschussek@gmail.com>
 */
class SessionTokenStorage implements ClearableTokenStorageInterface
{
    /**
     * The namespace used to store values in the session.
     */
     
     // the session's attribute where the CSRF token will be stored: _csrf/token_id (see below at getToken()).
     // Note that more than 1 CSRF token is stored in the server-side session storage since a user might have multiple csrf-protected forms with different names.
    const SESSION_NAMESPACE = '_csrf';

    private $session;
    private $namespace;

    /**
     * Initializes the storage with a Session object and a session namespace.
     *
     * @param string $namespace The namespace under which the token is stored in the session
     */
     
     // why are namespaces needed? https://symfony.com/blog/cve-2017-16653-csrf-protection-does-not-use-different-tokens-for-http-and-https
    public function __construct(SessionInterface $session, string $namespace = self::SESSION_NAMESPACE)
    {
        $this->session = $session;
        $this->namespace = $namespace;
    }

    /**
     * {@inheritdoc}
     */
     
     // this function retrieves the token OBJECT (id and value) from the session's attribute
    public function getToken(string $tokenId)
    {
        if (!$this->session->isStarted()) {
            $this->session->start();
        }
        
        // it checks whether there is a CSRF token object stored in the session with the given token id (under _csrf/token_id). It throws an error if nothing is found
        if (!$this->session->has($this->namespace.'/'.$tokenId)) {
            throw new TokenNotFoundException('The CSRF token with ID '.$tokenId.' does not exist.');
        }
  
        // a CSRF token object with the provided tokenId was found, so it is returned to the caller of this function
        return (string) $this->session->get($this->namespace.'/'.$tokenId);
    }

    /**
     * {@inheritdoc}
     */
     
     //this function will store the token object in the session (_csrf/token_id)
    public function setToken(string $tokenId, string $token)
    {
        if (!$this->session->isStarted()) {
            $this->session->start();
        }
         // places the token object in the session storage
        $this->session->set($this->namespace.'/'.$tokenId, $token);
    }

    /**
     * {@inheritdoc}
     */
     
     // boolean function that tells whether the session contains a CSRF token object or not for the given tokenId
    public function hasToken(string $tokenId)
    {
        if (!$this->session->isStarted()) {
            $this->session->start();
        }

        return $this->session->has($this->namespace.'/'.$tokenId);
    }

    /**
     * {@inheritdoc}
     */
     
     // might be called by developer to clear all CSRF tokens, e.g. when user logs out.
    public function removeToken(string $tokenId)
    {
        if (!$this->session->isStarted()) {
            $this->session->start();
        }

        return $this->session->remove($this->namespace.'/'.$tokenId);
    }

    /**
     * {@inheritdoc}
     */
     // this removes all CSRF tokens in the session storage
    public function clear()
    {
        foreach (array_keys($this->session->all()) as $key) {
            if (0 === strpos($key, $this->namespace.'/')) {
                $this->session->remove($key);
            }
        }
    }
}