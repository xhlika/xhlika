<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
 
 
 
// THIS IS THE MAIN CLASS OF THE ANTI-CSRF MECHANISM (AS THE NAME SUGGESTED), I.E. THE CSRF MIDDLEWARE IN SYMFONY
// IT WILL CALL THE RESPECTIVE FUNCTIONS TO RETRIEVE THE CSRF TOKEN OBJECT FROM THE SESSION, TOKEN GENERATION AND STORAGE IN SESSION STORAGE  AND ALSO CSRF VERIFICATION (SEE THE OTHER FILES IN THE FOLDER). 
// EACH FUNCTION IS EXPLAINED HERE: https://github.com/symfony/security-csrf/blob/master/CsrfTokenManagerInterface.php

namespace Symfony\Component\Security\Csrf;

use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\Security\Core\Exception\InvalidArgumentException;
use Symfony\Component\Security\Csrf\TokenGenerator\TokenGeneratorInterface;
use Symfony\Component\Security\Csrf\TokenGenerator\UriSafeTokenGenerator;
use Symfony\Component\Security\Csrf\TokenStorage\NativeSessionTokenStorage;
use Symfony\Component\Security\Csrf\TokenStorage\TokenStorageInterface;

/**
 * Default implementation of {@link CsrfTokenManagerInterface}.
 *
 * @author Bernhard Schussek <bschussek@gmail.com>
 * @author Kévin Dunglas <dunglas@gmail.com>
 */
class CsrfTokenManager implements CsrfTokenManagerInterface
{
    private $generator;
    private $storage;
    private $namespace;

// IMPORTANT: namespaces differ for http (just tokenid) and https connections (generated_namespace/tokenid).
    /**
     * @param string|RequestStack|callable|null $namespace
     *                                                     * null: generates a namespace using $_SERVER['HTTPS']
     *                                                     * string: uses the given string
     *                                                     * RequestStack: generates a namespace using the current master request
     *                                                     * callable: uses the result of this callable (must return a string)
     */
     
     
    public function __construct(TokenGeneratorInterface $generator = null, TokenStorageInterface $storage = null, $namespace = null)
    {   
        //https://github.com/symfony/symfony/blob/master/src/Symfony/Bundle/FrameworkBundle/Resources/config/security_csrf.xml 
        $this->generator = $generator ?: new UriSafeTokenGenerator();  // there is only one generator, provided in the config file.
        $this->storage = $storage ?: new NativeSessionTokenStorage();  // this is like a fallback if nothing is specified
                                                                       // however this is configured to be SessionTokenStorage() in the config file.

        $superGlobalNamespaceGenerator = function () {
            return !empty($_SERVER['HTTPS']) && 'off' !== strtolower($_SERVER['HTTPS']) ? 'https-' : '';
        };

        // different namespaces for http and https: https://symfony.com/blog/cve-2017-16653-csrf-protection-does-not-use-different-tokens-for-http-and-https 
        // It sets the namespace attribute of this class which is used when the token is retrieved, normally it is just the token_id for hppt.
        // For https it is:
        if (null === $namespace) {
            $this->namespace = $superGlobalNamespaceGenerator;
        } elseif ($namespace instanceof RequestStack) {
            $this->namespace = function () use ($namespace, $superGlobalNamespaceGenerator) {
                if ($request = $namespace->getMasterRequest()) {
                    return $request->isSecure() ? 'https-' : '';
                }

                return $superGlobalNamespaceGenerator();
            };
        } elseif (\is_callable($namespace) || \is_string($namespace)) {
            $this->namespace = $namespace;
        } else {
            throw new InvalidArgumentException(sprintf('$namespace must be a string, a callable returning a string, null or an instance of "RequestStack". "%s" given.', get_debug_type($namespace)));
        }
    }

    /**
     * {@inheritdoc}
     */
     
     // function that retrieves the CSRF token form the session storage. it is called by csrf_token() when developer calls it in an HTML form. It calls the getToken() function of the SessionTokenStorage.php
     // token_id is usually provided when the token is generated (automatically by Symfony forms) by the developer in the form (e.g. with: csrf_token('test'))
    public function getToken(string $tokenId)
    {
        // search on the session by token Id 
        $namespacedId = $this->getNamespace().$tokenId;
        // first it checks whether there is an object in the session storage stored with this token id (under _csrf/token_id attribute)
        if ($this->storage->hasToken($namespacedId)) {
            $value = $this->storage->getToken($namespacedId);
        } else {
            // otherwise, there is no token in the session (e.g. GET request when the login form is requested), generate a new one. 
            $value = $this->generator->generateToken();
            // the generated token is placed in the session under the _csrf/token_id (token_id varies based on the id specified by developer)
            $this->storage->setToken($namespacedId, $value);
        }
        
        // returns the CSRF token as an object (id, csrf_token_value)
        return new CsrfToken($tokenId, $value);
    }

    /**
     * {@inheritdoc}
     */
     
    //This method will generate a new token for the given token ID, independent of whether a token value previously existed or not. It can be used to
    // enforce once-only tokens in environments with high security needs. It returns a new CSRF token object which is also stored in the session
    public function refreshToken(string $tokenId)
    {
        $namespacedId = $this->getNamespace().$tokenId;
        $value = $this->generator->generateToken();

        $this->storage->setToken($namespacedId, $value);

        return new CsrfToken($tokenId, $value);
    }

    /**
     * {@inheritdoc}
     */
     
     // Invalidates the CSRF token with the given ID, if one exists, e.g. on log out.
     // it does this by calling removeToken() function in SessionTokenStorage class.
    public function removeToken(string $tokenId)
    {
        return $this->storage->removeToken($this->getNamespace().$tokenId);
    }

    /**
     * {@inheritdoc}
     */
     
     // this is the function that Symfony uses to do the CSRF check. There is another function that developer can use manually on special cases: isCsrfTokenValid() 
     // which in turns calls this function here. isCsrfTokenValid() is found https://github.com/symfony/symfony/blob/5.0/src/Symfony/Bundle/FrameworkBundle/Controller/AbstractController.php
     // This function gets the CSRF token object of the request as parameter
    public function isTokenValid(CsrfToken $token)
    {   
         //gets the token_id from the token object and creates the full attribute name, needed to search in the server-side session storage
        $namespacedId = $this->getNamespace().$token->getId();
        // if no token is found in the session under  _csrf/token_id, then there is no point continuing, return false--> CSRF attempt
        if (!$this->storage->hasToken($namespacedId)) {
            return false;
        }
         
        // if there is a CSRF token in the session, then it will perform a comparison (secure from timing attacks) between the token in the session and the token in req
        // hash_equals()--> true: valid req, false--> CSRF attempt=tokens didn't match
        return hash_equals($this->storage->getToken($namespacedId), $token->getValue());
    }

    private function getNamespace(): string
    {
        return \is_callable($ns = $this->namespace) ? $ns() : $ns;
    }
}