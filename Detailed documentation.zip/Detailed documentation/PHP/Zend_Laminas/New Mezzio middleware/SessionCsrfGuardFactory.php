<?php

/**
 * @see       https://github.com/mezzio/mezzio-csrf for the canonical source repository
 * @copyright https://github.com/mezzio/mezzio-csrf/blob/master/COPYRIGHT.md
 * @license   https://github.com/mezzio/mezzio-csrf/blob/master/LICENSE.md New BSD License
 */
 
 
 // THIS IS THE CLASS THAT INITIATES THE DEFAULT CSRF FACTORY, WHICH IS SESSION-BASED. THIS CLASS IS INVOKED WHEN THE CSRF MIDDLEWARE IS ENABLED.
declare(strict_types=1);

namespace Mezzio\Csrf;

use Mezzio\Session\SessionInterface;
use Mezzio\Session\SessionMiddleware;
use Psr\Http\Message\ServerRequestInterface;

// this factory (session-based) is the default CsrfGuardFactory that is invoked by the CsrfMiddleware. It will create the session-based CSRF GUARD.
class SessionCsrfGuardFactory implements CsrfGuardFactoryInterface   //https://github.com/mezzio/mezzio-csrf/blob/master/src/CsrfGuardFactoryInterface.php
{
    /**
     * @var string
     */
    private $attributeKey;

    public function __construct(string $attributeKey = SessionMiddleware::SESSION_ATTRIBUTE)  // attribute:csrf
    {
        $this->attributeKey = $attributeKey;
    }

    public function createGuardFromRequest(ServerRequestInterface $request) : CsrfGuardInterface
    {
        // if no session exists, then a new one needs to be created. This anti-csrf mechanism canot function without a session since token is stored there
        $session = $request->getAttribute($this->attributeKey, false);
        if (! $session instanceof SessionInterface) {
            throw Exception\MissingSessionException::create();
        }

        //if session exists, the session-based CSRF guard is initiated and takes the current session as parameter (needed e.g. for CSRF token verification)
        return new SessionCsrfGuard($session);
    }
}