<?php

/**
 * @see       https://github.com/mezzio/mezzio-csrf for the canonical source repository
 * @copyright https://github.com/mezzio/mezzio-csrf/blob/master/COPYRIGHT.md
 * @license   https://github.com/mezzio/mezzio-csrf/blob/master/LICENSE.md New BSD License
 */


// THE DEFAULT CSRF GUARD IS THE SESSION GUARD. THE DEVELOPER CAN ALSO MODIFY IT AND USE FLASH-BASED CSRF GUARD BUT SESSION GUARD IS THE DEFAULT
// HENCE THE ONLY ONE WE CONSIDER. NEVERTHELESS, THE GENERATION AND VALIDATION ARE DONE IN AN IDENTICAL WAY SO THE REASONING WORKS FOR BOTH.
declare(strict_types=1);

namespace Mezzio\Csrf;

class ConfigProvider
{
    public function __invoke() : array
    {
        return [
            'dependencies' => $this->getDependencies(),
        ];
    }

    public function getDependencies() : array
    {
        return [
            'aliases' => [
                // Change this to the CsrfGuardFactoryInterface implementation you wish to use:
                CsrfGuardFactoryInterface::class => SessionCsrfGuardFactory::class,

                // Legacy Zend Framework aliases
                \Zend\Expressive\Csrf\CsrfGuardFactoryInterface::class => CsrfGuardFactoryInterface::class,
                \Zend\Expressive\Csrf\FlashCsrfGuardFactory::class => FlashCsrfGuardFactory::class,
                \Zend\Expressive\Csrf\SessionCsrfGuardFactory::class => SessionCsrfGuardFactory::class,
                \Zend\Expressive\Csrf\CsrfMiddleware::class => CsrfMiddleware::class,
            ],
            'invokables' => [
                FlashCsrfGuardFactory::class   => FlashCsrfGuardFactory::class,
                SessionCsrfGuardFactory::class => SessionCsrfGuardFactory::class,
            ],
            'factories' => [
                CsrfMiddleware::class => CsrfMiddlewareFactory::class,
            ],
        ];
    }
}