<?php

/**
 * @see       https://github.com/mezzio/mezzio-csrf for the canonical source repository
 * @copyright https://github.com/mezzio/mezzio-csrf/blob/master/COPYRIGHT.md
 * @license   https://github.com/mezzio/mezzio-csrf/blob/master/LICENSE.md New BSD License
 */

// THIS CLASS HANDLES THE CSRF TOKEN GENERATION AND VERIFICATION. FOR A DETAILED DESCRIPTION OF FUNCTIONS IMPLEMENTED HERE, CHECK THE INTERFACE CLASS:
// https://github.com/mezzio/mezzio-csrf/blob/master/src/CsrfGuardInterface.php
declare(strict_types=1);

namespace Mezzio\Csrf;

use Mezzio\Session\SessionInterface;

use function bin2hex;
use function random_bytes;


class SessionCsrfGuard implements CsrfGuardInterface    // https://github.com/mezzio/mezzio-csrf/blob/master/src/CsrfGuardInterface.php
{
    /**
     * @var SessionInterface
     */
    private $session; // it takes the session as parameter when this CSRF guard is invoked. Why? CSRF token is stored in the session of the current request

    public function __construct(SessionInterface $session)
    {
        $this->session = $session;
    }
    
    
// generates a 16-byte CSRF token (128 bits of entropy) which will be converted to hexadecimal format (32-char CSRF token)
    public function generateToken(string $keyName = '__csrf') : string
    {
        $token = bin2hex(random_bytes(16));
        $this->session->set($keyName, $token); // the generated CSRF token is also stored in the session under the "_csrf" attribute.
        return $token;
    }

// verifies that the CSRF token in the server-side storage is the same as the CSRF token in the request.
// "token" is the CSRF token of the incoming request
    public function validateToken(string $token, string $csrfKey = '__csrf') : bool
    {
        $storedToken = $this->session->get($csrfKey, ''); // gets the CSRF token stored in server-side session storage
        $this->session->unset($csrfKey);  // after retrieving the token, it is removed from the session (since this mechanism is per-request)
        return $token === $storedToken;   // unsafe string comparison, but it is still safe since it is per-request, brute force is rendered useless.
    }
}