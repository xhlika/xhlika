<?php

/**
 * @see       https://github.com/laminas/laminas-validator for the canonical source repository
 * @copyright https://github.com/laminas/laminas-validator/blob/master/COPYRIGHT.md
 * @license   https://github.com/laminas/laminas-validator/blob/master/LICENSE.md New BSD License
 */


// THIS IS THE CLASS THAT HANDLES THE LOCAL CSRF PROTECTION IN LAMINAS (ONLY IF MANUALLY INVOKED BY THE DEVELOPER, I.E NO GLOBAL DEFENSE AGAINST CSRF).
namespace Laminas\Validator;

use Laminas\Math\Rand;
use Laminas\Session\Container as SessionContainer;
use Laminas\Stdlib\ArrayUtils;
use Traversable;

class Csrf extends AbstractValidator
{
    
    // the variables below are CSRF properties that the developer can decide to provide when invoking the CSRF class, or use the defaults otherwise
    
    /**
     * Error codes
     * @const string
     */
    const NOT_SAME = 'notSame';

    /**
     * Error messages
     * @var array
     */
    protected $messageTemplates = [
        self::NOT_SAME => 'The form submitted did not originate from the expected site',
    ];

    /**
     * Actual hash used.
     *
     * @var mixed
     */
    protected $hash;

    /**
     * Static cache of the session names to generated hashes
     * @todo unused, left here to avoid BC breaks
     *
     * @var array
     */
    protected static $hashCache;

    /**
     * Name of CSRF element (used to create non-colliding hashes)
     *
     * @var string
     */
    protected $name = 'csrf';

    /**
     * Salt for CSRF token
     * @var string
     */
    protected $salt = 'salt';

    /**
     * @var SessionContainer
     */
    protected $session;

    /**
     * TTL for CSRF token
     * @var int|null
     */
    protected $timeout = 300;

    /**
     * Constructor
     *
     * @param  array|Traversable $options
     */
    public function __construct($options = [])
    {
        parent::__construct($options);

        if ($options instanceof Traversable) {
            $options = ArrayUtils::iteratorToArray($options);
        }

        if (! is_array($options)) {
            $options = (array) $options;
        }

        foreach ($options as $key => $value) {
            switch (strtolower($key)) {
                case 'name':
                    $this->setName($value);  // "csrf"
                    break;
                case 'salt':
                    $this->setSalt($value);  // "salt"
                    break;
                case 'session':
                    $this->setSession($value); 
                    break;
                case 'timeout':
                    $this->setTimeout($value);  // TTL for CSRF = 300 sec by def = 5 minutes
                    break;
                default:
                    // ignore unknown options
                    break;
            }
        }
    }

    /**
     * Does the provided token match the one generated?
     *
     * @param  string $value
     * @param  mixed $context
     * @return bool
     */
     
     // function that performs the CSRF verification. It compares the CSRF token from the request ($value) against the value in the session
    public function isValid($value, $context = null)
    {
        // if the CSRF token in the request is null or not a string, it immediately aborts.
        if (! is_string($value)) {
            return false;
        }

        $this->setValue($value);

        // the CSRF token has a format: hashed_token-token_id. the function below retrieves token_id from the CSRF token
        $tokenId = $this->getTokenIdFromHash($value);
        // will retrieve the (full) hashed CSRF token from the session with the given token_id. 
        $hash = $this->getValidationToken($tokenId);

        // retrieves the hashed_token part of the CSRF token of the request
        $tokenFromValue = $this->getTokenFromHash($value);
        // retrieves the hashed_token part of the CSRF token retrieved from the session storage
        $tokenFromHash = $this->getTokenFromHash($hash);

        /* if any of only of these (only hashed_csrf_token part of the CSRF token is compared) CSRF tokens is mising or they are not equal, an error is thrown.
          It performs an insecure string comparison. Although the CSRF token is refreshed after each req, the attacker can keep trying the old value in a brute force attack,
          since the mechanisms stores old CSRF tokens in the session and it does NOT use per-request tokens. Normally, per-request tokens must be discarded after used.
          CSRF tokens are expired after 300sec (5min) so the attacker will have to perform his attack on this short time window (unless extended by developer), but still possible. */
        if (! $tokenFromValue || ! $tokenFromHash || ($tokenFromValue !== $tokenFromHash)) {
            $this->error(self::NOT_SAME);
            return false;
        }

// token was in session and in the incoming request.  If they were equal, then no CSRF --> process request.
        return true;
    }

    /**
     * Set CSRF name
     *
     * @param  string $name
     * @return $this
     */

    public function setName($name)
    {
        $this->name = (string) $name;       // defaults to "csrf"
        return $this;
    }

    /**
     * Get CSRF name
     *
     * @return string
     */

    public function getName()
    {
        return $this->name;       // defaults to "csrf" (set by setName() when constructor was initialized above)
    }

    /**
     * Set session container
     *
     * @param  SessionContainer $session
     * @return $this
     */
     // initialized the session and puts the csrf token in the session storage
    public function setSession(SessionContainer $session)
    {
        $this->session = $session;
        if ($this->hash) {
            $this->initCsrfToken();   // places token in the session storage, see below
        }
        return $this;
    }

    /**
     * Get session container
     *
     * Instantiate session container if none currently exists
     *
     * @return SessionContainer
     */
    public function getSession()
    {
    // if no session was set, a new session will be created by calling setSession() (which is normally called by constructor) and token is stored in it
        if (null === $this->session) {
            // Using fully qualified name, to ensure polyfill class alias is used
            $this->session = new SessionContainer($this->getSessionName());
        }
        // the old or new session is returned.
        return $this->session;
    }

    /**
     * Salt for CSRF token
     *
     * @param  string $salt
     * @return $this
     */
    public function setSalt($salt)
    {
        $this->salt = (string) $salt;   // defaults to "salt"
        return $this;
    }

    /**
     * Retrieve salt for CSRF token
     *
     * @return string
     */
    public function getSalt()
    {
        return $this->salt;    // defaults to "salt", set when constructor is initialized
    }

    /**
     * Retrieve CSRF token
     *
     * If no CSRF token currently exists, or should be regenerated,
     * generates one.
     *
     * @param  bool $regenerate    default false
     * @return string
     */
     
     /* important function, called by Csrf form element (laminas-form): https://github.com/laminas/laminas-form/blob/master/src/Element/Csrf.php#L127
        When no session exists (e.g. GET request for the login form) then this will call getHash(True)(i.e. regenerate=true). This will call generateHash() function to generate the token
        This is why the CSRF token is regenerated in each request, since laminas-form always calls getHash(True) when rendering a form. This will in turn call initCsrfToken() function 
        that will set the token in the new session. That function will again call getHash(), to retrieve the recntly-generated token. Note that getHash() will be called with regenerate=false this time,
        so the CSRF token is not regenerated twice within the same request.
     // Only in this case (called by laminas-form) this function is called with regenerate=true. In all other cases it is called with regenerate=false (default configuration). */
    public function getHash($regenerate = false)
    {
        // the "hash" property of this class  contains a generated csrf token. If it is null, then no token is yet generated.
        // These lines will generate a new one (or if getHash() is called with regenerate set to true)
        if ((null === $this->hash) || $regenerate) {
            $this->generateHash();// function that generates the hash, see below.
        }
        // returns the hashed token.
        return $this->hash;
    }

    /**
     * Get session namespace for CSRF token
     *
     * Generates a session namespace based on salt, element name, and class.
     *
     * @return string
     */
    public function getSessionName()
    {
        return str_replace('\\', '_', __CLASS__) . '_'
            . $this->getSalt() . '_'
            . strtr($this->getName(), ['[' => '_', ']' => '']);
    }

    /**
     * Set timeout for CSRF session token
     *
     * @param  int|null $ttl
     * @return $this
     */
    public function setTimeout($ttl)
    {
        $this->timeout = $ttl !== null ? (int) $ttl : null;   // sets the timeout for the validity of CSRF token. defaults to 300sec= 5min.
        return $this;
    }

    /**
     * Get CSRF session token timeout
     *
     * @return int
     */
    public function getTimeout()
    {
        return $this->timeout;  // defaults to 300 seconds
    }

    /**
     * Initialize CSRF token in session
     *
     * @return void
     */
     
   // calling this function will set the CSRF token in the current session's storage (called when session is initialized or when a token is (re)generated)
    protected function initCsrfToken()
    {
        $session = $this->getSession();
        $timeout = $this->getTimeout();
        if (null !== $timeout) {
            $session->setExpirationSeconds($timeout);  // sessions expire every 5 min.
        }

        $hash = $this->getHash(); // as explained above, if no csrf token exists, a new csrf token is generated. otherwise it returns currect token.
        $token = $this->getTokenFromHash($hash); // retrieves the hashed_csrf_token part of the csrf token.
        $tokenId = $this->getTokenIdFromHash($hash); // retrieves the second part (after "-") of the csrf token; the token_id

        /* if no token array exists, then one is created (e.g. if it is a new session). This array will hold the CSRF tokens. Each element in the array is stored as (token_id, hashed_csrf_token). 
           token_id is used to identify the current CSRF token in the session. NOTE: a new CSRF token is generated in each request, but all the old tokens are stored in the session
           (similar to Symfony and Slim) and can still be reused (for only 5 minutes (300 seconds, see above)). After this time, the CSRF token is expired and removed from session.
           In other words, this allows for a 5-min vulnerability windows for Replay attacks. Tested: REPLAY attack is possible within 5 minutes. After that token is invalidated. 
           BREACH attack is not possible since the CSRF token changes in every request.  */
        if (! $session->tokenList) {
            $session->tokenList = [];
        }
        // places (token_id, hashed_csrf_token) in the session.
        $session->tokenList[$tokenId] = $token;
        $session->hash = $hash; // @todo remove this, left for BC (not my comment)
    }

    /**
     * Generate CSRF token
     *
     * Generates CSRF token and stores both in {@link $hash} and element
     * value.
     *
     * @return void
     */
     
     // this is the function that generates the CSRF token.
    protected function generateHash()
    {
        // generates a hashed CSRF token with md5. The token to be hashed: "salt" || sth_random || "csrf"
        // It uses PHP's random_bytes() to generate 32 random bytes (256 bits of entropy). https://github.com/laminas/laminas-math/blob/master/src/Rand.php
        $token = md5($this->getSalt() . Rand::getBytes(32) .  $this->getName());
        // generates a token_id (see below) and the resulting CSRF token is: hashed_csrf_token-token_id
        $this->hash = $this->formatHash($token, $this->generateTokenId());

        // places the csrf token as an attribute of this class under csrf.hash
        $this->setValue($this->hash);
        $this->initCsrfToken();   // see above. It places the CSRF token (as a record: (token_id, hashed_csrf_token)) in the session storage
    }

    /**
     * @return string
     */
     // generates the token_id which will be part of the CSRF token, it uses the same function for randomization like the CSRF token.
     // It uses php's random_bytes() to generate 32 random bytes (256 bits of entropy). https://github.com/laminas/laminas-math/blob/master/src/Rand.php
    protected function generateTokenId()
    {
        return md5(Rand::getBytes(32));
    }

    /**
     * Get validation token
     *
     * Retrieve token from session, if it exists.
     *
     * @param string $tokenId
     * @return null|string
     */
     
     // as the comment above states, this function will retrieve the (full hashed) CSRF token from the current session. Normally it is used by providing the token_id, used to identify the correct 
     // CSRF token in the session.Note that the session storage stores only the hashed_csrf_token. The combination of hashed_csrf_token and token_id creates the actual final CSRF token sent in client-side
    protected function getValidationToken($tokenId = null)
    {
        $session = $this->getSession();

        /**
         * if no tokenId is passed we revert to the old behaviour
         * @todo remove, here for BC
         */
         // this is for backward compatibility, doesn't happen in the latest version
        if (! $tokenId && isset($session->hash)) {
            return $session->hash;
        }
        // if a token_id is provided and there is a CSRF token in the session storage's array with the given token_id, then the CSRF token is re-created by calling formatHash() that concatenates ("-") 
        // the hashed_csrf_token with token_id. If the form is not refreshed in 5 min, the CSRF token is expired, i.e. isset($session->tokenList[$tokenId]) = false and an error will be thrown 
        // in the CSRF verification (null != CSRF token in request)
        if ($tokenId && isset($session->tokenList[$tokenId])) {
            return $this->formatHash($session->tokenList[$tokenId], $tokenId); // returned the complete CSRF token (which should be same as in the request)
        }

        return;
    }

    /**
     * @param $token
     * @param $tokenId
     * @return string
     */
     
     // just a helper function that concatenates (with "-") the hashed_csrf_token with the token_id 
    protected function formatHash($token, $tokenId)
    {
        return sprintf('%s-%s', $token, $tokenId);
    }

    /**
     * @param $hash
     * @return string
     */
     
     //just a helper function that retrieves the first part of the CSRF token (hashed_csrf_token-token_id): hashed_csrf_token
    protected function getTokenFromHash($hash)
    {
        $data = explode('-', $hash); // divides the CSRF token in as many pieces as there are "-" (which in this case is 2 pieces, since 1 "-")
        return $data[0] ?: null;     // returns the first element in the array, i.e. hashed_csrf_token
    }

    /**
     * @param $hash
     * @return string
     */
     
   //just a helper function that retrieves the second part of the CSRF token (hashed_csrf_token-token_id) : token_id
    protected function getTokenIdFromHash($hash)
    {
        $data = explode('-', $hash);

        if (! isset($data[1])) { //  isset() function is an inbuilt function in PHP which checks whether a variable is set and is not NULL.
            return;
        }

        return $data[1]; //  returns the second element in the array, i.e. token_id
    }
}

