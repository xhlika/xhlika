<?php
declare(strict_types=1);

/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @since         3.5.0
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
 
 
 // THIS IS THE SOUCE CODE OF THE ANTI-CSRF MECHANISM IN CAKEPHP. THE ENTIRE CODE/LOGIC OF THE CSRF MIDDLEWARE IS FOUND WITHIN THIS FILE.
namespace Cake\Http\Middleware;

use ArrayAccess;
use Cake\Http\Cookie\Cookie;
use Cake\Http\Cookie\CookieInterface;
use Cake\Http\Exception\InvalidCsrfTokenException;
use Cake\Http\Response;
use Cake\Utility\Hash;
use Cake\Utility\Security;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

/**
 * Provides CSRF protection & validation.
 *
 * This middleware adds a CSRF token to a cookie. The cookie value is compared to
 * token in request data, or the X-CSRF-Token header on each PATCH, POST,
 * PUT, or DELETE request. This is known as "double submit cookie" technique.
 *
 * If the request data is missing or does not match the cookie data,
 * an InvalidCsrfTokenException will be raised.
 *
 * This middleware integrates with the FormHelper automatically and when
 * used together your forms will have CSRF tokens automatically added
 * when `$this->Form->create(...)` is used in a view.
 *
 * @see https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html#double-submit-cookie
 */
class CsrfProtectionMiddleware implements MiddlewareInterface
{
    /**
     * Config for the CSRF handling.
     *
     *  - `cookieName` The name of the cookie to send.
     *  - `expiry` A strotime compatible value of how long the CSRF token should last.
     *    Defaults to browser session.
     *  - `secure` Whether or not the cookie will be set with the Secure flag. Defaults to false.
     *  - `httpOnly` Whether or not the cookie will be set with the HttpOnly flag. Defaults to false.
     *  - `field` The form field to check. Changing this will also require configuring
     *    FormHelper.
     *
     * @var array
     */
    protected $_config = [
        'cookieName' => 'csrfToken',
        'expiry' => 0,
        'secure' => false,
        'httpOnly' => false,
        'field' => '_csrfToken',
    ];

    /**
     * Callback for deciding whether or not to skip the token check for particular request.
     *
     * CSRF protection token check will be skipped if the callback returns `true`.
     *
     * @var callable|null
     */
     // this can be used when the middleware is configured in src/Application.php. The developer can provide his own custom logic to disable CSRF check in specific situations, based on the request
    protected $whitelistCallback;

    /**
     * @var int
     */
     // length of CSRF token in string. (note that the final CSRF token that is sent to the client-side is a signed token: csrf_token.signature, len(csrf_token)=16)
    public const TOKEN_VALUE_LENGTH = 16;

    /**
     * Constructor
     *
     * @param array $config Config options. See $_config for valid keys.
     */
     // developer might provide his own configuration when configuring the middleware. Otherwise the default settings above will be applied instead
    public function __construct(array $config = [])
    {
        $this->_config = $config + $this->_config;
    }

    /**
     * Checks and sets the CSRF token depending on the HTTP verb.
     *
     * @param \Psr\Http\Message\ServerRequestInterface $request The request.
     * @param \Psr\Http\Server\RequestHandlerInterface $handler The request handler.
     * @return \Psr\Http\Message\ResponseInterface A response.
     */
     
     // same like in Slim, this process() function will handle the CSRF verification
    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $method = $request->getMethod();
        // check if the request method is an unsafe, or has a body (since safe request methods don't have a body)
        $hasData = in_array($method, ['PUT', 'POST', 'DELETE', 'PATCH'], true)
            || $request->getParsedBody();

        // even if it is an unsafe method, if callback was specified and returned true, then skip the CSRF verification ( i.e. handler will exe the request without doing the CSRF check)
        if (
            $hasData
            && $this->whitelistCallback !== null
            && call_user_func($this->whitelistCallback, $request) === true
        ) {
            $request = $this->_unsetTokenField($request);  // removes the CSRF token from the request's body. After all, no CSRF check will be done, so it is usesless

            return $handler->handle($request);
        }

        // gets all the cookie data from the request and place in an array
        $cookies = $request->getCookieParams();
        // gets the cookie value for the CSRF cookie (csrToken)
        $cookieData = Hash::get($cookies, $this->_config['cookieName']);

        // if the cookie value is not null and has a length >0 then  withAttribute() is called (returns an instance with the specified request attribute)
        if ($cookieData !== null && strlen($cookieData) > 0) {
            $request = $request->withAttribute('csrfToken', $cookieData);
        }

        // if the request is a GET req, e.g. retrieve the login form and the no CSRF cookie has been set yet, then a signed CSRF token will be generated
        if ($method === 'GET' && $cookieData === null) {
            $token = $this->createToken(); // see below
            $request = $request->withAttribute('csrfToken', $token);   // makes the token available to the request's objects, so that developer can access it
            /** @var mixed $response */                                // and add e.g. to the HTML form in the response
            $response = $handler->handle($request);
 
            // the signed CSRF token is placed in the CSRF cookie.
            return $this->_addTokenCookie($token, $request, $response);
        }

        // unsafe request (and no callback function is specified (which was checked above) to make the middleware skip the CSRF check)
        if ($hasData) {
            // function that compares the token in the request against the token in the CSRF cookie (see  _validateToken() below).
            $this->_validateToken($request);
            $request = $this->_unsetTokenField($request); // removes the CSRF token from the request's body. CSRF verification is finished!
        }

        return $handler->handle($request);
    }

    /**
     * Set callback for allowing to skip token check for particular request.
     *
     * The callback will receive request instance as argument and must return
     * `true` if you want to skip token check for the current request.
     *
     * @param callable $callback A callable.
     * @return $this
     */
    public function whitelistCallback(callable $callback)
    {
        $this->whitelistCallback = $callback;

        return $this;
    }

    /**
     * Remove CSRF protection token from request data.
     *
     * @param \Psr\Http\Message\ServerRequestInterface $request The request object.
     * @return \Psr\Http\Message\ServerRequestInterface
     */
     
    protected function _unsetTokenField(ServerRequestInterface $request): ServerRequestInterface
    {
        $body = $request->getParsedBody();
        if (is_array($body)) {
            unset($body[$this->_config['field']]);
            $request = $request->withParsedBody($body);
        }

        return $request;
    }

    /**
     * Create a new token to be used for CSRF protection
     *
     * @return string
     * @deprecated 4.0.6 Use {@link createToken()} instead.
     */
     // calls createToken() below to generate a signed CSRF token. Why 2 functions? One is private and the other one is public and can be called by developers.
    protected function _createToken(): string
    {
        return $this->createToken();
    }

    /**
     * Create a new token to be used for CSRF protection
     *
     * @return string
     */
     
     // function that generates the token.
    public function createToken(): string
    {
        /* https://book.cakephp.org/4/en/core-libraries/security.html and https://github.com/cakephp/cakephp/blob/master/src/Utility/Security.php#L122
           Generate a random string ( which is $length long) from a secure random source. This method draws from the same random source as randomBytes() and will encode the data 
           as a hexadecimal string (i.e. 16*2=32 chars string) IMPORTANT: token_value_length = 16 by default, but randomstring() calls randomBytes() with token_value_length/2=8.
           Then, randomBytes() will call PHP's random_bytes(8), which is NOT enough entropy (64 bits).
           The token is then converted to hexadecimal, which makes it with a length = TOKEN_VALUE_LENGTH = 16. Nevertheless, the generated random token is only 8 bytes (which is not enough). */
        $value = Security::randomString(static::TOKEN_VALUE_LENGTH);
 
         /*  https://www.php.net/manual/en/function.hash-hmac.php
            The CSRF token is signed with HMAC-SHA1. getSalt() returns $_salt variable, which  is "HMAC salt to be used for encr/decr routines." (documentation).
            Normally Security class in CakePHP uses it to derive the HMAC key, but here the salt is used directly as encryption key. Not a cryptographic key!
            final (signed) CSRF token format: csrf_token|signature.  */
        return $value . hash_hmac('sha1', $value, Security::getSalt());
    }

    /**
     * Verify that CSRF token was originally generated by the receiving application.
     *
     * @param string $token The CSRF token.
     * @return bool
     */
     
     // since CSRF tokens are signed, this function will verify that the signature of the CSRF token in the request is valid.
     // Note that the "token" parameter in this function is the signed CSRF token in the CSRF cookie
    protected function _verifyToken(string $token): bool
    {
        // if the CSRF token doesn't have the length that is expected (16), false is returned = token tampered with...
        if (strlen($token) <= self::TOKEN_VALUE_LENGTH) {
            return false;
        }

        // ...otherwise check the signature. key is not a "key", but the csrf token. Remember the signed CSRF token format is: csrf_token|signature
        // in this case key = csrf_token (i.e. the first 0-16 characters of the signed CSRF token)
        $key = substr($token, 0, static::TOKEN_VALUE_LENGTH);
        // hmac = signature part of the signed CSRF token.
        $hmac = substr($token, static::TOKEN_VALUE_LENGTH);

        // the CSRF token is signed again with HMAC-SHA1
        $expectedHmac = hash_hmac('sha1', $key, Security::getSalt());

        // check if the HMACs match, i.e. the signature is valid
        return hash_equals($hmac, $expectedHmac);
    }

    /**
     * Add a CSRF token to the response cookies.
     *
     * @param string $token The token to add.
     * @param \Psr\Http\Message\ServerRequestInterface $request The request to validate against.
     * @param \Psr\Http\Message\ResponseInterface $response The response.
     * @return \Psr\Http\Message\ResponseInterface $response Modified response.
     */
    protected function _addTokenCookie(
        string $token,
        ServerRequestInterface $request,
        ResponseInterface $response
    ): ResponseInterface { // creates  cookie with default setting: no Samesite, Httponly=false, Secure=false, expiration = browser's session.
        $cookie = $this->_createCookie($token, $request);
        if ($response instanceof Response) {
            return $response->withCookie($cookie);
        }

        return $response->withAddedHeader('Set-Cookie', $cookie->toHeaderValue());
    }

    /**
     * Validate the request data against the cookie token.
     *
     * @param \Psr\Http\Message\ServerRequestInterface $request The request to validate against.
     * @return void
     * @throws \Cake\Http\Exception\InvalidCsrfTokenException When the CSRF token is invalid or missing.
     */
     
    protected function _validateToken(ServerRequestInterface $request): void
    {
        // gets the signed CSRF token from the CSRF cookie in the incoming request
        $cookie = Hash::get($request->getCookieParams(), $this->_config['cookieName']);

        // if no CSRF cookie value is found in the incoming request, abort and throw an error
        if (!$cookie) {
            throw new InvalidCsrfTokenException(__d('cake', 'Missing CSRF cookie.'));
        }

        
        // if the signed CSRF token was tampered with (invalid signature or someone tampered with it) an error is thrown        
        if (!$this->_verifyToken($cookie)) {
            $exception = new InvalidCsrfTokenException(__d('cake', 'Missing or invalid CSRF cookie.'));
            // the CSRF cookie is set to be expired.
            $expiredCookie = $this->_createCookie('', $request)->withExpired();
            $exception->responseHeader('Set-Cookie', $expiredCookie->toHeaderValue());

            throw $exception;
        }

         // at this point the signature was valid, so the verification of 2 tokens will proceed. It will extract the CSRF token from the request's body (which should be stored under the name _csrfToken)
        $body = $request->getParsedBody();
        if (is_array($body) || $body instanceof ArrayAccess) { 
            
            // the CSRF token in the request body
            $post = (string)Hash::get($body, $this->_config['field']);
            // compare the CSRF token in request body against the CSRF token in the CSRF cookie
            if (hash_equals($post, $cookie)) {
                return;
            }
        }

        // at this point the comparison wasn't successful (either because there was no token in request body or because there was a token mismatch) so check for CSRF token in a custom header instead.
        $header = $request->getHeaderLine('X-CSRF-Token');
        // compare the CSRF token in custom header against the CSRF token in the CSRF cookie
        if (hash_equals($header, $cookie)) {
            return;
        }

        // if even this comparison fails, the token was missing or didn't match the token in the CSRF cookie.
        throw new InvalidCsrfTokenException(__d(
            'cake',
            'CSRF token from either the request body or request headers did not match or is missing.'
        ));
    }

    /**
     * Create response cookie
     *
     * @param string $value Cookie value
     * @param \Psr\Http\Message\ServerRequestInterface $request The request object.
     * @return \Cake\Http\Cookie\CookieInterface
     */
    protected function _createCookie(string $value, ServerRequestInterface $request): CookieInterface
    {
        $cookie = Cookie::create(
            $this->_config['cookieName'],
            $value,
            [
                'expires' => $this->_config['expiry'] ?: null,
                'path' => $request->getAttribute('webroot'),
                'secure' => $this->_config['secure'],
                'httponly' => $this->_config['httpOnly'],
            ]
        );

        return $cookie;
    }
}